export type UserRole = 'ADMIN' | 'PETUGAS INVENTARIS' | 'PIMPINAN/KEPALA MADRASAH' | 'USER/GURU';

export interface User {
  id: string;
  username: string;
  password?: string;
  nama: string;
  email: string;
  role: UserRole;
  jabatan: string;
  noHp?: string;
  aktif: boolean;
  createdAt: string;
}

export type KondisiBarang = 'Baik' | 'Rusak Ringan' | 'Rusak Berat';
export type StatusBarang = 'Tersedia' | 'Dipinjam' | 'Mutasi' | 'Diperbaiki' | 'Dihapus' | 'Hilang';

export interface SchoolProfile {
  namaMadrasah: string;
  yayasan: string;
  npsn: string;
  nsm: string;
  alamat: string;
  desa: string;
  kecamatan: string;
  kabupaten: string;
  provinsi: string;
  kodePos: string;
  telepon: string;
  email: string;
  website: string;
  kepalaMadrasah: string;
  nipKepalaMadrasah?: string;
  logoUrl: string;
  tahunPelajaran?: string; // e.g. "2025/2026", range 2025 s/d 2040
}

export const TAHUN_PELAJARAN_LIST: string[] = [
  '2025/2026',
  '2026/2027',
  '2027/2028',
  '2028/2029',
  '2029/2030',
  '2030/2031',
  '2031/2032',
  '2032/2033',
  '2033/2034',
  '2034/2035',
  '2035/2036',
  '2036/2037',
  '2037/2038',
  '2038/2039',
  '2039/2040',
  '2040/2041'
];

export interface Room {
  id: string;
  kodeRuangan: string; // e.g. R-KLS-X-01, LAB-KOM-01
  namaRuangan: string;
  jenisRuangan: string;
  gedung: string;
  lantai: string;
  luasRuangan: string; // m2
  penanggungJawab: string;
  kapasitas: number;
  kondisiRuangan: 'Baik' | 'Rusak Ringan' | 'Rusak Sedang' | 'Perlu Renovasi';
  keterangan: string;
  fotoRuangan: string;
}

export interface Category {
  id: string;
  kode: string; // e.g. MEU, ELK, KOM, LAP, PRN, PRO, LAB, OLA, SEN, KAN, PEM, BUK, KEB, DAP, ASR, MSJ, INS, KND, KOMM, LAI
  nama: string;
  keterangan?: string;
}

export interface Item {
  id: string;
  kodeBarang: string; // MAASS-ELK-2026-0001
  namaBarang: string;
  kategori: string;
  kategoriKode: string;
  merk: string;
  spesifikasi: string;
  nomorSeri?: string;
  tahunPerolehan: number;
  harga: number; // in IDR
  sumberDana: 'BOS' | 'Komite / Yayasan' | 'Bantuan Pemerintah' | 'Hibah / Wakaf' | 'Lainnya';
  ruanganId: string;
  ruanganNama: string;
  penanggungJawab: string;
  kondisi: KondisiBarang;
  status: StatusBarang;
  fotoBarang: string;
  keterangan?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Mutation {
  id: string;
  nomorMutasi: string;
  tanggal: string;
  kodeBarang: string;
  namaBarang: string;
  ruanganAsalId: string;
  ruanganAsalNama: string;
  ruanganTujuanId: string;
  ruanganTujuanNama: string;
  penanggungJawabLama: string;
  penanggungJawabBaru: string;
  alasanMutasi: string;
  petugas: string;
  keterangan: string;
}

export interface Loan {
  id: string;
  nomorPeminjaman: string;
  tanggal: string;
  peminjam: string;
  unitKelas: string;
  noHpPeminjam?: string;
  kodeBarang: string;
  namaBarang: string;
  jumlah: number;
  tanggalPinjam: string;
  rencanaKembali: string;
  tanggalPengembalian?: string;
  kondisiSaatPinjam: KondisiBarang;
  kondisiSaatKembali?: KondisiBarang;
  status: 'Diajukan' | 'Dipinjam' | 'Dikembalikan' | 'Terlambat' | 'Hilang' | 'Rusak';
  keterangan: string;
}

export interface Maintenance {
  id: string;
  nomorPerawatan: string;
  tanggal: string;
  kodeBarang: string;
  namaBarang: string;
  jenisPerawatan: 'Perawatan Rutin' | 'Perbaikan Ringan' | 'Perbaikan Berat' | 'Kalibrasi' | 'Penggantian Suku Cadang';
  kerusakan: string;
  tindakan: string;
  biaya: number;
  teknisi: string;
  kondisiSebelum: KondisiBarang;
  kondisiSesudah: KondisiBarang;
  fotoSebelum?: string;
  fotoSesudah?: string;
  keterangan: string;
}

export interface Disposal {
  id: string;
  nomorPenghapusan: string;
  tanggal: string;
  kodeBarang: string;
  namaBarang: string;
  tahunPerolehan: number;
  hargaPerolehan: number;
  kondisiTerakhir: KondisiBarang;
  alasanPenghapusan: string;
  metodePenghapusan: 'Lelang' | 'Pemusnahan' | 'Hibah / Donasi' | 'Tukar Menukar' | 'Daur Ulang';
  persetujuan: string; // e.g. Kepala Madrasah
  dokumenSK?: string;
  keterangan: string;
}

export interface LostItem {
  id: string;
  kodeBarang: string;
  namaBarang: string;
  ruangan: string;
  penanggungJawab: string;
  tanggalHilang: string;
  kronologi: string;
  nilaiBarang: number;
  tindakLanjut: string;
  dokumenLaporan?: string;
  status: 'Dalam Investigasi' | 'Diganti Penanggung Jawab' | 'Dihapus Aset' | 'Ditemukan Kembali';
}

export interface LibraryBook {
  id: string;
  kodeBuku: string;
  isbn: string;
  judul: string;
  penulis: string;
  penerbit: string;
  tahun: number;
  kategori: string;
  jumlah: number;
  lokasiRak: string;
  kondisi: 'Baik' | 'Rusak Ringan' | 'Rusak Berat';
}

export interface StockOpnameItemCheck {
  kodeBarang: string;
  namaBarang: string;
  kondisiSistem: KondisiBarang;
  ditemukan: boolean;
  kondisiAktual: KondisiBarang;
  perluPerbaikan: boolean;
  fotoDiperbarui: boolean;
  catatanFisik: string;
}

export interface StockOpnameSession {
  id: string;
  nomorOpname: string;
  tanggal: string;
  ruanganId: string;
  ruanganNama: string;
  petugasPemeriksa: string;
  totalBarangSistem: number;
  totalDitemukan: number;
  totalHilang: number;
  totalKondisiBerubah: number;
  totalRusak: number;
  totalBarangTambahan: number;
  items: StockOpnameItemCheck[];
  catatanKesimpulan: string;
  status: 'Draft' | 'Selesai';
}

export interface DamageReport {
  id: string;
  tanggal: string;
  kodeBarang: string;
  namaBarang: string;
  ruanganNama: string;
  pelaporNama: string;
  pelaporRole: string;
  pelaporKontak: string;
  deskripsiKerusakan: string;
  tingkatKerusakan: 'Rusak Ringan' | 'Rusak Berat' | 'Kritis/Berbahaya';
  fotoKerusakan?: string;
  status: 'Menunggu Review' | 'Diproses Perbaikan' | 'Selesai' | 'Ditolak';
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  timestamp: string;
  tanggal: string;
  jam: string;
  aktivitas: string;
  modul: string;
  dataSebelum?: string;
  dataSesudah?: string;
  ipAddress?: string;
}

export interface WhatsAppNotification {
  id: string;
  timestamp: string;
  targetNomor: string;
  targetNama: string;
  kategori: 'Lapor Kerusakan' | 'Peminjaman' | 'Pengembalian' | 'Mutasi' | 'Stock Opname';
  pesan: string;
  status: 'Terkirim' | 'Gagal' | 'Pending';
}
