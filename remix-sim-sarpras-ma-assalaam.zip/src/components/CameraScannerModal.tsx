import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  X,
  RefreshCw,
  Search,
  Building2,
  Package,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { Item, Room } from '../types';

interface CameraScannerModalProps {
  items: Item[];
  rooms: Room[];
  onFoundItem: (item: Item) => void;
  onFoundRoom: (room: Room) => void;
  onClose: () => void;
}

export const CameraScannerModal: React.FC<CameraScannerModalProps> = ({
  items,
  rooms,
  onFoundItem,
  onFoundRoom,
  onClose
}) => {
  const [manualCode, setManualCode] = useState('');
  const [scanError, setScanError] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const qrScannerRef = useRef<Html5Qrcode | null>(null);
  const scannerContainerId = 'interactive-camera-scanner-view';

  // Process a scanned or typed code
  const handleProcessCode = (scannedText: string) => {
    let clean = scannedText.trim();
    if (!clean) return;

    // Check if scannedText is a URL containing ?ruangan= or ?room= or #ruangan= or ?barang=
    try {
      if (clean.includes('ruangan=') || clean.includes('room=')) {
        const match = clean.match(/[?&#](?:ruangan|room)=([^&#]+)/i);
        if (match && match[1]) {
          clean = decodeURIComponent(match[1]).trim();
        }
      } else if (clean.includes('barang=') || clean.includes('item=')) {
        const match = clean.match(/[?&#](?:barang|item)=([^&#]+)/i);
        if (match && match[1]) {
          clean = decodeURIComponent(match[1]).trim();
        }
      } else if (clean.startsWith('http://') || clean.startsWith('https://')) {
        const urlObj = new URL(clean);
        const r = urlObj.searchParams.get('ruangan') || urlObj.searchParams.get('room');
        const b = urlObj.searchParams.get('barang') || urlObj.searchParams.get('item');
        if (r) clean = r.trim();
        else if (b) clean = b.trim();
      }
    } catch (e) {
      // not a strict URL, proceed with raw string
    }

    const cleanLower = clean.toLowerCase();

    // 1. Check if matches a Room (Priority for door scans)
    const matchedRoom = rooms.find(
      (r) =>
        r.kodeRuangan.toLowerCase() === cleanLower ||
        r.id.toLowerCase() === cleanLower ||
        r.namaRuangan.toLowerCase() === cleanLower ||
        cleanLower.includes(r.kodeRuangan.toLowerCase()) ||
        cleanLower.includes(r.id.toLowerCase())
    );

    if (matchedRoom) {
      stopCamera();
      onFoundRoom(matchedRoom);
      return;
    }

    // 2. Check if code matches an Item
    const matchedItem = items.find(
      (i) =>
        i.kodeBarang.toLowerCase() === cleanLower ||
        (i.nomorSeri && i.nomorSeri.toLowerCase() === cleanLower) ||
        cleanLower.includes(i.kodeBarang.toLowerCase())
    );

    if (matchedItem) {
      stopCamera();
      onFoundItem(matchedItem);
      return;
    }

    setScanError(`Kode "${clean}" tidak ditemukan dalam data barang maupun ruangan MA Assalaam.`);
  };

  const startCamera = async () => {
    setScanError(null);
    try {
      if (qrScannerRef.current) {
        await qrScannerRef.current.stop().catch(() => {});
      }

      const html5QrCode = new Html5Qrcode(scannerContainerId, {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.QR_CODE,
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.UPC_A
        ],
        verbose: false
      });

      qrScannerRef.current = html5QrCode;

      await html5QrCode.start(
        { facingMode: cameraFacing },
        {
          fps: 12,
          qrbox: { width: 250, height: 250 }
        },
        (decodedText) => {
          handleProcessCode(decodedText);
        },
        () => {
          // ignore scan frame errors
        }
      );

      setIsCameraActive(true);
    } catch (err: any) {
      console.warn('Camera start error:', err);
      setIsCameraActive(false);
      setScanError('Tidak dapat mengakses kamera perangkat. Pastikan izin kamera telah diberikan di browser.');
    }
  };

  const stopCamera = async () => {
    if (qrScannerRef.current) {
      try {
        await qrScannerRef.current.stop();
        qrScannerRef.current.clear();
      } catch (e) {
        // ignore
      }
      qrScannerRef.current = null;
    }
    setIsCameraActive(false);
  };

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, [cameraFacing]);

  const toggleCameraFacing = () => {
    setCameraFacing((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-extrabold text-sm">
            <Camera className="w-5 h-5 text-amber-500" />
            <span>Pemindai Barcode &amp; QR Code Langsung</span>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Camera Box */}
        <div className="mt-4 relative rounded-2xl overflow-hidden bg-slate-950 min-h-[280px] flex items-center justify-center border-2 border-slate-800 shadow-inner">
          <div id={scannerContainerId} className="w-full h-full" />

          {/* Scanner Guide Overlay */}
          <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
            <div className="w-56 h-56 border-2 border-dashed border-emerald-400/90 rounded-2xl relative animate-pulse">
              <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-amber-400 -mt-0.5 -ml-0.5" />
              <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-amber-400 -mt-0.5 -mr-0.5" />
              <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-amber-400 -mb-0.5 -ml-0.5" />
              <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-amber-400 -mb-0.5 -mr-0.5" />
            </div>
            <p className="mt-4 text-[11px] font-bold text-white bg-black/60 px-3 py-1 rounded-full backdrop-blur-xs">
              Arahkan kamera ke Barcode Barang atau QR Ruangan
            </p>
          </div>

          {/* Camera Controls inside overlay */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5 z-10">
            <button
              type="button"
              onClick={toggleCameraFacing}
              className="p-2 bg-slate-900/80 hover:bg-slate-800 text-white rounded-xl backdrop-blur-xs text-xs font-semibold flex items-center gap-1 shadow"
              title="Ganti Kamera Depan/Belakang"
            >
              <RefreshCw className="w-3.5 h-3.5 text-amber-300" />
            </button>
          </div>
        </div>

        {/* Error message */}
        {scanError && (
          <div className="mt-3 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
            <span>{scanError}</span>
          </div>
        )}

        {/* Manual Input Fallback */}
        <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
            Atau Ketik / Paste Kode Barang atau Kode Ruangan:
          </label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Contoh: MAASS-KOM-2026-0001 atau LAB-KOM-01"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleProcessCode(manualCode);
                  }
                }}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white uppercase font-mono font-bold"
              />
            </div>
            <button
              type="button"
              onClick={() => handleProcessCode(manualCode)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl shadow transition-colors cursor-pointer"
            >
              Cari
            </button>
          </div>
        </div>

        {/* Quick Sample Barcodes For Testing */}
        <div className="mt-3 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
            <HelpCircle className="w-3 h-3 text-emerald-600" />
            Uji Coba Cepat (Klik salah satu):
          </span>
          <div className="flex flex-wrap gap-1.5">
            {items.slice(0, 3).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleProcessCode(item.kodeBarang)}
                className="px-2 py-1 bg-white dark:bg-slate-700 hover:bg-emerald-50 text-[10px] font-mono font-bold text-emerald-800 dark:text-emerald-300 rounded-lg border border-slate-200 dark:border-slate-600 transition-colors shadow-2xs flex items-center gap-1"
              >
                <Package className="w-3 h-3" />
                {item.kodeBarang}
              </button>
            ))}
            {rooms.slice(0, 2).map((room) => (
              <button
                key={room.id}
                type="button"
                onClick={() => handleProcessCode(room.kodeRuangan)}
                className="px-2 py-1 bg-white dark:bg-slate-700 hover:bg-amber-50 text-[10px] font-mono font-bold text-amber-800 dark:text-amber-300 rounded-lg border border-slate-200 dark:border-slate-600 transition-colors shadow-2xs flex items-center gap-1"
              >
                <Building2 className="w-3 h-3" />
                {room.kodeRuangan}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
