import React, { useState } from 'react';
import {
  Building2,
  Package,
  AlertTriangle,
  Send,
  X,
  ArrowLeft,
  CheckCircle2,
  Search,
  DollarSign,
  User,
  MapPin,
  Camera,
  Layers,
  Info
} from 'lucide-react';
import { Room, Item, SchoolProfile, DamageReport } from '../types';
import { StorageService } from '../services/storage';
import { formatRupiah } from '../services/barcodeGenerator';

interface PublicRoomViewerProps {
  rooms: Room[];
  items: Item[];
  schoolProfile: SchoolProfile;
  selectedRoomId?: string;
  onClose: () => void;
  onOpenScanner: () => void;
}

export const PublicRoomViewer: React.FC<PublicRoomViewerProps> = ({
  rooms,
  items,
  schoolProfile,
  selectedRoomId,
  onClose,
  onOpenScanner
}) => {
  const [activeRoomId, setActiveRoomId] = useState<string>(
    selectedRoomId || rooms[0]?.id || ''
  );
  const [searchQuery, setSearchQuery] = useState('');

  // Whenever selectedRoomId prop changes (e.g. from camera scan or URL param), sync activeRoomId
  React.useEffect(() => {
    if (selectedRoomId) {
      const found = rooms.find(
        (r) =>
          r.id.toLowerCase() === selectedRoomId.toLowerCase() ||
          r.kodeRuangan.toLowerCase() === selectedRoomId.toLowerCase() ||
          r.namaRuangan.toLowerCase() === selectedRoomId.toLowerCase()
      );
      if (found) {
        setActiveRoomId(found.id);
      } else {
        setActiveRoomId(selectedRoomId);
      }
    }
  }, [selectedRoomId, rooms]);

  // Damage Report Form Modal
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportItemCode, setReportItemCode] = useState('');
  const [pelaporNama, setPelaporNama] = useState('');
  const [pelaporKontak, setPelaporKontak] = useState('');
  const [deskripsi, setDeskripsi] = useState('');
  const [tingkat, setTingkat] = useState<'Rusak Ringan' | 'Rusak Berat' | 'Kritis/Berbahaya'>('Rusak Ringan');
  const [fotoKerusakan, setFotoKerusakan] = useState('');
  const [reportSuccess, setReportSuccess] = useState(false);

  const currentRoom =
    rooms.find(
      (r) =>
        r.id === activeRoomId ||
        r.kodeRuangan.toLowerCase() === activeRoomId.toLowerCase()
    ) || rooms[0];

  // Items located in current room
  const roomItems = items.filter(
    (item) =>
      item.ruanganId === currentRoom?.id ||
      item.ruanganNama.toLowerCase() === currentRoom?.namaRuangan.toLowerCase()
  );

  // Filtered by local search query
  const filteredItems = roomItems.filter(
    (item) =>
      item.namaBarang.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.kodeBarang.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.merk.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.spesifikasi.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalNilaiAset = roomItems.reduce((acc, curr) => acc + (curr.harga || 0), 0);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setFotoKerusakan(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitDamageReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pelaporNama.trim() || !deskripsi.trim()) {
      alert('Mohon isi nama pelapor dan deskripsi kerusakan.');
      return;
    }

    const targetItem = roomItems.find((i) => i.kodeBarang === reportItemCode) || roomItems[0];
    const newReport: DamageReport = {
      id: `rep-${Date.now()}`,
      tanggal: new Date().toLocaleString('id-ID'),
      kodeBarang: targetItem ? targetItem.kodeBarang : 'UMUM',
      namaBarang: targetItem ? targetItem.namaBarang : 'Fasilitas Ruangan ' + currentRoom.namaRuangan,
      ruanganNama: currentRoom.namaRuangan,
      pelaporNama: pelaporNama.trim(),
      pelaporRole: 'Tamu / Guru / Siswa (Scan Pintu)',
      pelaporKontak: pelaporKontak.trim() || '-',
      deskripsiKerusakan: deskripsi.trim(),
      tingkatKerusakan: tingkat,
      fotoKerusakan,
      status: 'Menunggu Review'
    };

    // Save report to database (ticket for admin review only, does not alter item inventory)
    const existingReports = StorageService.getDamageReports();
    existingReports.unshift(newReport);
    StorageService.saveDamageReports(existingReports);

    // Add audit log
    StorageService.addAuditLog(
      null,
      `Laporan kerusakan fasilitas diajukan: ${newReport.namaBarang} di ${currentRoom.namaRuangan}`,
      'Laporan Kerusakan Publik'
    );

    // Send WhatsApp notification simulation to admin
    const sheetSettings = StorageService.getSheetSettings();
    const adminWA = sheetSettings.waAdminNumber || '081223456789';
    const waText = `🚨 *LAPORAN KERUSAKAN BARANG - MA ASSALAAM*\n\n` +
      `Ruangan: ${currentRoom.namaRuangan} (${currentRoom.kodeRuangan})\n` +
      `Barang: ${newReport.namaBarang} (${newReport.kodeBarang})\n` +
      `Pelapor: ${newReport.pelaporNama} (Kontak: ${newReport.pelaporKontak})\n` +
      `Tingkat: ${newReport.tingkatKerusakan}\n` +
      `Keterangan: ${newReport.deskripsiKerusakan}\n\n` +
      `_Tercatat otomatis melalui Scan QR Pintu Ruangan._`;

    StorageService.sendWhatsAppNotification(adminWA, 'Admin Sarpras MA Assalaam', 'Lapor Kerusakan', waText);

    setReportSuccess(true);
    setTimeout(() => {
      setShowReportModal(false);
      setReportSuccess(false);
      setDeskripsi('');
      setFotoKerusakan('');
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-100 dark:bg-slate-950 overflow-y-auto">
      {/* Top Banner */}
      <div className="bg-emerald-800 text-white px-4 py-3 shadow-md flex items-center justify-between sticky top-0 z-20 border-b border-emerald-900">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-emerald-700 rounded-lg text-emerald-200 hover:text-white transition-colors flex items-center gap-1 text-xs font-semibold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Kembali ke Halaman Masuk</span>
          </button>
          <div className="h-4 w-px bg-emerald-700 hidden sm:block" />
          <div className="flex items-center gap-2">
            <img
              src={schoolProfile.logoUrl}
              alt="Logo MA Assalaam"
              className="w-7 h-7 object-contain rounded-full bg-white p-0.5"
            />
            <span className="text-xs font-bold text-amber-300">
              Pemeriksaan QR Pintu Ruangan (Akses Tanpa Login)
            </span>
          </div>
        </div>

        <button
          onClick={onOpenScanner}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg shadow transition-colors"
        >
          <Camera className="w-3.5 h-3.5" />
          <span>Scan QR Pintu Lain</span>
        </button>
      </div>

      <div className="max-w-6xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* Connection status banner */}
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-500 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <CheckCircle2 className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase text-emerald-900 dark:text-emerald-200 tracking-wide">
                  Terhubung ke QR Code Pintu: {currentRoom.namaRuangan}
                </span>
                <span className="font-mono text-[10px] font-bold bg-amber-400 text-slate-950 px-2 py-0.5 rounded">
                  {currentRoom.kodeRuangan}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                Menampilkan daftar inventaris lengkap {roomItems.length} unit barang di ruangan ini tanpa memerlukan login.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenScanner}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Pindai QR Pintu Lain</span>
          </button>
        </div>

        {/* Selector to switch room */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
            <Building2 className="w-4 h-4 text-emerald-600" />
            <span className="font-bold">Pilih / Ganti Ruangan:</span>
          </div>
          <select
            value={activeRoomId}
            onChange={(e) => setActiveRoomId(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 text-xs font-semibold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          >
            {rooms.map((room) => (
              <option key={room.id} value={room.id}>
                {room.namaRuangan} ({room.kodeRuangan}) - {room.gedung}
              </option>
            ))}
          </select>
        </div>

        {currentRoom && (
          <>
            {/* Room Hero Card */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-md border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-3">
                {/* Photo */}
                <div className="h-48 md:h-full relative overflow-hidden bg-slate-200 dark:bg-slate-800">
                  <img
                    src={currentRoom.fotoRuangan}
                    alt={currentRoom.namaRuangan}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3 px-2.5 py-1 bg-emerald-800/90 text-amber-300 text-[11px] font-extrabold rounded-lg backdrop-blur-xs">
                    {currentRoom.kodeRuangan}
                  </div>
                </div>

                {/* Details */}
                <div className="p-5 md:col-span-2 flex flex-col justify-between">
                  <div>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <h2 className="text-xl font-black text-slate-900 dark:text-white">
                        {currentRoom.namaRuangan}
                      </h2>
                      <span className="px-3 py-1 text-xs font-bold rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300">
                        Kondisi: {currentRoom.kondisiRuangan}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-slate-600 dark:text-slate-300 mt-3">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Gedung &amp; Lantai</span>
                        <span className="font-semibold">{currentRoom.gedung}, {currentRoom.lantai}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Penanggung Jawab</span>
                        <span className="font-semibold text-emerald-700 dark:text-emerald-400">{currentRoom.penanggungJawab}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Luas &amp; Kapasitas</span>
                        <span className="font-semibold">{currentRoom.luasRuangan} m² ({currentRoom.kapasitas} Orang)</span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-3 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">Keterangan: </span>
                      {currentRoom.keterangan || 'Tidak ada catatan khusus.'}
                    </p>
                  </div>

                  {/* Summary Badges & Action */}
                  <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-4 text-xs font-semibold">
                      <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                        <Package className="w-4 h-4 text-emerald-600" />
                        <span>Total: <strong className="text-slate-900 dark:text-white">{roomItems.length}</strong> Barang</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                        <DollarSign className="w-4 h-4 text-amber-600" />
                        <span>Nilai Aset: <strong className="text-emerald-700 dark:text-emerald-400">{formatRupiah(totalNilaiAset)}</strong></span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setShowReportModal(true)}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer hover:scale-105"
                    >
                      <AlertTriangle className="w-4 h-4 text-amber-300" />
                      Laporkan Kerusakan di Ruangan Ini
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Room Inventory List */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-md border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-emerald-600" />
                    Daftar Seluruh Barang di Ruangan Ini ({filteredItems.length})
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Data inventaris tersinkronisasi otomatis dengan database pusat MA Assalaam
                  </p>
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Cari barang di ruangan..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {filteredItems.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  <Package className="w-8 h-8 mx-auto mb-2 text-slate-300 opacity-60" />
                  Tidak ada barang yang cocok dalam ruangan ini.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
                      <tr>
                        <th className="py-2.5 px-3">No</th>
                        <th className="py-2.5 px-3">Kode Inventaris</th>
                        <th className="py-2.5 px-3">Nama Barang</th>
                        <th className="py-2.5 px-3">Merk / Spesifikasi</th>
                        <th className="py-2.5 px-3">Kondisi</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3 text-right">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                      {filteredItems.map((item, idx) => (
                        <tr key={item.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                          <td className="py-2 px-3 text-slate-400">{idx + 1}</td>
                          <td className="py-2 px-3 font-mono font-bold text-emerald-700 dark:text-emerald-400">
                            {item.kodeBarang}
                          </td>
                          <td className="py-2 px-3 font-semibold text-slate-900 dark:text-white">
                            {item.namaBarang}
                          </td>
                          <td className="py-2 px-3 text-[11px] text-slate-500 max-w-xs truncate">
                            {item.merk} - {item.spesifikasi}
                          </td>
                          <td className="py-2 px-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                item.kondisi === 'Baik'
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                  : item.kondisi === 'Rusak Ringan'
                                  ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                  : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                              }`}
                            >
                              {item.kondisi}
                            </span>
                          </td>
                          <td className="py-2 px-3">
                            <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400">
                              {item.status}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-right">
                            <button
                              type="button"
                              onClick={() => {
                                setReportItemCode(item.kodeBarang);
                                setShowReportModal(true);
                              }}
                              className="px-2.5 py-1 text-[10px] font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg transition-colors"
                            >
                              Lapor Rusak
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* POPUP MODAL LAPOR KERUSAKAN */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 text-rose-600 font-extrabold text-sm">
                <AlertTriangle className="w-5 h-5" />
                <span>Form Laporan Kerusakan Barang</span>
              </div>
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {reportSuccess ? (
              <div className="py-8 text-center space-y-2">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto animate-bounce" />
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Laporan Berhasil Terkirim!
                </h4>
                <p className="text-xs text-slate-500">
                  Notifikasi otomatis telah dikirimkan ke koordinator sarpras &amp; diteruskan via WhatsApp. Terima kasih atas kepedulian Anda.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitDamageReport} className="mt-4 space-y-3.5 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Ruangan Terkait
                  </label>
                  <input
                    type="text"
                    disabled
                    value={`${currentRoom.namaRuangan} (${currentRoom.kodeRuangan})`}
                    className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border rounded-xl text-slate-500 font-semibold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Pilih Barang yang Rusak <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={reportItemCode}
                    onChange={(e) => setReportItemCode(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  >
                    <option value="">-- Fasilitas Umum Ruangan (Tanpa Kode Khusus) --</option>
                    {roomItems.map((itm) => (
                      <option key={itm.id} value={itm.kodeBarang}>
                        {itm.kodeBarang} - {itm.namaBarang} ({itm.merk})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Nama Pelapor <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Ust. Saepudin / Rina Siswa"
                      value={pelaporNama}
                      onChange={(e) => setPelaporNama(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                      No. WhatsApp Pelapor
                    </label>
                    <input
                      type="tel"
                      placeholder="08xxxxxxxxxx"
                      value={pelaporKontak}
                      onChange={(e) => setPelaporKontak(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Tingkat Keparahan Kerusakan
                  </label>
                  <select
                    value={tingkat}
                    onChange={(e) => setTingkat(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-semibold"
                  >
                    <option value="Rusak Ringan">Rusak Ringan (Masih bisa digunakan sebagian)</option>
                    <option value="Rusak Berat">Rusak Berat (Tidak berfungsi / mati total)</option>
                    <option value="Kritis/Berbahaya">Kritis / Berbahaya (Konsleting, pecah beling, bocor gas)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Deskripsi Kerusakan / Kronologi <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Jelaskan detail kendala barang, letak posisi, atau gejala saat dinyalakan..."
                    value={deskripsi}
                    onChange={(e) => setDeskripsi(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Foto Kondisi Kerusakan (Opsional)
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="w-full text-xs text-slate-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-emerald-100 file:text-emerald-800 dark:file:bg-slate-800 dark:file:text-emerald-300 cursor-pointer"
                  />
                  {fotoKerusakan && (
                    <img
                      src={fotoKerusakan}
                      alt="Preview Rusak"
                      className="mt-2 w-20 h-20 object-cover rounded-lg border border-slate-300 shadow-sm"
                    />
                  )}
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowReportModal(false)}
                    className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Kirim Laporan Kerusakan
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
