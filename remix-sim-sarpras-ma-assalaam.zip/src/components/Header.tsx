import React, { useState } from 'react';
import {
  Bell,
  Camera,
  Moon,
  Sun,
  LogOut,
  RefreshCw,
  Upload,
  UserCheck
} from 'lucide-react';
import { User, SchoolProfile } from '../types';
import { StorageService } from '../services/storage';

interface HeaderProps {
  currentUser: User | null;
  schoolProfile: SchoolProfile;
  onLogout: () => void;
  onOpenScanner: () => void;
  onOpenNotifications: () => void;
  notificationCount: number;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onUpdateLogo: (newLogoUrl: string) => void;
  onManualSync: () => void;
  isSyncing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  schoolProfile,
  onLogout,
  onOpenScanner,
  onOpenNotifications,
  notificationCount,
  darkMode,
  onToggleDarkMode,
  onUpdateLogo,
  onManualSync,
  isSyncing
}) => {
  const [showLogoModal, setShowLogoModal] = useState(false);
  const [logoInput, setLogoInput] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onUpdateLogo(event.target.result as string);
          setShowLogoModal(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveLogoUrl = () => {
    if (logoInput.trim()) {
      onUpdateLogo(logoInput.trim());
      setShowLogoModal(false);
      setLogoInput('');
    }
  };

  return (
    <>
      <header className="sticky top-0 z-30 flex items-center justify-between px-4 py-2.5 bg-emerald-800 text-white shadow-md border-b border-emerald-900">
        {/* Left: School Emblem & Titles */}
        <div className="flex items-center gap-3">
          <div className="relative group cursor-pointer" onClick={() => setShowLogoModal(true)} title="Klik untuk mengubah logo madrasah (PNG/SVG)">
            <img
              src={schoolProfile.logoUrl}
              alt="Logo MA Assalaam"
              className="w-10 h-10 object-contain rounded-full bg-white p-0.5 shadow ring-2 ring-amber-400 group-hover:scale-105 transition-transform"
            />
            <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Upload className="w-3.5 h-3.5 text-white" />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-wide text-amber-300 drop-shadow-sm font-sans">
                SIM SARPRAS MA ASSALAAM
              </span>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40 rounded-full">
                ARJASARI
              </span>
              <span className="hidden md:inline-block px-2 py-0.5 text-[10px] font-bold bg-emerald-950/80 text-emerald-200 border border-emerald-500/30 rounded-full font-mono">
                TP {schoolProfile.tahunPelajaran || '2025/2026'}
              </span>
            </div>
            <p className="text-[11px] text-emerald-100 hidden md:block">
              Sistem Inventaris Sarana dan Prasarana {schoolProfile.namaMadrasah} • Kab. Bandung
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {/* Automated Spreadsheet Live Status Indicator */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 bg-emerald-900/80 border border-emerald-600/50 rounded-lg text-[11px] text-emerald-200" title="Koneksi Google Spreadsheet aktif & otomatis tersinkronisasi">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Spreadsheet Auto-Sync</span>
          </div>
          {/* Direct Camera Barcode/QR Scan */}
          <button
            onClick={onOpenScanner}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-emerald-700 hover:bg-emerald-600 border border-emerald-500/40 text-white rounded-lg shadow-sm transition-all"
            title="Akses Langsung Kamera Scanner Barcode / QR Ruangan"
          >
            <Camera className="w-4 h-4 text-amber-300 animate-pulse" />
            <span className="hidden sm:inline">Scan Barcode / QR</span>
          </button>

          {/* Sync to Spreadsheet button */}
          <button
            onClick={onManualSync}
            disabled={isSyncing}
            className="p-1.5 text-xs font-medium bg-emerald-700/60 hover:bg-emerald-600 border border-emerald-500/30 text-emerald-100 rounded-lg transition-colors"
            title="Sinkronisasi Otomatis ke Spreadsheet & Data"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin text-amber-300' : ''}`} />
          </button>

          {/* Notification Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative p-1.5 bg-emerald-700/60 hover:bg-emerald-600 border border-emerald-500/30 text-emerald-100 rounded-lg transition-colors"
            title="Notifikasi & Laporan Kerusakan"
          >
            <Bell className="w-4 h-4" />
            {notificationCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-bold text-white ring-2 ring-emerald-800 animate-bounce">
                {notificationCount}
              </span>
            )}
          </button>

          {/* Dark Mode */}
          <button
            onClick={onToggleDarkMode}
            className="p-1.5 bg-emerald-700/60 hover:bg-emerald-600 border border-emerald-500/30 text-emerald-100 rounded-lg transition-colors"
            title={darkMode ? 'Beralih ke Mode Terang' : 'Beralih ke Mode Gelap'}
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-slate-200" />}
          </button>

          {/* User Profile & Role Info */}
          {currentUser && (
            <div className="flex items-center gap-2 pl-2 border-l border-emerald-700/70">
              <div className="hidden lg:block text-right">
                <div className="text-xs font-bold leading-tight text-white flex items-center justify-end gap-1">
                  <UserCheck className="w-3.5 h-3.5 text-amber-300" />
                  {currentUser.nama.split(',')[0]}
                </div>
                <div className="text-[10px] font-medium text-emerald-200 uppercase tracking-wider">
                  {currentUser.role}
                </div>
              </div>

              <button
                onClick={onLogout}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-rose-700 hover:bg-rose-600 text-white rounded-lg shadow-sm transition-colors"
                title="Keluar dari Akun"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Keluar</span>
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Modal Upload Logo Madrasah (PNG / SVG) */}
      {showLogoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Upload className="w-5 h-5 text-emerald-600" />
              Perbarui Logo Madrasah
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Pilih file gambar logo baru dalam format PNG transparan atau SVG untuk ditampilkan pada kop surat, label inventaris, dan sertifikat resmi MA Assalaam.
            </p>

            <div className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl mb-4 bg-slate-50 dark:bg-slate-800/50">
              <img
                src={schoolProfile.logoUrl}
                alt="Logo Preview"
                className="w-20 h-20 object-contain mb-3 rounded-full bg-white p-1 shadow"
              />
              <label className="cursor-pointer px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow transition-colors flex items-center gap-2">
                <Upload className="w-4 h-4" />
                Pilih File Logo PNG dari Perangkat
                <input
                  type="file"
                  accept="image/png, image/jpeg, image/svg+xml"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
            </div>

            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Atau Masukkan URL Logo (Opsional):
              </label>
              <input
                type="text"
                placeholder="https://.../logo.png"
                value={logoInput}
                onChange={(e) => setLogoInput(e.target.value)}
                className="w-full text-xs px-3 py-2 border rounded-lg dark:bg-slate-800 dark:border-slate-700 text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowLogoModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
              >
                Batal
              </button>
              {logoInput && (
                <button
                  type="button"
                  onClick={handleSaveLogoUrl}
                  className="px-4 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg"
                >
                  Terapkan URL
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
