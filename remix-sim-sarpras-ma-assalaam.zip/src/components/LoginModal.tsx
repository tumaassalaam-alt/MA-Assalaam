import React, { useState } from 'react';
import {
  Lock,
  UserCheck,
  QrCode,
  AlertCircle,
  Building,
  Mail,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { User, SchoolProfile } from '../types';
import { StorageService } from '../services/storage';

interface LoginModalProps {
  schoolProfile: SchoolProfile;
  onLoginSuccess: (user: User) => void;
  onOpenPublicRoomScan: () => void;
  onDirectScanBarcode: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  schoolProfile,
  onLoginSuccess,
  onOpenPublicRoomScan,
  onDirectScanBarcode
}) => {
  // Login Form State
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!username.trim()) {
      setErrorMessage('Silakan masukkan email atau username terdaftar Anda.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await StorageService.login(username.trim(), password.trim());
      if (res.success && res.user) {
        onLoginSuccess(res.user);
      } else {
        setErrorMessage(
          res.message ||
          `Akses Ditolak: Email atau akun "${username.trim()}" tidak terdaftar dalam database aplikasi ini. Hanya email yang telah terdaftar yang dapat masuk.`
        );
      }
    } catch (err: any) {
      setErrorMessage('Terjadi kendala saat verifikasi: ' + (err.message || 'Koneksi gagal'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Header Card */}
        <div className="bg-gradient-to-br from-emerald-800 via-emerald-700 to-emerald-900 p-6 text-white text-center relative border-b border-emerald-600/30">
          <div className="w-20 h-20 mx-auto mb-3 bg-white p-1 rounded-full shadow-lg ring-4 ring-amber-400/80 flex items-center justify-center">
            <img
              src={schoolProfile.logoUrl}
              alt="Logo MA Assalaam"
              className="w-full h-full object-contain rounded-full"
            />
          </div>
          <h1 className="text-xl font-extrabold tracking-wide text-amber-300 drop-shadow-sm font-sans">
            SIM SARPRAS MA ASSALAAM
          </h1>
          <p className="text-xs text-emerald-100 font-medium mt-1">
            Sistem Informasi Inventaris Sarana dan Prasarana
          </p>
          <p className="text-[11px] text-emerald-200/80 mt-0.5">
            {schoolProfile.yayasan} • Kec. Arjasari, Kab. Bandung
          </p>
        </div>

        {/* SECTION 1: PUBLIC ACCESS - SCAN BARCODE RUANGAN (NO LOGIN REQUIRED) */}
        <div className="p-4 bg-emerald-50/80 dark:bg-emerald-950/40 border-b border-emerald-200 dark:border-emerald-800">
          <div className="text-center mb-2.5">
            <span className="text-[11px] font-bold text-emerald-900 dark:text-emerald-200 uppercase tracking-wider flex items-center justify-center gap-1">
              🚪 Scan Barcode / QR Ruangan
            </span>
            <p className="text-xs text-emerald-800 dark:text-emerald-300/90 font-medium mt-0.5">
              Hanya melihat data ruangan &amp; inventaris tanpa masuk ke akun aplikasi
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={onDirectScanBarcode}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl shadow-sm transition-all hover:scale-[1.02] cursor-pointer"
            >
              <QrCode className="w-4 h-4 text-slate-950 shrink-0" />
              <span>Buka Kamera Scan</span>
            </button>

            <button
              type="button"
              onClick={onOpenPublicRoomScan}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl shadow-sm transition-all hover:scale-[1.02] cursor-pointer"
            >
              <Building className="w-4 h-4 text-amber-300 shrink-0" />
              <span>Lihat Data Ruangan</span>
            </button>
          </div>
        </div>

        {/* SECTION 2: AUTHENTICATION FOR REGISTERED DATABASE EMAILS ONLY */}
        <div className="p-6">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100 dark:border-slate-800">
            <h2 className="text-xs font-black text-slate-800 dark:text-slate-100 flex items-center gap-1.5 uppercase tracking-wide">
              <UserCheck className="w-4 h-4 text-emerald-600" />
              Masuk Akun Terdaftar
            </h2>
            <span className="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-full">
              Khusus Email Terdaftar
            </span>
          </div>

          {/* Access Restriction Notice */}
          <div className="mb-4 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px] text-slate-600 dark:text-slate-300 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>Akses Dibatasi:</strong> Hanya email yang sudah ada datanya di database aplikasi ini yang dapat masuk. Email baru tidak dapat merubah database sebelum didaftarkan oleh Administrator.
            </p>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500 mt-0.5" />
              <span className="leading-snug">{errorMessage}</span>
            </div>
          )}

          {/* LOGIN FORM */}
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Email atau Username Terdaftar
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  placeholder="Contoh: tumaassalaam@gmail.com atau admin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Password Akun
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  placeholder="Masukkan password Anda (default: 123456)"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-60 text-white font-bold text-xs rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {isLoading ? (
                <span>Memverifikasi Database...</span>
              ) : (
                <>
                  <span>Verifikasi &amp; Masuk ke Aplikasi</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
