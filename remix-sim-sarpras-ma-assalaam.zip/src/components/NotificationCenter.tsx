import React from 'react';
import {
  Bell,
  X,
  AlertTriangle,
  Clock,
  Wrench,
  CameraOff,
  Barcode,
  Share2,
  CheckCircle2,
  Smartphone
} from 'lucide-react';
import { Item, Loan, LostItem, DamageReport } from '../types';
import { StorageService } from '../services/storage';

interface NotificationCenterProps {
  items: Item[];
  loans: Loan[];
  lostItems: LostItem[];
  damageReports: DamageReport[];
  onClose: () => void;
  onSelectItem: (item: Item) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  items,
  loans,
  lostItems,
  damageReports,
  onClose,
  onSelectItem
}) => {
  // 1. Damaged items
  const damagedItems = items.filter((i) => i.kondisi === 'Rusak Berat' || i.kondisi === 'Rusak Ringan');
  // 2. Overdue loans
  const overdueLoans = loans.filter((l) => l.status === 'Terlambat');
  // 3. Pending damage reports
  const pendingReports = damageReports.filter((r) => r.status === 'Menunggu Review');
  // 4. Lost items
  const activeLost = lostItems.filter((l) => l.status === 'Dalam Investigasi');
  // 5. Items missing photo
  const itemsWithoutPhoto = items.filter((i) => !i.fotoBarang || i.fotoBarang.trim() === '');

  const totalAlerts =
    damagedItems.length +
    overdueLoans.length +
    pendingReports.length +
    activeLost.length +
    itemsWithoutPhoto.length;

  const handleSendWaAlert = (targetPhone: string, title: string, body: string) => {
    const text = `*SIM SARPRAS MA ASSALAAM - PERINGATAN SISTEM*\n\n` +
      `📋 *${title}*\n${body}\n\n` +
      `_Mohon tindak lanjuti melalui SIM SARPRAS MA Assalaam._`;
    StorageService.openWhatsApp(targetPhone, text);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-white dark:bg-slate-900 shadow-2xl border-l border-slate-200 dark:border-slate-800 flex flex-col animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="p-4 bg-emerald-800 text-white flex items-center justify-between border-b border-emerald-900">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-amber-300" />
          <h3 className="font-bold text-sm">Pusat Peringatan &amp; Notifikasi</h3>
          <span className="px-2 py-0.5 bg-rose-500 text-white text-[10px] font-extrabold rounded-full">
            {totalAlerts}
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 hover:bg-emerald-700 rounded-lg text-emerald-200 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Content List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        {/* Pending Damage Reports (from students/teachers) */}
        {pendingReports.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-bold text-rose-700 dark:text-rose-400 flex items-center gap-1.5 uppercase text-[11px] tracking-wider">
              <AlertTriangle className="w-3.5 h-3.5" />
              Laporan Kerusakan Baru ({pendingReports.length})
            </h4>
            <div className="space-y-2">
              {pendingReports.map((rep) => (
                <div
                  key={rep.id}
                  className="p-3 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 rounded-xl space-y-1.5"
                >
                  <div className="flex items-start justify-between">
                    <span className="font-bold text-rose-900 dark:text-rose-200">
                      {rep.namaBarang}
                    </span>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-200 dark:bg-rose-900 text-rose-800 dark:text-rose-200">
                      {rep.tingkatKerusakan}
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 text-[11px]">
                    {rep.deskripsiKerusakan}
                  </p>
                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-rose-200/50">
                    <span>Di: {rep.ruanganNama} • Oleh: {rep.pelaporNama}</span>
                    {rep.pelaporKontak && rep.pelaporKontak !== '-' && (
                      <button
                        type="button"
                        onClick={() =>
                          handleSendWaAlert(
                            rep.pelaporKontak,
                            'Konfirmasi Tindak Lanjut Kerusakan',
                            `Halo Bapak/Ibu ${rep.pelaporNama}, laporan kerusakan barang [${rep.namaBarang}] di ${rep.ruanganNama} sedang ditindaklanjuti tim Sarpras.`
                          )
                        }
                        className="text-emerald-700 dark:text-emerald-400 font-bold flex items-center gap-1 hover:underline"
                      >
                        <Smartphone className="w-3 h-3" />
                        WA Pelapor
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Overdue Loans */}
        {overdueLoans.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-bold text-amber-700 dark:text-amber-400 flex items-center gap-1.5 uppercase text-[11px] tracking-wider">
              <Clock className="w-3.5 h-3.5" />
              Peminjaman Terlambat ({overdueLoans.length})
            </h4>
            <div className="space-y-2">
              {overdueLoans.map((loan) => (
                <div
                  key={loan.id}
                  className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-xl space-y-1.5"
                >
                  <div className="flex items-start justify-between">
                    <span className="font-bold text-amber-900 dark:text-amber-200">
                      {loan.namaBarang}
                    </span>
                    <span className="text-[10px] font-bold text-rose-600 bg-rose-100 dark:bg-rose-950 px-1.5 py-0.5 rounded">
                      Rencana: {loan.rencanaKembali}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300">
                    Peminjam: <strong>{loan.peminjam}</strong> ({loan.unitKelas})
                  </p>
                  {loan.noHpPeminjam && (
                    <button
                      type="button"
                      onClick={() =>
                        handleSendWaAlert(
                          loan.noHpPeminjam!,
                          'Peringatan Pengembalian Sarpras MA Assalaam',
                          `Yth. ${loan.peminjam}, mohon segera mengembalikan aset [${loan.namaBarang}] (${loan.kodeBarang}) yang telah melewati batas rencana kembali (${loan.rencanaKembali}).`
                        )
                      }
                      className="w-full mt-1 py-1 px-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[10px] flex items-center justify-center gap-1 transition-colors"
                    >
                      <Smartphone className="w-3 h-3 text-amber-300" />
                      Kirim Peringatan WhatsApp
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Damaged Items */}
        {damagedItems.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 uppercase text-[11px] tracking-wider">
              <Wrench className="w-3.5 h-3.5 text-amber-600" />
              Barang Perlu Servis ({damagedItems.length})
            </h4>
            <div className="space-y-1.5">
              {damagedItems.slice(0, 5).map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    onSelectItem(item);
                    onClose();
                  }}
                  className="p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:border-emerald-500 cursor-pointer transition-colors flex items-center justify-between"
                >
                  <div>
                    <span className="font-bold text-slate-800 dark:text-slate-200 block">
                      {item.namaBarang}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {item.kodeBarang} • {item.ruanganNama}
                    </span>
                  </div>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                      item.kondisi === 'Rusak Berat'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.kondisi}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Missing Photos Warning */}
        {itemsWithoutPhoto.length > 0 && (
          <div className="p-3 bg-slate-100 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CameraOff className="w-4 h-4 text-slate-500" />
              <div>
                <span className="font-bold text-slate-800 dark:text-slate-200 block">
                  Foto Inventaris Belum Lengkap
                </span>
                <span className="text-[10px] text-slate-500">
                  Ada {itemsWithoutPhoto.length} barang belum dilengkapi foto dokumentasi fisik.
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-3 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 text-center">
        <span className="text-[11px] text-slate-500">
          Notifikasi terintegrasi otomatis dengan WhatsApp Webhook
        </span>
      </div>
    </div>
  );
};
