import React from 'react';
import {
  LayoutDashboard,
  Building2,
  Package,
  QrCode,
  ArrowLeftRight,
  ClipboardList,
  Wrench,
  Trash2,
  AlertTriangle,
  BookOpen,
  CheckSquare,
  FileText,
  FileSignature,
  Printer,
  Users,
  Database,
  HelpCircle,
  School,
  Tags
} from 'lucide-react';
import { UserRole } from '../types';

export type ActiveTab =
  | 'dashboard'
  | 'madrasah'
  | 'kategori'
  | 'ruangan'
  | 'barang'
  | 'scan'
  | 'peminjaman'
  | 'mutasi'
  | 'pemeliharaan'
  | 'penghapusan'
  | 'hilang'
  | 'buku'
  | 'stock-opname'
  | 'laporan'
  | 'berita-acara'
  | 'cetak-label'
  | 'cetak-qr-ruangan'
  | 'pengguna'
  | 'backup-sync'
  | 'panduan';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  userRole: UserRole;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  userRole,
  isMobileOpen,
  setIsMobileOpen
}) => {
  interface NavItem {
    id: ActiveTab;
    label: string;
    icon: React.ElementType;
    badge?: string;
    roles: UserRole[];
  }

  const navItems: NavItem[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH', 'USER/GURU']
    },
    {
      id: 'ruangan',
      label: 'Data Ruangan & Denah',
      icon: Building2,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH', 'USER/GURU']
    },
    {
      id: 'barang',
      label: 'Inventaris Barang',
      icon: Package,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH', 'USER/GURU']
    },
    {
      id: 'scan',
      label: 'Scan Barcode & QR',
      icon: QrCode,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH', 'USER/GURU']
    },
    {
      id: 'peminjaman',
      label: 'Peminjaman Barang',
      icon: ClipboardList,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH']
    },
    {
      id: 'mutasi',
      label: 'Mutasi Barang',
      icon: ArrowLeftRight,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH']
    },
    {
      id: 'pemeliharaan',
      label: 'Pemeliharaan / Servis',
      icon: Wrench,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH']
    },
    {
      id: 'penghapusan',
      label: 'Penghapusan Aset',
      icon: Trash2,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH']
    },
    {
      id: 'hilang',
      label: 'Barang Hilang',
      icon: AlertTriangle,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH']
    },
    {
      id: 'buku',
      label: 'Inventaris Buku (Perpus)',
      icon: BookOpen,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH', 'USER/GURU']
    },
    {
      id: 'stock-opname',
      label: 'Stock Opname',
      icon: CheckSquare,
      badge: 'Fisik',
      roles: ['ADMIN', 'PETUGAS INVENTARIS']
    },
    {
      id: 'laporan',
      label: 'Laporan Inventaris',
      icon: FileText,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH']
    },
    {
      id: 'berita-acara',
      label: 'Berita Acara Resmi',
      icon: FileSignature,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH']
    },
    {
      id: 'cetak-label',
      label: 'Cetak Label Barang (5x3)',
      icon: Printer,
      roles: ['ADMIN', 'PETUGAS INVENTARIS']
    },
    {
      id: 'cetak-qr-ruangan',
      label: 'Cetak Label Ruangan (A4)',
      icon: Building2,
      roles: ['ADMIN', 'PETUGAS INVENTARIS']
    },
    {
      id: 'madrasah',
      label: 'Profil Madrasah',
      icon: School,
      roles: ['ADMIN']
    },
    {
      id: 'kategori',
      label: 'Kategori Barang',
      icon: Tags,
      roles: ['ADMIN', 'PETUGAS INVENTARIS']
    },
    {
      id: 'pengguna',
      label: 'Kelola Pengguna',
      icon: Users,
      roles: ['ADMIN']
    },
    {
      id: 'backup-sync',
      label: 'Spreadsheet & Backup',
      icon: Database,
      badge: 'G-Sheet',
      roles: ['ADMIN']
    },
    {
      id: 'panduan',
      label: 'Panduan Penggunaan',
      icon: HelpCircle,
      roles: ['ADMIN', 'PETUGAS INVENTARIS', 'PIMPINAN/KEPALA MADRASAH', 'USER/GURU']
    }
  ];

  const filteredNav = navItems.filter((item) => item.roles.includes(userRole));

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          onClick={() => setIsMobileOpen(false)}
          className="fixed inset-0 z-40 bg-black/50 lg:hidden backdrop-blur-xs"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed lg:static top-[57px] bottom-0 left-0 z-40 w-64 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800 transition-transform duration-300 ease-in-out ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* User Role Card inside sidebar */}
        <div className="p-3 border-b border-slate-800 bg-slate-950/40">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-400">
            <span>Hak Akses:</span>
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                userRole === 'ADMIN'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : userRole === 'PETUGAS INVENTARIS'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : userRole === 'PIMPINAN/KEPALA MADRASAH'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
              }`}
            >
              {userRole}
            </span>
          </div>
        </div>

        {/* Scrollable Nav Items */}
        <div className="flex-1 overflow-y-auto py-2 px-2.5 space-y-1 custom-scrollbar">
          {filteredNav.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsMobileOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors group ${
                  isActive
                    ? 'bg-emerald-700 text-white font-semibold shadow-sm'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-amber-300' : 'text-slate-400 group-hover:text-emerald-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${
                      isActive
                        ? 'bg-amber-400 text-slate-900'
                        : 'bg-slate-800 text-amber-300 border border-amber-500/30'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-slate-800 text-[10px] text-slate-500 text-center">
          <p className="font-semibold text-slate-400">MA ASSALAAM BANDUNG</p>
          <p>Kec. Arjasari • NPSN 20277258</p>
          <p className="text-[9px] text-slate-600 mt-1">v2.5 Production Ready</p>
        </div>
      </aside>
    </>
  );
};
