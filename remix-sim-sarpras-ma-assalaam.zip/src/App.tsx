/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { StorageService } from './services/storage';
import { SpreadsheetSyncService } from './services/spreadsheetSync';
import {
  User,
  SchoolProfile,
  Category,
  Room,
  Item,
  Mutation,
  Loan,
  Maintenance,
  Disposal,
  LostItem,
  LibraryBook,
  DamageReport,
  AuditLog,
  StockOpnameSession
} from './types';

// Components
import { Header } from './components/Header';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { LoginModal } from './components/LoginModal';
import { PublicRoomViewer } from './components/PublicRoomViewer';
import { CameraScannerModal } from './components/CameraScannerModal';
import { NotificationCenter } from './components/NotificationCenter';

// Views
import { DashboardView } from './views/DashboardView';
import { RuanganView } from './views/RuanganView';
import { BarangView } from './views/BarangView';
import { DetailBarangModal } from './views/DetailBarangModal';
import { MutasiView } from './views/MutasiView';
import { PeminjamanView } from './views/PeminjamanView';
import { PemeliharaanView } from './views/PemeliharaanView';
import { PenghapusanView } from './views/PenghapusanView';
import { BarangHilangView } from './views/BarangHilangView';
import { BukuView } from './views/BukuView';
import { StockOpnameView } from './views/StockOpnameView';
import { LaporanView } from './views/LaporanView';
import { BeritaAcaraView } from './views/BeritaAcaraView';
import { CetakLabelView } from './views/CetakLabelView';
import { MasterDataView } from './views/MasterDataView';
import { PenggunaView } from './views/PenggunaView';
import { BackupSyncView } from './views/BackupSyncView';
import { PanduanView } from './views/PanduanView';

export default function App() {
  // Initialize default data if first load
  useEffect(() => {
    StorageService.init();
  }, []);

  // Automated background sync heartbeat for Google Spreadsheet
  useEffect(() => {
    const timer = setInterval(() => {
      StorageService.triggerAutoSync('Sinkronisasi otomatis berkala');
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  // Auth state
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    StorageService.init();
    return StorageService.getCurrentUser();
  });

  // App Theme
  const [darkMode, setDarkMode] = useState<boolean>(false);

  // Mobile sidebar open
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  // Database Data States
  const [schoolProfile, setSchoolProfile] = useState<SchoolProfile>(() => StorageService.getSchoolProfile());
  const [categories, setCategories] = useState<Category[]>(() => StorageService.getCategories());
  const [rooms, setRooms] = useState<Room[]>(() => StorageService.getRooms());
  const [items, setItems] = useState<Item[]>(() => StorageService.getItems());
  const [users, setUsers] = useState<User[]>(() => StorageService.getUsers());
  const [mutations, setMutations] = useState<Mutation[]>(() => StorageService.getMutations());
  const [loans, setLoans] = useState<Loan[]>(() => StorageService.getLoans());
  const [maintenance, setMaintenance] = useState<Maintenance[]>(() => StorageService.getMaintenance());
  const [disposals, setDisposals] = useState<Disposal[]>(() => StorageService.getDisposals());
  const [lostItems, setLostItems] = useState<LostItem[]>(() => StorageService.getLostItems());
  const [books, setBooks] = useState<LibraryBook[]>(() => StorageService.getBooks());
  const [damageReports, setDamageReports] = useState<DamageReport[]>(() => StorageService.getDamageReports());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => StorageService.getAuditLogs());
  const [stockOpnames, setStockOpnames] = useState<StockOpnameSession[]>(() => StorageService.getStockOpnameSessions());

  // Interactive UI Modal States
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isPublicRoomOpen, setIsPublicRoomOpen] = useState(false);
  const [publicRoomTargetId, setPublicRoomTargetId] = useState<string | undefined>(undefined);
  const [selectedDetailItem, setSelectedDetailItem] = useState<Item | null>(null);
  const [labelPrintItems, setLabelPrintItems] = useState<Item[]>([]);
  const [beritaAcaraInitialType, setBeritaAcaraInitialType] = useState<any>('pemeriksaan');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncToast, setSyncToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Auto-sync toast notification listener
  useEffect(() => {
    const handleSyncToast = (e: any) => {
      const detail = e.detail;
      if (detail?.action) {
        setSyncToast({
          message: `Auto-Sync: ${detail.action}`,
          type: 'success'
        });
        setTimeout(() => setSyncToast(null), 3500);
      }
    };
    window.addEventListener('sarpras-spreadsheet-sync', handleSyncToast);
    return () => window.removeEventListener('sarpras-spreadsheet-sync', handleSyncToast);
  }, []);

  // Check URL parameters on initial render or when changed (e.g. mobile camera scans QR code ?ruangan=...)
  useEffect(() => {
    const checkDirectScanUrl = () => {
      try {
        const searchParams = new URLSearchParams(window.location.search);
        const hash = window.location.hash;

        const targetRoomCode = searchParams.get('ruangan') || searchParams.get('room');
        const targetItemCode = searchParams.get('barang') || searchParams.get('item');

        if (targetRoomCode && rooms.length > 0) {
          const cleanCode = decodeURIComponent(targetRoomCode).trim().toLowerCase();
          const foundRoom = rooms.find(
            (r) =>
              r.kodeRuangan.toLowerCase() === cleanCode ||
              r.id.toLowerCase() === cleanCode ||
              r.namaRuangan.toLowerCase().includes(cleanCode)
          );
          if (foundRoom) {
            setPublicRoomTargetId(foundRoom.id);
            setIsPublicRoomOpen(true);
          }
        } else if (targetItemCode && items.length > 0) {
          const cleanItem = decodeURIComponent(targetItemCode).trim().toLowerCase();
          const foundItem = items.find(
            (i) =>
              i.kodeBarang.toLowerCase() === cleanItem ||
              i.id.toLowerCase() === cleanItem
          );
          if (foundItem) {
            setSelectedDetailItem(foundItem);
          }
        } else if (hash.includes('ruangan=')) {
          const match = hash.match(/ruangan=([^&]+)/i);
          if (match && match[1]) {
            const cleanCode = decodeURIComponent(match[1]).trim().toLowerCase();
            const foundRoom = rooms.find(
              (r) =>
                r.kodeRuangan.toLowerCase() === cleanCode ||
                r.id.toLowerCase() === cleanCode
            );
            if (foundRoom) {
              setPublicRoomTargetId(foundRoom.id);
              setIsPublicRoomOpen(true);
            }
          }
        }
      } catch (err) {
        console.warn('Error parsing scan URL parameters:', err);
      }
    };

    checkDirectScanUrl();
    window.addEventListener('popstate', checkDirectScanUrl);
    return () => window.removeEventListener('popstate', checkDirectScanUrl);
  }, [rooms, items]);

  // Initial Central Database synchronization from server on load
  useEffect(() => {
    StorageService.fetchServerDatabase().then((success) => {
      if (success) {
        refreshAllData();
      }
    });

    const handleDatabaseSync = () => {
      refreshAllData();
    };

    window.addEventListener('sarpras-database-synced', handleDatabaseSync);
    return () => window.removeEventListener('sarpras-database-synced', handleDatabaseSync);
  }, []);

  // Ensure current logged-in user is strictly an active registered user in database
  useEffect(() => {
    if (currentUser) {
      const activeUsers = StorageService.getUsers();
      const isValid = activeUsers.some(
        (u) =>
          u.aktif &&
          (u.email.toLowerCase() === currentUser.email.toLowerCase() ||
           u.username.toLowerCase() === currentUser.username.toLowerCase())
      );
      if (!isValid) {
        StorageService.logout();
        setCurrentUser(null);
      }
    }
  }, [users, currentUser]);

  // Reload all state from Storage
  const refreshAllData = () => {
    setSchoolProfile(StorageService.getSchoolProfile());
    setCategories(StorageService.getCategories());
    setRooms(StorageService.getRooms());
    setItems(StorageService.getItems());
    setUsers(StorageService.getUsers());
    setMutations(StorageService.getMutations());
    setLoans(StorageService.getLoans());
    setMaintenance(StorageService.getMaintenance());
    setDisposals(StorageService.getDisposals());
    setLostItems(StorageService.getLostItems());
    setBooks(StorageService.getBooks());
    setDamageReports(StorageService.getDamageReports());
    setAuditLogs(StorageService.getAuditLogs());
    setStockOpnames(StorageService.getStockOpnameSessions());
  };

  // Sync to Spreadsheet button action
  const handleManualSync = async () => {
    setIsSyncing(true);
    setSyncToast({ message: 'Menghubungkan ke Google Spreadsheet...', type: 'info' });
    try {
      const res = await SpreadsheetSyncService.runFullSync();
      refreshAllData();
      StorageService.addAuditLog(currentUser, `Sinkronisasi Google Spreadsheet: ${res.message}`, 'Spreadsheet Sync');
      setSyncToast({
        message: res.message || 'Sinkronisasi dengan Google Spreadsheet selesai!',
        type: res.success ? 'success' : 'info'
      });
      setTimeout(() => setSyncToast(null), 4000);
    } catch (err: any) {
      console.warn('Sync failed:', err);
      setSyncToast({
        message: 'Kendala sinkronisasi: ' + err.message,
        type: 'error'
      });
      setTimeout(() => setSyncToast(null), 4000);
    } finally {
      setIsSyncing(false);
    }
  };

  // Handlers for Save / Delete
  const handleSaveProfile = (newProfile: SchoolProfile) => {
    StorageService.saveSchoolProfile(newProfile, currentUser || undefined);
    setSchoolProfile(newProfile);
  };

  const handleSaveCategories = (newCats: Category[]) => {
    StorageService.saveCategories(newCats, currentUser || undefined);
    setCategories(newCats);
  };

  const handleSaveRoom = async (room: Room) => {
    const existing = rooms.some((r) => r.id === room.id);
    const updated = existing ? rooms.map((r) => (r.id === room.id ? room : r)) : [...rooms, room];
    setRooms(updated);
    await StorageService.saveRooms(updated, currentUser || undefined, room);
  };

  const handleDeleteRoom = async (roomId: string) => {
    if (confirm('Yakin ingin menghapus data ruangan ini?')) {
      const updated = rooms.filter((r) => r.id !== roomId);
      setRooms(updated);
      await StorageService.saveRooms(updated, currentUser || undefined, undefined, roomId);
    }
  };

  const handleSaveItem = (itemOrItems: Item | Item[]) => {
    let updated: Item[] = [];
    if (Array.isArray(itemOrItems)) {
      updated = [...items, ...itemOrItems];
      StorageService.saveItems(
        updated,
        currentUser || undefined,
        `Menambah ${itemOrItems.length} unit aset baru (batch)`
      );
    } else {
      const exists = items.some((i) => i.id === itemOrItems.id);
      updated = exists
        ? items.map((i) => (i.id === itemOrItems.id ? itemOrItems : i))
        : [...items, itemOrItems];
      StorageService.saveItems(
        updated,
        currentUser || undefined,
        `Menyimpan/mengedit data barang: ${itemOrItems.namaBarang}`
      );
    }
    setItems(updated);
  };

  const handleDeleteItem = (itemId: string) => {
    const target = items.find((i) => i.id === itemId);
    if (!target) return;
    if (confirm(`Yakin ingin memindahkan status barang [${target.namaBarang}] ke DIHAPUS?`)) {
      const updated = items.map((i) => (i.id === itemId ? { ...i, status: 'Dihapus' as const } : i));
      StorageService.saveItems(updated, currentUser || undefined, `Soft delete aset: ${target.namaBarang}`);
      setItems(updated);
    }
  };

  const handleSaveMutation = (mut: Mutation) => {
    const updatedMutations = [mut, ...mutations];
    StorageService.saveMutations(updatedMutations, currentUser || undefined);
    setMutations(updatedMutations);

    // Automatically update item room & penanggung jawab
    const updatedItems = items.map((itm) => {
      if (itm.kodeBarang === mut.kodeBarang) {
        return {
          ...itm,
          ruanganId: mut.ruanganTujuanId,
          ruanganNama: mut.ruanganTujuanNama,
          penanggungJawab: mut.penanggungJawabBaru,
          status: 'Tersedia' as const,
          updatedAt: new Date().toISOString()
        };
      }
      return itm;
    });
    StorageService.saveItems(updatedItems, currentUser || undefined, `Mutasi lokasi barang: ${mut.namaBarang} ke ${mut.ruanganTujuanNama}`);
    setItems(updatedItems);
  };

  const handleSaveLoan = (loan: Loan) => {
    const exists = loans.some((l) => l.id === loan.id);
    const updatedLoans = exists ? loans.map((l) => (l.id === loan.id ? loan : l)) : [loan, ...loans];
    StorageService.saveLoans(updatedLoans, currentUser || undefined);
    setLoans(updatedLoans);

    // Update item status if borrowed or returned
    const updatedItems = items.map((itm) => {
      if (itm.kodeBarang === loan.kodeBarang) {
        return {
          ...itm,
          status: (loan.status === 'Dikembalikan' ? 'Tersedia' : 'Dipinjam') as any,
          kondisi: loan.kondisiSaatKembali || itm.kondisi,
          updatedAt: new Date().toISOString()
        };
      }
      return itm;
    });
    StorageService.saveItems(updatedItems, currentUser || undefined);
    setItems(updatedItems);
  };

  const handleSaveMaintenance = (maint: Maintenance) => {
    const updated = [maint, ...maintenance];
    StorageService.saveMaintenance(updated, currentUser || undefined);
    setMaintenance(updated);

    // Update item condition
    const updatedItems = items.map((itm) => {
      if (itm.kodeBarang === maint.kodeBarang) {
        return {
          ...itm,
          kondisi: maint.kondisiSesudah,
          status: 'Tersedia' as const,
          updatedAt: new Date().toISOString()
        };
      }
      return itm;
    });
    StorageService.saveItems(updatedItems, currentUser || undefined, `Penyelesaian servis barang: ${maint.namaBarang}`);
    setItems(updatedItems);
  };

  const handleSaveDisposal = (disp: Disposal) => {
    const updated = [disp, ...disposals];
    StorageService.saveDisposals(updated, currentUser || undefined);
    setDisposals(updated);

    // Soft delete item status to Dihapus
    const updatedItems = items.map((itm) => {
      if (itm.kodeBarang === disp.kodeBarang) {
        return {
          ...itm,
          status: 'Dihapus' as const,
          updatedAt: new Date().toISOString()
        };
      }
      return itm;
    });
    StorageService.saveItems(updatedItems, currentUser || undefined, `Penetapan penghapusan aset: ${disp.namaBarang}`);
    setItems(updatedItems);
  };

  const handleSaveLostItem = (lost: LostItem) => {
    const exists = lostItems.some((l) => l.id === lost.id);
    const updated = exists ? lostItems.map((l) => (l.id === lost.id ? lost : l)) : [lost, ...lostItems];
    StorageService.saveLostItems(updated, currentUser || undefined);
    setLostItems(updated);

    // Update item status to Hilang
    const updatedItems = items.map((itm) => {
      if (itm.kodeBarang === lost.kodeBarang) {
        return {
          ...itm,
          status: (lost.status === 'Ditemukan Kembali' ? 'Tersedia' : 'Hilang') as any,
          updatedAt: new Date().toISOString()
        };
      }
      return itm;
    });
    StorageService.saveItems(updatedItems, currentUser || undefined, `Laporan barang hilang: ${lost.namaBarang}`);
    setItems(updatedItems);
  };

  const handleSaveBook = (book: LibraryBook) => {
    const exists = books.some((b) => b.id === book.id);
    const updated = exists ? books.map((b) => (b.id === book.id ? book : b)) : [book, ...books];
    StorageService.saveBooks(updated, currentUser || undefined);
    setBooks(updated);
  };

  const handleDeleteBook = (bookId: string) => {
    if (confirm('Hapus data buku ini?')) {
      const updated = books.filter((b) => b.id !== bookId);
      StorageService.saveBooks(updated, currentUser || undefined);
      setBooks(updated);
    }
  };

  const handleSaveUser = (user: User) => {
    const exists = users.some((u) => u.id === user.id);
    const updated = exists ? users.map((u) => (u.id === user.id ? user : u)) : [...users, user];
    StorageService.saveUsers(updated, currentUser || undefined);
    setUsers(updated);
  };

  const handleDeleteUser = (userId: string) => {
    const updated = users.filter((u) => u.id !== userId);
    StorageService.saveUsers(updated, currentUser || undefined);
    setUsers(updated);
  };

  const handleSaveStockOpname = (session: StockOpnameSession) => {
    const updated = [session, ...stockOpnames];
    StorageService.saveStockOpnameSessions(updated, currentUser || undefined);
    setStockOpnames(updated);
  };

  // Camera Barcode / QR Detected
  const handleScannerFoundItem = (item: Item) => {
    setIsScannerOpen(false);
    setSelectedDetailItem(item);
  };

  const handleScannerFoundRoom = (room: Room) => {
    setIsScannerOpen(false);
    setPublicRoomTargetId(room.id);
    setIsPublicRoomOpen(true);
  };

  // Notification count
  const damagedCount = items.filter((i) => i.kondisi === 'Rusak Berat' || i.kondisi === 'Rusak Ringan').length;
  const overdueCount = loans.filter((l) => l.status === 'Terlambat').length;
  const pendingReportCount = damageReports.filter((r) => r.status === 'Menunggu Review').length;
  const totalNotifs = damagedCount + overdueCount + pendingReportCount;

  return (
    <div className={`min-h-screen bg-slate-100 ${darkMode ? 'dark bg-slate-950 text-slate-100' : 'text-slate-900'} font-sans`}>
      {/* 1. INITIAL LOGIN MODAL (If Not Logged In) */}
      {!currentUser && (
        <LoginModal
          schoolProfile={schoolProfile}
          onLoginSuccess={(user) => {
            setCurrentUser(user);
          }}
          onOpenPublicRoomScan={() => {
            setPublicRoomTargetId(rooms[0]?.id);
            setIsPublicRoomOpen(true);
          }}
          onDirectScanBarcode={() => {
            setIsScannerOpen(true);
          }}
        />
      )}

      {/* 2. PUBLIC ROOM VIEWER (ACCESSED WITHOUT LOGIN OR VIA QR DOOR SCAN) */}
      {isPublicRoomOpen && (
        <PublicRoomViewer
          rooms={rooms}
          items={items}
          schoolProfile={schoolProfile}
          selectedRoomId={publicRoomTargetId}
          onClose={() => {
            setIsPublicRoomOpen(false);
            setPublicRoomTargetId(undefined);
            try {
              if (window.location.search.includes('ruangan') || window.location.search.includes('room')) {
                window.history.replaceState({}, '', window.location.pathname);
              }
            } catch (e) {}
            refreshAllData();
          }}
          onOpenScanner={() => {
            setIsScannerOpen(true);
          }}
        />
      )}

      {/* 3. MAIN APPLICATION INTERFACE (When User is Logged In) */}
      {currentUser && (
        <div className="flex flex-col min-h-screen">
          <Header
            currentUser={currentUser}
            schoolProfile={schoolProfile}
            onLogout={() => {
              StorageService.logout();
              setCurrentUser(null);
            }}
            onOpenScanner={() => setIsScannerOpen(true)}
            onOpenNotifications={() => setIsNotificationsOpen(true)}
            notificationCount={totalNotifs}
            darkMode={darkMode}
            onToggleDarkMode={() => setDarkMode(!darkMode)}
            onUpdateLogo={(newLogo) => handleSaveProfile({ ...schoolProfile, logoUrl: newLogo })}
            onManualSync={handleManualSync}
            isSyncing={isSyncing}
          />

          <div className="flex flex-1">
            {/* Sidebar */}
            <Sidebar
              activeTab={activeTab}
              setActiveTab={(tab) => {
                if (tab === 'scan') {
                  setIsScannerOpen(true);
                } else {
                  setActiveTab(tab);
                }
              }}
              userRole={currentUser.role}
              isMobileOpen={isMobileNavOpen}
              setIsMobileOpen={setIsMobileNavOpen}
            />

            {/* Main Content View Area */}
            <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto overflow-x-hidden">
              {activeTab === 'dashboard' && (
                <DashboardView
                  items={items}
                  rooms={rooms}
                  categories={categories}
                  loans={loans}
                  mutations={mutations}
                  disposals={disposals}
                  auditLogs={auditLogs}
                  userRole={currentUser.role}
                  schoolProfile={schoolProfile}
                  onUpdateSchoolProfile={handleSaveProfile}
                  onNavigateTab={(tab) => setActiveTab(tab)}
                  onSelectItem={(item) => setSelectedDetailItem(item)}
                />
              )}

              {activeTab === 'ruangan' && (
                <RuanganView
                  rooms={rooms}
                  items={items}
                  userRole={currentUser.role}
                  schoolProfile={schoolProfile}
                  onSaveRoom={handleSaveRoom}
                  onDeleteRoom={handleDeleteRoom}
                  onOpenPublicRoom={(roomId) => {
                    setPublicRoomTargetId(roomId);
                    setIsPublicRoomOpen(true);
                  }}
                  onOpenScanner={() => setIsScannerOpen(true)}
                  onPrintRoomLabel={(room) => {
                    setActiveTab('cetak-qr-ruangan');
                  }}
                />
              )}

              {activeTab === 'barang' && (
                <BarangView
                  items={items}
                  rooms={rooms}
                  categories={categories}
                  userRole={currentUser.role}
                  onSaveItem={handleSaveItem}
                  onDeleteItem={handleDeleteItem}
                  onSelectItem={(item) => setSelectedDetailItem(item)}
                  onPrintSelectedLabels={(selected) => {
                    setLabelPrintItems(selected);
                    setActiveTab('cetak-label');
                  }}
                />
              )}

              {activeTab === 'peminjaman' && (
                <PeminjamanView
                  loans={loans}
                  items={items}
                  userRole={currentUser.role}
                  onSaveLoan={handleSaveLoan}
                  onOpenBeritaAcaraPinjam={(loan) => {
                    setBeritaAcaraInitialType('peminjaman');
                    setActiveTab('berita-acara');
                  }}
                />
              )}

              {activeTab === 'mutasi' && (
                <MutasiView
                  mutations={mutations}
                  items={items}
                  rooms={rooms}
                  userRole={currentUser.role}
                  schoolProfile={schoolProfile}
                  onSaveMutation={handleSaveMutation}
                  onOpenBeritaAcaraMutasi={(m) => {
                    setBeritaAcaraInitialType('mutasi');
                    setActiveTab('berita-acara');
                  }}
                />
              )}

              {activeTab === 'pemeliharaan' && (
                <PemeliharaanView
                  maintenance={maintenance}
                  items={items}
                  userRole={currentUser.role}
                  onSaveMaintenance={handleSaveMaintenance}
                />
              )}

              {activeTab === 'penghapusan' && (
                <PenghapusanView
                  disposals={disposals}
                  items={items}
                  userRole={currentUser.role}
                  schoolProfile={schoolProfile}
                  onSaveDisposal={handleSaveDisposal}
                  onOpenBeritaAcaraHapus={(d) => {
                    setBeritaAcaraInitialType('penghapusan');
                    setActiveTab('berita-acara');
                  }}
                />
              )}

              {activeTab === 'hilang' && (
                <BarangHilangView
                  lostItems={lostItems}
                  items={items}
                  userRole={currentUser.role}
                  onSaveLostItem={handleSaveLostItem}
                />
              )}

              {activeTab === 'buku' && (
                <BukuView
                  books={books}
                  userRole={currentUser.role}
                  onSaveBook={handleSaveBook}
                  onDeleteBook={handleDeleteBook}
                />
              )}

              {activeTab === 'stock-opname' && (
                <StockOpnameView
                  rooms={rooms}
                  items={items}
                  userRole={currentUser.role}
                  schoolProfile={schoolProfile}
                  sessions={stockOpnames}
                  onSaveSession={handleSaveStockOpname}
                />
              )}

              {activeTab === 'laporan' && (
                <LaporanView
                  items={items}
                  rooms={rooms}
                  categories={categories}
                  mutations={mutations}
                  loans={loans}
                  maintenance={maintenance}
                  disposals={disposals}
                  lostItems={lostItems}
                  schoolProfile={schoolProfile}
                  userRole={currentUser.role}
                  onUpdateSchoolProfile={handleSaveProfile}
                />
              )}

              {activeTab === 'berita-acara' && (
                <BeritaAcaraView
                  items={items}
                  rooms={rooms}
                  mutations={mutations}
                  loans={loans}
                  disposals={disposals}
                  schoolProfile={schoolProfile}
                  initialType={beritaAcaraInitialType}
                />
              )}

              {activeTab === 'cetak-label' && (
                <CetakLabelView
                  items={items}
                  rooms={rooms}
                  categories={categories}
                  schoolProfile={schoolProfile}
                  initialSelectedItems={labelPrintItems}
                  mode="barang"
                />
              )}

              {activeTab === 'cetak-qr-ruangan' && (
                <CetakLabelView
                  items={items}
                  rooms={rooms}
                  categories={categories}
                  schoolProfile={schoolProfile}
                  mode="ruangan"
                  onOpenPublicRoom={(roomId) => {
                    setPublicRoomTargetId(roomId);
                    setIsPublicRoomOpen(true);
                  }}
                />
              )}

              {(activeTab === 'madrasah' || activeTab === 'kategori') && (
                <MasterDataView
                  schoolProfile={schoolProfile}
                  categories={categories}
                  userRole={currentUser.role}
                  onSaveProfile={handleSaveProfile}
                  onSaveCategories={handleSaveCategories}
                />
              )}

              {activeTab === 'pengguna' && (
                <PenggunaView
                  users={users}
                  currentUser={currentUser}
                  onSaveUser={handleSaveUser}
                  onDeleteUser={handleDeleteUser}
                />
              )}

              {activeTab === 'backup-sync' && (
                <BackupSyncView
                  currentUser={currentUser}
                  items={items}
                  rooms={rooms}
                  onImportItems={(imported) => {
                    handleSaveItem(imported);
                  }}
                  onRefreshData={refreshAllData}
                />
              )}

              {activeTab === 'panduan' && <PanduanView />}
            </main>
          </div>
        </div>
      )}

      {/* 4. MODALS & DRAWERS */}
      {/* Live Camera Scanner */}
      {isScannerOpen && (
        <CameraScannerModal
          items={items}
          rooms={rooms}
          onFoundItem={handleScannerFoundItem}
          onFoundRoom={handleScannerFoundRoom}
          onClose={() => setIsScannerOpen(false)}
        />
      )}

      {/* Detail Item Card Modal */}
      {selectedDetailItem && (
        <DetailBarangModal
          item={selectedDetailItem}
          mutations={mutations}
          loans={loans}
          maintenance={maintenance}
          userRole={currentUser ? currentUser.role : 'USER/GURU'}
          onClose={() => setSelectedDetailItem(null)}
          onEditItem={(itm) => {
            setSelectedDetailItem(null);
            setActiveTab('barang');
          }}
          onMutateItem={(itm) => {
            setSelectedDetailItem(null);
            setActiveTab('mutasi');
          }}
          onMaintainItem={(itm) => {
            setSelectedDetailItem(null);
            setActiveTab('pemeliharaan');
          }}
          onLoanItem={(itm) => {
            setSelectedDetailItem(null);
            setActiveTab('peminjaman');
          }}
          onPrintLabel={(itm) => {
            setSelectedDetailItem(null);
            setLabelPrintItems([itm]);
            setActiveTab('cetak-label');
          }}
        />
      )}

      {/* Notification Center Drawer */}
      {isNotificationsOpen && (
        <NotificationCenter
          items={items}
          loans={loans}
          lostItems={lostItems}
          damageReports={damageReports}
          onClose={() => setIsNotificationsOpen(false)}
          onSelectItem={(itm) => {
            setSelectedDetailItem(itm);
          }}
        />
      )}

      {/* Floating Sync Toast Notification */}
      {syncToast && (
        <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom-5 duration-300 max-w-md">
          <div className={`p-4 rounded-2xl shadow-2xl flex items-center gap-3 border text-xs font-semibold backdrop-blur-md ${
            syncToast.type === 'error'
              ? 'bg-rose-950/95 text-rose-100 border-rose-700'
              : syncToast.type === 'info'
              ? 'bg-sky-950/95 text-sky-100 border-sky-700'
              : 'bg-emerald-950/95 text-emerald-100 border-emerald-600'
          }`}>
            <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${
              syncToast.type === 'error' ? 'bg-rose-400' : syncToast.type === 'info' ? 'bg-sky-400 animate-ping' : 'bg-emerald-400 animate-pulse'
            }`} />
            <div className="flex-1 leading-snug">
              <span className="font-black block text-[10px] uppercase tracking-wider text-amber-300">
                Google Spreadsheet Auto-Sync
              </span>
              {syncToast.message}
            </div>
            <button
              onClick={() => setSyncToast(null)}
              className="text-slate-400 hover:text-white p-1 rounded-lg text-xs"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
