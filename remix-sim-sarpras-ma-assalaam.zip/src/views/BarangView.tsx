import React, { useState } from 'react';
import {
  Package,
  Plus,
  Search,
  Filter,
  Layers,
  Printer,
  Edit2,
  Trash2,
  Eye,
  Camera,
  Download,
  Upload,
  CheckSquare,
  Sparkles,
  X
} from 'lucide-react';
import { Item, Room, Category, UserRole } from '../types';
import { formatRupiah, generateNextItemCode } from '../services/barcodeGenerator';

interface BarangViewProps {
  items: Item[];
  rooms: Room[];
  categories: Category[];
  userRole: UserRole;
  onSaveItem: (item: Item | Item[]) => void;
  onDeleteItem: (itemId: string) => void;
  onSelectItem: (item: Item) => void;
  onPrintSelectedLabels: (selectedItems: Item[]) => void;
}

export const BarangView: React.FC<BarangViewProps> = ({
  items,
  rooms,
  categories,
  userRole,
  onSaveItem,
  onDeleteItem,
  onSelectItem,
  onPrintSelectedLabels
}) => {
  const currentYear = new Date().getFullYear();

  // Search & Filter State
  const [search, setSearch] = useState('');
  const [filterRuangan, setFilterRuangan] = useState('Semua');
  const [filterKategori, setFilterKategori] = useState('Semua');
  const [filterKondisi, setFilterKondisi] = useState('Semua');
  const [filterStatus, setFilterStatus] = useState('Semua');

  // Checkbox multi-select for bulk label printing
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);

  // Add / Edit Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Item | null>(null);

  // Form Fields
  const [namaBarang, setNamaBarang] = useState('');
  const [kategoriKode, setKategoriKode] = useState(categories[0]?.kode || 'MEU');
  const [merk, setMerk] = useState('');
  const [spesifikasi, setSpesifikasi] = useState('');
  const [nomorSeri, setNomorSeri] = useState('');
  const [tahunPerolehan, setTahunPerolehan] = useState<number>(currentYear);
  const [harga, setHarga] = useState<number>(0);
  const [sumberDana, setSumberDana] = useState<Item['sumberDana']>('BOS');
  const [ruanganId, setRuanganId] = useState(rooms[0]?.id || '');
  const [kondisi, setKondisi] = useState<Item['kondisi']>('Baik');
  const [status, setStatus] = useState<Item['status']>('Tersedia');
  const [keterangan, setKeterangan] = useState('');
  const [fotoBarang, setFotoBarang] = useState('');
  
  // Batch individual quantity generator
  const [quantityCount, setQuantityCount] = useState<number>(1);

  // Filtering
  const filteredItems = items.filter((item) => {
    const q = search.toLowerCase();
    const matchSearch =
      item.namaBarang.toLowerCase().includes(q) ||
      item.kodeBarang.toLowerCase().includes(q) ||
      item.merk.toLowerCase().includes(q) ||
      (item.nomorSeri && item.nomorSeri.toLowerCase().includes(q)) ||
      item.penanggungJawab.toLowerCase().includes(q) ||
      item.ruanganNama.toLowerCase().includes(q);

    const matchRuangan = filterRuangan === 'Semua' || item.ruanganId === filterRuangan;
    const matchKategori = filterKategori === 'Semua' || item.kategori === filterKategori;
    const matchKondisi = filterKondisi === 'Semua' || item.kondisi === filterKondisi;
    const matchStatus = filterStatus === 'Semua' || item.status === filterStatus;

    return matchSearch && matchRuangan && matchKategori && matchKondisi && matchStatus;
  });

  const handleOpenAdd = () => {
    setEditingItem(null);
    setNamaBarang('');
    setKategoriKode(categories[0]?.kode || 'MEU');
    setMerk('');
    setSpesifikasi('');
    setNomorSeri('');
    setTahunPerolehan(currentYear);
    setHarga(1500000);
    setSumberDana('BOS');
    setRuanganId(rooms[0]?.id || '');
    setKondisi('Baik');
    setStatus('Tersedia');
    setKeterangan('');
    setFotoBarang('https://images.unsplash.com/photo-1587831990711-23ca6441447b?w=600&auto=format&fit=crop&q=80');
    setQuantityCount(1);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (itm: Item) => {
    setEditingItem(itm);
    setNamaBarang(itm.namaBarang);
    setKategoriKode(itm.kategoriKode);
    setMerk(itm.merk);
    setSpesifikasi(itm.spesifikasi);
    setNomorSeri(itm.nomorSeri || '');
    setTahunPerolehan(itm.tahunPerolehan);
    setHarga(itm.harga);
    setSumberDana(itm.sumberDana);
    setRuanganId(itm.ruanganId);
    setKondisi(itm.kondisi);
    setStatus(itm.status);
    setKeterangan(itm.keterangan || '');
    setFotoBarang(itm.fotoBarang);
    setQuantityCount(1);
    setIsModalOpen(true);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setFotoBarang(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!namaBarang.trim()) {
      alert('Nama barang wajib diisi!');
      return;
    }

    const targetRoom = rooms.find((r) => r.id === ruanganId) || rooms[0];
    const targetCategory = categories.find((c) => c.kode === kategoriKode) || categories[0];
    const nowIso = new Date().toISOString();

    if (editingItem) {
      // Single Item Edit
      const updated: Item = {
        ...editingItem,
        namaBarang: namaBarang.trim(),
        kategori: targetCategory.nama,
        kategoriKode: targetCategory.kode,
        merk: merk.trim(),
        spesifikasi: spesifikasi.trim(),
        nomorSeri: nomorSeri.trim(),
        tahunPerolehan: Number(tahunPerolehan),
        harga: Number(harga),
        sumberDana,
        ruanganId: targetRoom.id,
        ruanganNama: targetRoom.namaRuangan,
        penanggungJawab: targetRoom.penanggungJawab,
        kondisi,
        status,
        keterangan: keterangan.trim(),
        fotoBarang: fotoBarang || 'https://images.unsplash.com/photo-1587831990711-23ca6441447b?w=600&auto=format&fit=crop&q=80',
        updatedAt: nowIso
      };
      onSaveItem(updated);
    } else {
      // Adding New: Support bulk batch creation with sequential auto-codes
      const existingCodes = items.map((i) => i.kodeBarang);
      const newItems: Item[] = [];
      const qty = Math.max(1, Number(quantityCount) || 1);

      for (let i = 0; i < qty; i++) {
        const nextCode = generateNextItemCode(targetCategory.kode, tahunPerolehan, [
          ...existingCodes,
          ...newItems.map((n) => n.kodeBarang)
        ]);

        newItems.push({
          id: `itm-${Date.now()}-${i}-${Math.floor(Math.random() * 1000)}`,
          kodeBarang: nextCode,
          namaBarang: namaBarang.trim(),
          kategori: targetCategory.nama,
          kategoriKode: targetCategory.kode,
          merk: merk.trim(),
          spesifikasi: spesifikasi.trim(),
          nomorSeri: qty === 1 && nomorSeri ? nomorSeri.trim() : `${nomorSeri || 'SN'}-${i + 1}`,
          tahunPerolehan: Number(tahunPerolehan),
          harga: Number(harga),
          sumberDana,
          ruanganId: targetRoom.id,
          ruanganNama: targetRoom.namaRuangan,
          penanggungJawab: targetRoom.penanggungJawab,
          kondisi,
          status,
          keterangan: keterangan.trim(),
          fotoBarang: fotoBarang || 'https://images.unsplash.com/photo-1587831990711-23ca6441447b?w=600&auto=format&fit=crop&q=80',
          createdAt: nowIso,
          updatedAt: nowIso
        });
      }

      onSaveItem(newItems);
    }

    setIsModalOpen(false);
  };

  const toggleSelectAll = () => {
    if (selectedItemIds.length === filteredItems.length) {
      setSelectedItemIds([]);
    } else {
      setSelectedItemIds(filteredItems.map((i) => i.id));
    }
  };

  const toggleSelectItem = (id: string) => {
    setSelectedItemIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handlePrintSelected = () => {
    const selected = items.filter((i) => selectedItemIds.includes(i.id));
    if (selected.length === 0) {
      alert('Pilih minimal 1 barang melalui centang kotak untuk mencetak label.');
      return;
    }
    onPrintSelectedLabels(selected);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Package className="w-6 h-6 text-emerald-600" />
            Inventaris Sarana &amp; Prasarana Barang
          </h1>
          <p className="text-xs text-slate-500">
            Penomoran otomatis: MAASS-[KAT]-[TAHUN]-[0001]. Setiap aset individual memiliki barcode &amp; QR unik.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {selectedItemIds.length > 0 && (
            <button
              type="button"
              onClick={handlePrintSelected}
              className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer animate-pulse"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak {selectedItemIds.length} Label Terpilih</span>
            </button>
          )}

          {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && (
            <button
              type="button"
              onClick={handleOpenAdd}
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah / Batch Input Barang</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari kode inventaris, nama barang, merk, nomor seri, ruangan..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full md:w-auto">
            {/* Ruangan */}
            <select
              value={filterRuangan}
              onChange={(e) => setFilterRuangan(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-semibold"
            >
              <option value="Semua">Semua Ruangan</option>
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.namaRuangan}
                </option>
              ))}
            </select>

            {/* Kategori */}
            <select
              value={filterKategori}
              onChange={(e) => setFilterKategori(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-semibold"
            >
              <option value="Semua">Semua Kategori</option>
              {categories.map((c) => (
                <option key={c.id} value={c.nama}>
                  {c.nama}
                </option>
              ))}
            </select>

            {/* Kondisi */}
            <select
              value={filterKondisi}
              onChange={(e) => setFilterKondisi(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-semibold"
            >
              <option value="Semua">Semua Kondisi</option>
              <option value="Baik">Baik</option>
              <option value="Rusak Ringan">Rusak Ringan</option>
              <option value="Rusak Berat">Rusak Berat</option>
            </select>

            {/* Status */}
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-semibold"
            >
              <option value="Semua">Semua Status</option>
              <option value="Tersedia">Tersedia</option>
              <option value="Dipinjam">Dipinjam</option>
              <option value="Diperbaiki">Diperbaiki</option>
              <option value="Mutasi">Mutasi</option>
              <option value="Hilang">Hilang</option>
              <option value="Dihapus">Dihapus</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 pt-1 border-t border-slate-100 dark:border-slate-800">
          <span>
            Menampilkan <strong className="text-slate-900 dark:text-white">{filteredItems.length}</strong> dari {items.length} total barang
          </span>
          {selectedItemIds.length > 0 && (
            <span className="text-emerald-700 dark:text-emerald-400 font-bold">
              {selectedItemIds.length} barang terpilih
            </span>
          )}
        </div>
      </div>

      {/* Main Items Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={filteredItems.length > 0 && selectedItemIds.length === filteredItems.length}
                    onChange={toggleSelectAll}
                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  />
                </th>
                <th className="py-3 px-3">Kode Barang</th>
                <th className="py-3 px-3">Nama Barang</th>
                <th className="py-3 px-3">Kategori</th>
                <th className="py-3 px-3">Merk / Spesifikasi</th>
                <th className="py-3 px-3">Tahun</th>
                <th className="py-3 px-3">Harga</th>
                <th className="py-3 px-3">Lokasi Ruangan</th>
                <th className="py-3 px-3">Kondisi</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {filteredItems.map((item, idx) => {
                const isSelected = selectedItemIds.includes(item.id);
                return (
                  <tr
                    key={item.id}
                    className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors ${
                      isSelected ? 'bg-emerald-50/40 dark:bg-emerald-950/20' : ''
                    }`}
                  >
                    <td className="py-2.5 px-3 text-center">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelectItem(item.id)}
                        className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                      />
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-emerald-700 dark:text-emerald-400 whitespace-nowrap">
                      {item.kodeBarang}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-white">
                      <button
                        type="button"
                        onClick={() => onSelectItem(item)}
                        className="hover:text-emerald-600 hover:underline text-left cursor-pointer"
                      >
                        {item.namaBarang}
                      </button>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">{item.kategori}</td>
                    <td className="py-2.5 px-3 text-[11px] text-slate-500 max-w-xs truncate">
                      {item.merk} - {item.spesifikasi}
                    </td>
                    <td className="py-2.5 px-3 font-mono">{item.tahunPerolehan}</td>
                    <td className="py-2.5 px-3 font-mono font-semibold whitespace-nowrap text-slate-900 dark:text-white">
                      {formatRupiah(item.harga)}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap font-medium text-emerald-800 dark:text-emerald-300">
                      {item.ruanganNama}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          item.kondisi === 'Baik'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : item.kondisi === 'Rusak Ringan'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}
                      >
                        {item.kondisi}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400">
                        {item.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right whitespace-nowrap space-x-1">
                      <button
                        type="button"
                        onClick={() => onSelectItem(item)}
                        className="p-1.5 text-slate-500 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                        title="Lihat Detail & Barcode"
                      >
                        <Eye className="w-4 h-4" />
                      </button>

                      {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && (
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                          title="Edit Data Barang"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                      )}

                      {userRole === 'ADMIN' && (
                        <button
                          type="button"
                          onClick={() => onDeleteItem(item.id)}
                          className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                          title="Hapus / Soft Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Barang Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Package className="w-5 h-5 text-emerald-600" />
                {editingItem ? 'Edit Data Barang' : 'Tambah Inventaris Barang (Single / Batch)'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Nama Barang <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. PC Desktop UNBK Core i5"
                    value={namaBarang}
                    onChange={(e) => setNamaBarang(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Kategori Barang
                  </label>
                  <select
                    value={kategoriKode}
                    onChange={(e) => setKategoriKode(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.kode}>
                        {c.nama} ({c.kode})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Merk / Brand
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Lenovo, Epson, Daikin, Olimpic"
                    value={merk}
                    onChange={(e) => setMerk(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Nomor Seri (Serial Number)
                  </label>
                  <input
                    type="text"
                    placeholder="Nomor pabrik / SN"
                    value={nomorSeri}
                    onChange={(e) => setNomorSeri(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Spesifikasi Lengkap
                </label>
                <input
                  type="text"
                  placeholder="Spesifikasi teknis, dimensi, processor, kapasitas..."
                  value={spesifikasi}
                  onChange={(e) => setSpesifikasi(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Tahun Perolehan
                  </label>
                  <input
                    type="number"
                    value={tahunPerolehan}
                    onChange={(e) => setTahunPerolehan(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Harga Perolehan (Rp)
                  </label>
                  <input
                    type="number"
                    value={harga}
                    onChange={(e) => setHarga(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Sumber Dana
                  </label>
                  <select
                    value={sumberDana}
                    onChange={(e) => setSumberDana(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  >
                    <option value="BOS">BOS</option>
                    <option value="Komite / Yayasan">Komite / Yayasan</option>
                    <option value="Bantuan Pemerintah">Bantuan Pemerintah</option>
                    <option value="Hibah / Wakaf">Hibah / Wakaf</option>
                    <option value="Lainnya">Lainnya</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Penempatan Ruangan <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={ruanganId}
                    onChange={(e) => setRuanganId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                  >
                    {rooms.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.namaRuangan} ({r.kodeRuangan})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Kondisi Fisik
                  </label>
                  <select
                    value={kondisi}
                    onChange={(e) => setKondisi(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  >
                    <option value="Baik">Baik</option>
                    <option value="Rusak Ringan">Rusak Ringan</option>
                    <option value="Rusak Berat">Rusak Berat</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  >
                    <option value="Tersedia">Tersedia</option>
                    <option value="Dipinjam">Dipinjam</option>
                    <option value="Mutasi">Mutasi</option>
                    <option value="Diperbaiki">Diperbaiki</option>
                    <option value="Hilang">Hilang</option>
                    <option value="Dihapus">Dihapus</option>
                  </select>
                </div>
              </div>

              {!editingItem && (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-amber-900 dark:text-amber-200 block">
                        Pembuatan Batch Nomor Inventaris Individual:
                      </span>
                      <p className="text-[11px] text-amber-800 dark:text-amber-300">
                        Jika jumlah lebih dari 1, sistem akan membuatkan nomor inventaris individual berurutan otomatis (misal: 0001, 0002, 0003) dengan masing-masing barcode sendiri.
                      </p>
                    </div>
                    <div className="w-24">
                      <input
                        type="number"
                        min="1"
                        max="100"
                        value={quantityCount}
                        onChange={(e) => setQuantityCount(Number(e.target.value))}
                        className="w-full px-2 py-1.5 bg-white dark:bg-slate-800 border border-amber-400 rounded-lg font-bold text-center"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Upload Foto Barang
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="w-full text-xs text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:bg-emerald-100 file:text-emerald-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Keterangan Tambahan
                </label>
                <textarea
                  rows={2}
                  value={keterangan}
                  onChange={(e) => setKeterangan(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-xs"
                >
                  {editingItem ? 'Simpan Perubahan' : `Simpan ${quantityCount} Barang ke Database`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
