import React, { useState } from 'react';
import {
  ClipboardList,
  Plus,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Calendar,
  Smartphone,
  FileSignature,
  User,
  X
} from 'lucide-react';
import { Loan, Item, UserRole } from '../types';
import { StorageService } from '../services/storage';

interface PeminjamanViewProps {
  loans: Loan[];
  items: Item[];
  userRole: UserRole;
  onSaveLoan: (loan: Loan) => void;
  onOpenBeritaAcaraPinjam: (loan: Loan) => void;
}

export const PeminjamanView: React.FC<PeminjamanViewProps> = ({
  loans,
  items,
  userRole,
  onSaveLoan,
  onOpenBeritaAcaraPinjam
}) => {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [returnModalLoan, setReturnModalLoan] = useState<Loan | null>(null);

  // Form Fields for new Loan
  const [peminjam, setPeminjam] = useState('');
  const [unitKelas, setUnitKelas] = useState('Guru Mapel PAI');
  const [noHpPeminjam, setNoHpPeminjam] = useState('');
  const [selectedItemCode, setSelectedItemCode] = useState(items[0]?.kodeBarang || '');
  const [jumlah, setJumlah] = useState<number>(1);
  const [tanggalPinjam, setTanggalPinjam] = useState(new Date().toISOString().split('T')[0]);
  const [rencanaKembali, setRencanaKembali] = useState(
    new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0]
  );
  const [keterangan, setKeterangan] = useState('Untuk kegiatan pembelajaran kurikulum');

  // Return Form Fields
  const [kondisiKembali, setKondisiKembali] = useState<'Baik' | 'Rusak Ringan' | 'Rusak Berat'>('Baik');
  const [catatanKembali, setCatatanKembali] = useState('Barang kembali lengkap dan berfungsi normal');

  const selectedItem = items.find((i) => i.kodeBarang === selectedItemCode) || items[0];

  const filteredLoans = loans.filter((l) => {
    const q = search.toLowerCase();
    return (
      l.nomorPeminjaman.toLowerCase().includes(q) ||
      l.peminjam.toLowerCase().includes(q) ||
      l.namaBarang.toLowerCase().includes(q) ||
      l.kodeBarang.toLowerCase().includes(q) ||
      l.status.toLowerCase().includes(q)
    );
  });

  const handleOpenAdd = () => {
    setPeminjam('');
    setNoHpPeminjam('');
    setIsModalOpen(true);
  };

  const handleCreateLoan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!peminjam.trim() || !selectedItem) return;

    const seq = (loans.length + 1).toString().padStart(3, '0');
    const nomorPeminjaman = `PINJAM/MA-ASS/${new Date().getFullYear()}/${(new Date().getMonth() + 1).toString().padStart(2, '0')}/${seq}`;

    const newLoan: Loan = {
      id: `loan-${Date.now()}`,
      nomorPeminjaman,
      tanggal: new Date().toISOString().split('T')[0],
      peminjam: peminjam.trim(),
      unitKelas: unitKelas.trim(),
      noHpPeminjam: noHpPeminjam.trim(),
      kodeBarang: selectedItem.kodeBarang,
      namaBarang: selectedItem.namaBarang,
      jumlah: Number(jumlah) || 1,
      tanggalPinjam,
      rencanaKembali,
      kondisiSaatPinjam: selectedItem.kondisi,
      status: 'Dipinjam',
      keterangan: keterangan.trim()
    };

    onSaveLoan(newLoan);
    setIsModalOpen(false);
  };

  const handleReturnLoan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!returnModalLoan) return;

    const updated: Loan = {
      ...returnModalLoan,
      status: 'Dikembalikan',
      tanggalPengembalian: new Date().toISOString().split('T')[0],
      kondisiSaatKembali: kondisiKembali,
      keterangan: `${returnModalLoan.keterangan} | Pengembalian: ${catatanKembali}`
    };

    onSaveLoan(updated);
    setReturnModalLoan(null);
  };

  const handleSendWaReminder = (loan: Loan) => {
    if (!loan.noHpPeminjam) {
      alert('Peminjam tidak memiliki nomor WhatsApp tercatat.');
      return;
    }
    const msg = `*PEMBERITAHUAN SARPRAS MA ASSALAAM*\n\n` +
      `Yth. Bapak/Ibu *${loan.peminjam}*,\n` +
      `Mengingatkan mengenai peminjaman inventaris madrasah:\n` +
      `- Barang: ${loan.namaBarang} (${loan.kodeBarang})\n` +
      `- Rencana Pengembalian: ${loan.rencanaKembali}\n\n` +
      `Mohon segera mengembalikan aset tersebut ke ruang Sarpras MA Assalaam dalam kondisi baik. Terima kasih.`;
    StorageService.openWhatsApp(loan.noHpPeminjam, msg);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <ClipboardList className="w-6 h-6 text-emerald-600" />
            Peminjaman Sarana &amp; Prasarana
          </h1>
          <p className="text-xs text-slate-500">
            Monitoring peminjaman laptop, proyektor, peralatan sound &amp; olahraga beserta notifikasi keterlambatan otomatis.
          </p>
        </div>

        {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && (
          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Formulir Peminjaman Baru</span>
          </button>
        )}
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nomor pinjam, nama peminjam, nama barang..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          />
        </div>
      </div>

      {/* Loan List Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">No</th>
                <th className="py-3 px-3">No. Pinjam</th>
                <th className="py-3 px-3">Peminjam</th>
                <th className="py-3 px-3">Barang</th>
                <th className="py-3 px-3">Tgl Pinjam</th>
                <th className="py-3 px-3">Rencana Kembali</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {filteredLoans.map((loan, idx) => (
                <tr key={loan.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 text-slate-400">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-emerald-700 dark:text-emerald-400 whitespace-nowrap">
                    {loan.nomorPeminjaman}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="font-bold text-slate-900 dark:text-white block">
                      {loan.peminjam}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {loan.unitKelas} {loan.noHpPeminjam ? `• ${loan.noHpPeminjam}` : ''}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                    <div>{loan.namaBarang}</div>
                    <span className="font-mono text-[10px] text-slate-400">{loan.kodeBarang}</span>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">{loan.tanggalPinjam}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={`font-semibold ${
                        loan.status === 'Terlambat'
                          ? 'text-rose-600 font-bold'
                          : 'text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {loan.rencanaKembali}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        loan.status === 'Dikembalikan'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : loan.status === 'Terlambat'
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 animate-pulse'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {loan.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right whitespace-nowrap space-x-1">
                    {loan.status !== 'Dikembalikan' && (
                      <button
                        type="button"
                        onClick={() => setReturnModalLoan(loan)}
                        className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                      >
                        Kembalikan
                      </button>
                    )}

                    {loan.noHpPeminjam && (
                      <button
                        type="button"
                        onClick={() => handleSendWaReminder(loan)}
                        className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-bold transition-colors inline-block"
                        title="Kirim Pengingat WhatsApp"
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => onOpenBeritaAcaraPinjam(loan)}
                      className="p-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-[10px] inline-block"
                      title="Cetak Berita Acara Peminjaman"
                    >
                      <FileSignature className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add Loan */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-emerald-600" />
                Input Formulir Peminjaman Barang
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateLoan} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Nama Peminjam <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Dra. Hj. Maryam"
                    value={peminjam}
                    onChange={(e) => setPeminjam(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Unit / Kelas
                  </label>
                  <input
                    type="text"
                    placeholder="Guru Mapel / Kelas X-A"
                    value={unitKelas}
                    onChange={(e) => setUnitKelas(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nomor WhatsApp Peminjam (Untuk notifikasi otomatis)
                </label>
                <input
                  type="tel"
                  placeholder="08xxxxxxxxxx"
                  value={noHpPeminjam}
                  onChange={(e) => setNoHpPeminjam(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Pilih Barang yang Dipinjam <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedItemCode}
                  onChange={(e) => setSelectedItemCode(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                >
                  {items.map((i) => (
                    <option key={i.id} value={i.kodeBarang}>
                      {i.kodeBarang} - {i.namaBarang} ({i.status})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Tanggal Pinjam
                  </label>
                  <input
                    type="date"
                    value={tanggalPinjam}
                    onChange={(e) => setTanggalPinjam(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Rencana Tanggal Kembali <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={rencanaKembali}
                    onChange={(e) => setRencanaKembali(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Keterangan / Keperluan Peminjaman
                </label>
                <textarea
                  rows={2}
                  value={keterangan}
                  onChange={(e) => setKeterangan(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-xs"
                >
                  Simpan Peminjaman
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Return Loan */}
      {returnModalLoan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                Konfirmasi Pengembalian Barang
              </h3>
              <button
                type="button"
                onClick={() => setReturnModalLoan(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleReturnLoan} className="mt-4 space-y-3.5 text-xs">
              <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl space-y-1">
                <div>Barang: <strong>{returnModalLoan.namaBarang}</strong> ({returnModalLoan.kodeBarang})</div>
                <div>Peminjam: <strong>{returnModalLoan.peminjam}</strong></div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Kondisi Saat Dikembalikan
                </label>
                <select
                  value={kondisiKembali}
                  onChange={(e) => setKondisiKembali(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                >
                  <option value="Baik">Baik (Normal)</option>
                  <option value="Rusak Ringan">Rusak Ringan</option>
                  <option value="Rusak Berat">Rusak Berat</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Catatan Pengembalian
                </label>
                <textarea
                  rows={2}
                  value={catatanKembali}
                  onChange={(e) => setCatatanKembali(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReturnModalLoan(null)}
                  className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-xs"
                >
                  Konfirmasi Pengembalian
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
