import React, { useState } from 'react';
import {
  Wrench,
  Plus,
  Search,
  DollarSign,
  User,
  Calendar,
  Camera,
  CheckCircle2,
  X
} from 'lucide-react';
import { Maintenance, Item, UserRole } from '../types';
import { formatRupiah } from '../services/barcodeGenerator';

interface PemeliharaanViewProps {
  maintenance: Maintenance[];
  items: Item[];
  userRole: UserRole;
  onSaveMaintenance: (maint: Maintenance) => void;
}

export const PemeliharaanView: React.FC<PemeliharaanViewProps> = ({
  maintenance,
  items,
  userRole,
  onSaveMaintenance
}) => {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form Fields
  const [selectedItemCode, setSelectedItemCode] = useState(items[0]?.kodeBarang || '');
  const [jenisPerawatan, setJenisPerawatan] = useState<Maintenance['jenisPerawatan']>('Perbaikan Ringan');
  const [kerusakan, setKerusakan] = useState('');
  const [tindakan, setTindakan] = useState('');
  const [biaya, setBiaya] = useState<number>(150000);
  const [teknisi, setTeknisi] = useState('CV. Mandiri Sarpras Bandung');
  const [kondisiSebelum, setKondisiSebelum] = useState<'Baik' | 'Rusak Ringan' | 'Rusak Berat'>('Rusak Ringan');
  const [kondisiSesudah, setKondisiSesudah] = useState<'Baik' | 'Rusak Ringan' | 'Rusak Berat'>('Baik');
  const [keterangan, setKeterangan] = useState('Perawatan berkala aset madrasah');
  const [fotoSebelum, setFotoSebelum] = useState('');
  const [fotoSesudah, setFotoSesudah] = useState('');

  const selectedItem = items.find((i) => i.kodeBarang === selectedItemCode) || items[0];

  const filtered = maintenance.filter((m) => {
    const q = search.toLowerCase();
    return (
      m.nomorPerawatan.toLowerCase().includes(q) ||
      m.namaBarang.toLowerCase().includes(q) ||
      m.kodeBarang.toLowerCase().includes(q) ||
      m.teknisi.toLowerCase().includes(q) ||
      m.jenisPerawatan.toLowerCase().includes(q)
    );
  });

  const totalBiaya = maintenance.reduce((sum, m) => sum + (m.biaya || 0), 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem || !kerusakan.trim()) return;

    const seq = (maintenance.length + 1).toString().padStart(3, '0');
    const nomorPerawatan = `RAWAT/MA-ASS/${new Date().getFullYear()}/${(new Date().getMonth() + 1).toString().padStart(2, '0')}/${seq}`;

    const newMaint: Maintenance = {
      id: `maint-${Date.now()}`,
      nomorPerawatan,
      tanggal: new Date().toISOString().split('T')[0],
      kodeBarang: selectedItem.kodeBarang,
      namaBarang: selectedItem.namaBarang,
      jenisPerawatan,
      kerusakan: kerusakan.trim(),
      tindakan: tindakan.trim() || 'Servis dan kalibrasi unit',
      biaya: Number(biaya) || 0,
      teknisi: teknisi.trim(),
      kondisiSebelum,
      kondisiSesudah,
      fotoSebelum,
      fotoSesudah,
      keterangan: keterangan.trim()
    };

    onSaveMaintenance(newMaint);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Wrench className="w-6 h-6 text-amber-500" />
            Pemeliharaan &amp; Perbaikan Aset Sarpras
          </h1>
          <p className="text-xs text-slate-500">
            Pencatatan riwayat servis berkala, penggantian komponen, dan monitoring biaya pemeliharaan.
          </p>
        </div>

        {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && (
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Catat Servis / Perbaikan</span>
          </button>
        )}
      </div>

      {/* Stats summary */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nomor servis, teknisi, kerusakan..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-3 text-xs">
          <span className="text-slate-500">Total Biaya Pemeliharaan:</span>
          <span className="font-extrabold text-amber-600 dark:text-amber-400 text-sm font-mono">
            {formatRupiah(totalBiaya)}
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">No</th>
                <th className="py-3 px-3">No. Servis</th>
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">Barang</th>
                <th className="py-3 px-3">Jenis Servis</th>
                <th className="py-3 px-3">Kerusakan &amp; Tindakan</th>
                <th className="py-3 px-3">Biaya</th>
                <th className="py-3 px-3">Teknisi</th>
                <th className="py-3 px-3">Hasil Kondisi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {filtered.map((m, idx) => (
                <tr key={m.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 text-slate-400">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-700 dark:text-amber-400 whitespace-nowrap">
                    {m.nomorPerawatan}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">{m.tanggal}</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                    <div>{m.namaBarang}</div>
                    <span className="font-mono text-[10px] text-slate-400">{m.kodeBarang}</span>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap font-medium text-slate-700 dark:text-slate-300">
                    {m.jenisPerawatan}
                  </td>
                  <td className="py-2.5 px-3 max-w-xs">
                    <div className="font-semibold text-rose-700 dark:text-rose-400 truncate">{m.kerusakan}</div>
                    <div className="text-[10px] text-slate-500 truncate">{m.tindakan}</div>
                  </td>
                  <td className="py-2.5 px-3 font-mono font-bold text-slate-900 dark:text-white whitespace-nowrap">
                    {formatRupiah(m.biaya)}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap text-slate-600 dark:text-slate-400">{m.teknisi}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      {m.kondisiSesudah}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Wrench className="w-5 h-5 text-amber-500" />
                Catat Pemeliharaan / Perbaikan Aset
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Pilih Barang <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedItemCode}
                  onChange={(e) => setSelectedItemCode(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                >
                  {items.map((i) => (
                    <option key={i.id} value={i.kodeBarang}>
                      {i.kodeBarang} - {i.namaBarang} (Kondisi: {i.kondisi})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Jenis Perawatan
                  </label>
                  <select
                    value={jenisPerawatan}
                    onChange={(e) => setJenisPerawatan(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  >
                    <option value="Perawatan Rutin">Perawatan Rutin</option>
                    <option value="Perbaikan Ringan">Perbaikan Ringan</option>
                    <option value="Perbaikan Berat">Perbaikan Berat</option>
                    <option value="Kalibrasi">Kalibrasi</option>
                    <option value="Penggantian Suku Cadang">Penggantian Suku Cadang</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Biaya Servis (Rp)
                  </label>
                  <input
                    type="number"
                    value={biaya}
                    onChange={(e) => setBiaya(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Kerusakan / Keluhan <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lampu proyektor redup, printer macet, kabel putus..."
                  value={kerusakan}
                  onChange={(e) => setKerusakan(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Tindakan Perbaikan
                </label>
                <input
                  type="text"
                  placeholder="Tindakan teknis yang dilakukan teknisi"
                  value={tindakan}
                  onChange={(e) => setTindakan(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Nama Teknisi / Bengkel Servis
                  </label>
                  <input
                    type="text"
                    value={teknisi}
                    onChange={(e) => setTeknisi(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Kondisi Sesudah Servis
                  </label>
                  <select
                    value={kondisiSesudah}
                    onChange={(e) => setKondisiSesudah(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold text-emerald-700"
                  >
                    <option value="Baik">Baik (Normal)</option>
                    <option value="Rusak Ringan">Masih Rusak Ringan</option>
                    <option value="Rusak Berat">Rusak Berat (Gagal Servis)</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-xs"
                >
                  Simpan Catatan Servis
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
