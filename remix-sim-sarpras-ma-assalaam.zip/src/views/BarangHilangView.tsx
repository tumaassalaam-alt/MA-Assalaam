import React, { useState } from 'react';
import {
  AlertTriangle,
  Plus,
  Search,
  CheckCircle,
  HelpCircle,
  DollarSign,
  FileText,
  X
} from 'lucide-react';
import { LostItem, Item, UserRole } from '../types';
import { formatRupiah } from '../services/barcodeGenerator';

interface BarangHilangViewProps {
  lostItems: LostItem[];
  items: Item[];
  userRole: UserRole;
  onSaveLostItem: (lost: LostItem) => void;
}

export const BarangHilangView: React.FC<BarangHilangViewProps> = ({
  lostItems,
  items,
  userRole,
  onSaveLostItem
}) => {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form Fields
  const [selectedItemCode, setSelectedItemCode] = useState(items[0]?.kodeBarang || '');
  const [kronologi, setKronologi] = useState('');
  const [tindakLanjut, setTindakLanjut] = useState('Pemeriksaan rekaman CCTV dan koordinasi tim keamanan');
  const [dokumenLaporan, setDokumenLaporan] = useState(`LAP-HILANG/${new Date().getFullYear()}/01`);
  const [status, setStatus] = useState<LostItem['status']>('Dalam Investigasi');

  const selectedItem = items.find((i) => i.kodeBarang === selectedItemCode) || items[0];

  const filtered = lostItems.filter((l) => {
    const q = search.toLowerCase();
    return (
      l.kodeBarang.toLowerCase().includes(q) ||
      l.namaBarang.toLowerCase().includes(q) ||
      l.ruangan.toLowerCase().includes(q) ||
      l.penanggungJawab.toLowerCase().includes(q) ||
      l.status.toLowerCase().includes(q)
    );
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem || !kronologi.trim()) return;

    const newLost: LostItem = {
      id: `lost-${Date.now()}`,
      kodeBarang: selectedItem.kodeBarang,
      namaBarang: selectedItem.namaBarang,
      ruangan: selectedItem.ruanganNama,
      penanggungJawab: selectedItem.penanggungJawab,
      tanggalHilang: new Date().toISOString().split('T')[0],
      kronologi: kronologi.trim(),
      nilaiBarang: selectedItem.harga,
      tindakLanjut: tindakLanjut.trim(),
      dokumenLaporan: dokumenLaporan.trim(),
      status
    };

    onSaveLostItem(newLost);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-amber-500" />
            Penelusuran &amp; Berkas Barang Hilang
          </h1>
          <p className="text-xs text-slate-500">
            Pencatatan investigasi kronologi kehilangan, penanggung jawab aset, dan tindak lanjut ganti rugi / penutupan kasus.
          </p>
        </div>

        {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && (
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Catat Laporan Hilang</span>
          </button>
        )}
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari kode barang, nama, kronologi..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">No</th>
                <th className="py-3 px-3">Kode / Barang</th>
                <th className="py-3 px-3">Lokasi Terakhir</th>
                <th className="py-3 px-3">Penanggung Jawab</th>
                <th className="py-3 px-3">Tgl Hilang</th>
                <th className="py-3 px-3">Nilai Aset</th>
                <th className="py-3 px-3">Kronologi &amp; Tindak Lanjut</th>
                <th className="py-3 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {filtered.map((l, idx) => (
                <tr key={l.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 text-slate-400">{idx + 1}</td>
                  <td className="py-2.5 px-3">
                    <div className="font-bold text-slate-900 dark:text-white">{l.namaBarang}</div>
                    <span className="font-mono text-[10px] text-amber-700 dark:text-amber-400">{l.kodeBarang}</span>
                  </td>
                  <td className="py-2.5 px-3">{l.ruangan}</td>
                  <td className="py-2.5 px-3 font-medium">{l.penanggungJawab}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap">{l.tanggalHilang}</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-slate-900 dark:text-white whitespace-nowrap">
                    {formatRupiah(l.nilaiBarang)}
                  </td>
                  <td className="py-2.5 px-3 max-w-xs">
                    <p className="text-slate-700 dark:text-slate-300 truncate">{l.kronologi}</p>
                    <span className="text-[10px] text-slate-400 block truncate">TL: {l.tindakLanjut}</span>
                  </td>
                  <td className="py-2.5 px-3 text-right whitespace-nowrap">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        l.status === 'Ditemukan Kembali'
                          ? 'bg-emerald-100 text-emerald-800'
                          : l.status === 'Diganti Penanggung Jawab'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {l.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" />
                Catat Berkas Kehilangan Barang
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Pilih Barang yang Hilang <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedItemCode}
                  onChange={(e) => setSelectedItemCode(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                >
                  {items.map((i) => (
                    <option key={i.id} value={i.kodeBarang}>
                      {i.kodeBarang} - {i.namaBarang} ({i.ruanganNama})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Kronologi Kejadian Kehilangan <span className="text-rose-500">*</span>
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Kapan terakhir dilihat, lokasi kegiatan, siapa pemakai terakhir..."
                  value={kronologi}
                  onChange={(e) => setKronologi(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Rencana Tindak Lanjut
                </label>
                <input
                  type="text"
                  value={tindakLanjut}
                  onChange={(e) => setTindakLanjut(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Nomor Dokumen Laporan
                  </label>
                  <input
                    type="text"
                    value={dokumenLaporan}
                    onChange={(e) => setDokumenLaporan(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Status Kasus
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                  >
                    <option value="Dalam Investigasi">Dalam Investigasi</option>
                    <option value="Diganti Penanggung Jawab">Diganti Penanggung Jawab</option>
                    <option value="Dihapus Aset">Dihapus Aset</option>
                    <option value="Ditemukan Kembali">Ditemukan Kembali</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Simpan Laporan Kehilangan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
