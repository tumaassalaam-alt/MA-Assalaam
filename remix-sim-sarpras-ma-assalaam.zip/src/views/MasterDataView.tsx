import React, { useState, useEffect } from 'react';
import {
  School,
  Tags,
  Save,
  Upload,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Building,
  Mail,
  Phone,
  Globe,
  MapPin,
  Calendar,
  X
} from 'lucide-react';
import { SchoolProfile, Category, UserRole, TAHUN_PELAJARAN_LIST } from '../types';

interface MasterDataViewProps {
  schoolProfile: SchoolProfile;
  categories: Category[];
  userRole: UserRole;
  onSaveProfile: (profile: SchoolProfile) => void;
  onSaveCategories: (cats: Category[]) => void;
}

export const MasterDataView: React.FC<MasterDataViewProps> = ({
  schoolProfile,
  categories,
  userRole,
  onSaveProfile,
  onSaveCategories
}) => {
  const [activeTab, setActiveTab] = useState<'madrasah' | 'kategori'>('madrasah');

  // School profile form
  const [profile, setProfile] = useState<SchoolProfile>({ ...schoolProfile });
  const [profileSuccess, setProfileSuccess] = useState(false);

  useEffect(() => {
    setProfile({ ...schoolProfile });
  }, [schoolProfile]);

  // Categories form
  const [categoryList, setCategoryList] = useState<Category[]>([...categories]);
  const [isCatModalOpen, setIsCatModalOpen] = useState(false);
  const [catKode, setCatKode] = useState('');
  const [catNama, setCatNama] = useState('');
  const [catKet, setCatKet] = useState('');

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveProfile(profile);
    setProfileSuccess(true);
    setTimeout(() => setProfileSuccess(false), 2000);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setProfile((prev) => ({ ...prev, logoUrl: event.target?.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catKode.trim() || !catNama.trim()) return;

    const newCat: Category = {
      id: `cat-${Date.now()}`,
      kode: catKode.trim().toUpperCase(),
      nama: catNama.trim(),
      keterangan: catKet.trim()
    };

    const updated = [...categoryList, newCat];
    setCategoryList(updated);
    onSaveCategories(updated);
    setIsCatModalOpen(false);
    setCatKode('');
    setCatNama('');
    setCatKet('');
  };

  const handleDeleteCategory = (catId: string) => {
    if (confirm('Yakin ingin menghapus kategori ini?')) {
      const updated = categoryList.filter((c) => c.id !== catId);
      setCategoryList(updated);
      onSaveCategories(updated);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <School className="w-6 h-6 text-emerald-600" />
            Master Data &amp; Identitas Madrasah
          </h1>
          <p className="text-xs text-slate-500">
            Kelola data legalitas madrasah, logo resmi, alamat kop surat, serta master kategori sarpras.
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveTab('madrasah')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
              activeTab === 'madrasah'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Profil Madrasah
          </button>
          <button
            onClick={() => setActiveTab('kategori')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
              activeTab === 'kategori'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Master Kategori Barang ({categoryList.length})
          </button>
        </div>
      </div>

      {activeTab === 'madrasah' ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs max-w-4xl">
          {profileSuccess && (
            <div className="mb-4 p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 rounded-xl text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Profil Madrasah berhasil disimpan dan kop surat diperbarui!</span>
            </div>
          )}

          <form onSubmit={handleProfileSubmit} className="space-y-4 text-xs">
            {/* Logo Section */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center gap-4">
              <img
                src={profile.logoUrl}
                alt="Logo Madrasah"
                className="w-20 h-20 object-contain rounded-full bg-white p-1 shadow ring-2 ring-emerald-600"
              />
              <div className="space-y-1.5 text-center sm:text-left">
                <span className="font-bold text-slate-900 dark:text-white block">
                  Logo Resmi MA Assalaam (PNG / SVG)
                </span>
                <p className="text-[11px] text-slate-500">
                  Digunakan pada label inventaris 5x3 cm, label pintu A4, dan kop surat berita acara.
                </p>
                <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs transition-colors">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload Logo PNG Baru</span>
                  <input
                    type="file"
                    accept="image/png, image/jpeg, image/svg+xml"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nama Madrasah
                </label>
                <input
                  type="text"
                  required
                  value={profile.namaMadrasah}
                  onChange={(e) => setProfile({ ...profile, namaMadrasah: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Yayasan Penaung
                </label>
                <input
                  type="text"
                  required
                  value={profile.yayasan}
                  onChange={(e) => setProfile({ ...profile, yayasan: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  NPSN
                </label>
                <input
                  type="text"
                  value={profile.npsn}
                  onChange={(e) => setProfile({ ...profile, npsn: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  NSM
                </label>
                <input
                  type="text"
                  value={profile.nsm}
                  onChange={(e) => setProfile({ ...profile, nsm: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  No. Telepon / WA
                </label>
                <input
                  type="text"
                  value={profile.telepon}
                  onChange={(e) => setProfile({ ...profile, telepon: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Kode Pos
                </label>
                <input
                  type="text"
                  value={profile.kodePos}
                  onChange={(e) => setProfile({ ...profile, kodePos: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Alamat Lengkap
                </label>
                <input
                  type="text"
                  value={profile.alamat}
                  onChange={(e) => setProfile({ ...profile, alamat: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Desa
                  </label>
                  <input
                    type="text"
                    value={profile.desa}
                    onChange={(e) => setProfile({ ...profile, desa: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Kecamatan
                  </label>
                  <input
                    type="text"
                    value={profile.kecamatan}
                    onChange={(e) => setProfile({ ...profile, kecamatan: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Kabupaten
                  </label>
                  <input
                    type="text"
                    value={profile.kabupaten}
                    onChange={(e) => setProfile({ ...profile, kabupaten: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Email Resmi Madrasah
                </label>
                <input
                  type="email"
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Website Madrasah
                </label>
                <input
                  type="text"
                  value={profile.website}
                  onChange={(e) => setProfile({ ...profile, website: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>
            </div>

            {/* Tahun Pelajaran Setting Card */}
            <div className="p-4 bg-emerald-50/70 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/80 space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <label className="block font-black text-sm text-emerald-950 dark:text-emerald-200 flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    Tahun Pelajaran (Aktif untuk Kop Surat &amp; Cetak Laporan)
                  </label>
                  <p className="text-[11px] text-emerald-800 dark:text-emerald-300">
                    Pilihan dropdown dari tahun 2025 s/d 2040. Nilai ini menjadi acuan otomatis pada kop surat, laporan inventaris sarpras, dan berita acara madrasah.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={profile.tahunPelajaran || '2025/2026'}
                    onChange={(e) => setProfile({ ...profile, tahunPelajaran: e.target.value })}
                    className="px-4 py-2 bg-white dark:bg-slate-800 border-2 border-emerald-600 rounded-xl font-black text-emerald-900 dark:text-emerald-200 text-sm shadow-xs cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {TAHUN_PELAJARAN_LIST.map((tp) => (
                      <option key={tp} value={tp}>
                        Tahun Pelajaran {tp}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nama Kepala Madrasah
                </label>
                <input
                  type="text"
                  value={profile.kepalaMadrasah}
                  onChange={(e) => setProfile({ ...profile, kepalaMadrasah: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold text-emerald-800 dark:text-emerald-300"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  NIP / NUPTK Kepala Madrasah
                </label>
                <input
                  type="text"
                  value={profile.nipKepalaMadrasah || ''}
                  onChange={(e) => setProfile({ ...profile, nipKepalaMadrasah: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                />
              </div>
            </div>

            {userRole === 'ADMIN' && (
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Simpan Perubahan Profil Madrasah</span>
                </button>
              </div>
            )}
          </form>
        </div>
      ) : (
        /* Kategori Tab */
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-slate-500">
              Master Kategori Penentu Kode Otomatis: MAASS-[KODE_KAT]-[TAHUN]-[0001]
            </span>
            {userRole === 'ADMIN' && (
              <button
                type="button"
                onClick={() => setIsCatModalOpen(true)}
                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Kategori</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {categoryList.map((cat) => (
              <div
                key={cat.id}
                className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between"
              >
                <div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-400 text-slate-950 inline-block mb-1">
                    {cat.kode}
                  </span>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    {cat.nama}
                  </h4>
                  <p className="text-[10px] text-slate-400 truncate max-w-[180px]">
                    {cat.keterangan || '-'}
                  </p>
                </div>

                {userRole === 'ADMIN' && (
                  <button
                    type="button"
                    onClick={() => handleDeleteCategory(cat.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                    title="Hapus Kategori"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal Add Category */}
      {isCatModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                Tambah Kategori Barang
              </h3>
              <button
                type="button"
                onClick={() => setIsCatModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCategory} className="mt-4 space-y-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Kode Singkatan (Maks 4 Huruf, e.g. LAB, ELK) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={4}
                  value={catKode}
                  onChange={(e) => setCatKode(e.target.value.toUpperCase())}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono font-bold uppercase"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nama Kategori <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={catNama}
                  onChange={(e) => setCatNama(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Keterangan
                </label>
                <input
                  type="text"
                  value={catKet}
                  onChange={(e) => setCatKet(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCatModalOpen(false)}
                  className="px-4 py-2 font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl"
                >
                  Simpan Kategori
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
