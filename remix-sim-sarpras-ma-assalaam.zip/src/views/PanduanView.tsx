import React from 'react';
import {
  HelpCircle,
  ShieldCheck,
  Package,
  QrCode,
  Printer,
  ArrowLeftRight,
  ClipboardList,
  CheckSquare,
  FileText,
  Smartphone,
  Database
} from 'lucide-react';

export const PanduanView: React.FC = () => {
  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200 max-w-5xl">
      {/* Header */}
      <div>
        <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
          <HelpCircle className="w-6 h-6 text-emerald-600" />
          Panduan Penggunaan SIM SARPRAS MA ASSALAAM
        </h1>
        <p className="text-xs text-slate-500">
          Petunjuk teknis operasional sistem inventaris untuk Administrator, Petugas Sarpras, Kepala Madrasah, dan Dewan Guru.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {/* Section 1 */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <h3 className="font-extrabold text-sm text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            1. Hak Akses &amp; Otorisasi Pengguna
          </h3>
          <p className="text-slate-600 dark:text-slate-300">
            Sistem memiliki 4 tingkatan hak akses:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-400 text-[11.5px]">
            <li><strong>ADMIN:</strong> Akses penuh kelola seluruh data, pengguna, profil madrasah, backup database, dan cetak semua dokumen.</li>
            <li><strong>PETUGAS INVENTARIS:</strong> Input barang, scan barcode, mutasi lokasi, servis, stok opname, dan cetak label barcode.</li>
            <li><strong>PIMPINAN / KEPALA:</strong> Memantau dashboard statistik, rekapitulasi nilai aset, dan mencetak laporan resmi bertanda tangan.</li>
            <li><strong>USER / GURU:</strong> Melihat inventaris ruangan dan melaporkan kerusakan barang langsung ke tim sarpras.</li>
          </ul>
        </div>

        {/* Section 2 */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <h3 className="font-extrabold text-sm text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
            <Package className="w-4 h-4 text-emerald-600" />
            2. Penomoran Otomatis &amp; Input Batch
          </h3>
          <p className="text-slate-600 dark:text-slate-300">
            Format kode barang terstandar: <code>MAASS-[KAT]-[TAHUN]-[0001]</code>.
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-400 text-[11.5px]">
            <li>Jika membeli barang sejenis dalam jumlah banyak (misal: 20 unit PC), gunakan opsi <strong>Batch Input</strong>.</li>
            <li>Sistem akan otomatis menerbitkan 20 nomor inventaris berurutan unik, masing-masing dengan barcode dan QR code sendiri.</li>
            <li>Foto barang dapat diunggah langsung atau menggunakan kamera smartphone.</li>
          </ul>
        </div>

        {/* Section 3 */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <h3 className="font-extrabold text-sm text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
            <QrCode className="w-4 h-4 text-emerald-600" />
            3. Scan QR Pintu Ruangan Tanpa Login
          </h3>
          <p className="text-slate-600 dark:text-slate-300">
            Guru, santri, atau tamu madrasah dapat memeriksa sarpras tanpa perlu login:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-400 text-[11.5px]">
            <li>Arahkan kamera HP ke QR Code pada label pintu ruangan.</li>
            <li>Daftar seluruh barang, kondisi, dan penanggung jawab ruangan akan langsung terbuka di browser.</li>
            <li>Tersedia tombol <strong>Laporkan Kerusakan</strong> untuk melapor kendala fasilitas yang langsung meneruskan notifikasi otomatis ke WhatsApp Admin.</li>
          </ul>
        </div>

        {/* Section 4 */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <h3 className="font-extrabold text-sm text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
            <Printer className="w-4 h-4 text-emerald-600" />
            4. Cetak Label Barcode &amp; Dokumen Resmi
          </h3>
          <p className="text-slate-600 dark:text-slate-300">
            Sistem menyediakan layout print siap pakai:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-400 text-[11.5px]">
            <li><strong>Label Barang 5 × 3 cm:</strong> Dilengkapi logo MA Assalaam, nama madrasah, barcode visual, dan QR code (grid A4 atau thermal).</li>
            <li><strong>Label Pintu Ruangan A4:</strong> Desain kop resmi untuk ditempel di pintu masuk kelas/laboratorium.</li>
            <li><strong>Berita Acara Resmi:</strong> BA Pemeriksaan, Serah Terima, Mutasi, Peminjaman, Penghapusan, dan Stock Opname.</li>
          </ul>
        </div>

        {/* Section 5 */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <h3 className="font-extrabold text-sm text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
            <CheckSquare className="w-4 h-4 text-emerald-600" />
            5. Alur Stock Opname Fisik Inventaris
          </h3>
          <p className="text-slate-600 dark:text-slate-300">
            Prosedur checklist fisik berkala:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-400 text-[11.5px]">
            <li>Pilih ruangan target pemeriksaan di menu Stock Opname.</li>
            <li>Klik status fisik: Ditemukan / Tidak Ditemukan dan sesuaikan kondisi aktual (Baik / Rusak).</li>
            <li>Sistem otomatis menghitung selisih sistem vs temuan aktual dan menerbitkan Berita Acara Opname.</li>
          </ul>
        </div>

        {/* Section 6 */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <h3 className="font-extrabold text-sm text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-600" />
            6. Sinkronisasi Spreadsheet &amp; WhatsApp
          </h3>
          <p className="text-slate-600 dark:text-slate-300">
            Integrasi cloud Google Spreadsheet:
          </p>
          <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-400 text-[11.5px]">
            <li>Tekan tombol sinkronisasi di header kapan saja untuk sinkronisasi dua arah dengan Google Sheets.</li>
            <li>Tersedia template kode <code>Code.gs</code> untuk dipasang pada Google Apps Script.</li>
            <li>Setiap pelaporan kerusakan dan mutasi otomatis memicu notifikasi peringatan via WhatsApp.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
