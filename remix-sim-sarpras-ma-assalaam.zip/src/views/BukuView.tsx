import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Search,
  Barcode,
  QrCode,
  Tag,
  Layers,
  MapPin,
  X
} from 'lucide-react';
import { LibraryBook, UserRole } from '../types';
import { generateBarcodeSvg } from '../services/barcodeGenerator';

interface BukuViewProps {
  books: LibraryBook[];
  userRole: UserRole;
  onSaveBook: (book: LibraryBook) => void;
  onDeleteBook: (bookId: string) => void;
}

export const BukuView: React.FC<BukuViewProps> = ({
  books,
  userRole,
  onSaveBook,
  onDeleteBook
}) => {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<LibraryBook | null>(null);

  // Form Fields
  const [kodeBuku, setKodeBuku] = useState('');
  const [isbn, setIsbn] = useState('');
  const [judul, setJudul] = useState('');
  const [penulis, setPenulis] = useState('');
  const [penerbit, setPenerbit] = useState('');
  const [tahun, setTahun] = useState<number>(new Date().getFullYear());
  const [kategori, setKategori] = useState('Pelajaran Agama');
  const [jumlah, setJumlah] = useState<number>(30);
  const [lokasiRak, setLokasiRak] = useState('Rak A-01 (Agama)');
  const [kondisi, setKondisi] = useState<LibraryBook['kondisi']>('Baik');

  const filtered = books.filter((b) => {
    const q = search.toLowerCase();
    return (
      b.judul.toLowerCase().includes(q) ||
      b.kodeBuku.toLowerCase().includes(q) ||
      b.isbn.toLowerCase().includes(q) ||
      b.penulis.toLowerCase().includes(q) ||
      b.penerbit.toLowerCase().includes(q) ||
      b.kategori.toLowerCase().includes(q)
    );
  });

  const handleOpenAdd = () => {
    setEditingBook(null);
    setKodeBuku(`BK-MAASS-${Math.floor(100 + Math.random() * 900)}`);
    setIsbn('978-602-');
    setJudul('');
    setPenulis('');
    setPenerbit('Kemenag RI / Erlangga');
    setTahun(new Date().getFullYear());
    setKategori('Pelajaran Agama');
    setJumlah(35);
    setLokasiRak('Rak A-01');
    setKondisi('Baik');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!kodeBuku.trim() || !judul.trim()) return;

    const bookData: LibraryBook = {
      id: editingBook ? editingBook.id : `buk-${Date.now()}`,
      kodeBuku: kodeBuku.trim(),
      isbn: isbn.trim(),
      judul: judul.trim(),
      penulis: penulis.trim(),
      penerbit: penerbit.trim(),
      tahun: Number(tahun),
      kategori,
      jumlah: Number(jumlah) || 1,
      lokasiRak: lokasiRak.trim(),
      kondisi
    };

    onSaveBook(bookData);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-emerald-600" />
            Inventaris Buku &amp; Perpustakaan Digital
          </h1>
          <p className="text-xs text-slate-500">
            Koleksi buku teks utama kurikulum merdeka, kitab kuning, referensi madrasah, dan lokasi penataan rak.
          </p>
        </div>

        {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && (
          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Buku Perpustakaan</span>
          </button>
        )}
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari judul buku, pengarang, ISBN, kode rak..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">No</th>
                <th className="py-3 px-3">Kode Buku</th>
                <th className="py-3 px-3">Judul Buku</th>
                <th className="py-3 px-3">ISBN</th>
                <th className="py-3 px-3">Penulis / Penerbit</th>
                <th className="py-3 px-3">Kategori</th>
                <th className="py-3 px-3">Jumlah</th>
                <th className="py-3 px-3">Lokasi Rak</th>
                <th className="py-3 px-3">Kondisi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {filtered.map((b, idx) => (
                <tr key={b.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 text-slate-400">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-emerald-700 dark:text-emerald-400 whitespace-nowrap">
                    {b.kodeBuku}
                  </td>
                  <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-white">
                    {b.judul}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                    {b.isbn || '-'}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                    <div>{b.penulis}</div>
                    <span className="text-[10px] text-slate-400">{b.penerbit} ({b.tahun})</span>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">{b.kategori}</td>
                  <td className="py-2.5 px-3 font-bold text-emerald-700 dark:text-emerald-400 whitespace-nowrap">
                    {b.jumlah} Eks
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-slate-700 dark:text-slate-300 whitespace-nowrap">
                    {b.lokasiRak}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      {b.kondisi}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-emerald-600" />
                Tambah Buku Perpustakaan
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Kode Buku <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={kodeBuku}
                    onChange={(e) => setKodeBuku(e.target.value.toUpperCase())}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    ISBN
                  </label>
                  <input
                    type="text"
                    value={isbn}
                    onChange={(e) => setIsbn(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Judul Buku <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Fikih Madrasah Aliyah Kelas X"
                  value={judul}
                  onChange={(e) => setJudul(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Nama Penulis
                  </label>
                  <input
                    type="text"
                    value={penulis}
                    onChange={(e) => setPenulis(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Penerbit &amp; Tahun
                  </label>
                  <input
                    type="text"
                    value={penerbit}
                    onChange={(e) => setPenerbit(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Jumlah Eksemplar
                  </label>
                  <input
                    type="number"
                    value={jumlah}
                    onChange={(e) => setJumlah(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Lokasi Rak
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Rak A-01"
                    value={lokasiRak}
                    onChange={(e) => setLokasiRak(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Kondisi
                  </label>
                  <select
                    value={kondisi}
                    onChange={(e) => setKondisi(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  >
                    <option value="Baik">Baik</option>
                    <option value="Rusak Ringan">Rusak Ringan</option>
                    <option value="Rusak Berat">Rusak Berat</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-xs"
                >
                  Simpan Buku
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
