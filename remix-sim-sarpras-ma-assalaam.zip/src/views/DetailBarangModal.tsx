import React, { useEffect, useState } from 'react';
import {
  X,
  Package,
  Calendar,
  DollarSign,
  Building2,
  User,
  ShieldCheck,
  AlertTriangle,
  ArrowLeftRight,
  ClipboardList,
  Wrench,
  Printer,
  Edit,
  Tag,
  Share2
} from 'lucide-react';
import {
  Item,
  Mutation,
  Loan,
  Maintenance,
  UserRole
} from '../types';
import {
  generateBarcodeSvg,
  generateQrDataUrl,
  formatRupiah
} from '../services/barcodeGenerator';

interface DetailBarangModalProps {
  item: Item;
  mutations: Mutation[];
  loans: Loan[];
  maintenance: Maintenance[];
  userRole: UserRole;
  onClose: () => void;
  onEditItem?: (item: Item) => void;
  onMutateItem?: (item: Item) => void;
  onMaintainItem?: (item: Item) => void;
  onLoanItem?: (item: Item) => void;
  onPrintLabel?: (item: Item) => void;
}

export const DetailBarangModal: React.FC<DetailBarangModalProps> = ({
  item,
  mutations,
  loans,
  maintenance,
  userRole,
  onClose,
  onEditItem,
  onMutateItem,
  onMaintainItem,
  onLoanItem,
  onPrintLabel
}) => {
  const [qrUrl, setQrUrl] = useState('');
  const [activeTab, setActiveTab] = useState<'info' | 'mutasi' | 'rawat' | 'pinjam'>('info');

  useEffect(() => {
    generateQrDataUrl(item.kodeBarang).then((url) => setQrUrl(url));
  }, [item.kodeBarang]);

  const itemMutations = mutations.filter((m) => m.kodeBarang === item.kodeBarang);
  const itemLoans = loans.filter((l) => l.kodeBarang === item.kodeBarang);
  const itemMaintenance = maintenance.filter((m) => m.kodeBarang === item.kodeBarang);

  const barcodeSvg = generateBarcodeSvg(item.kodeBarang);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto animate-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="p-5 bg-gradient-to-r from-emerald-800 to-teal-800 text-white flex items-center justify-between border-b border-emerald-900">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl backdrop-blur-xs">
              <Package className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-amber-400 text-slate-950 uppercase font-mono">
                {item.kodeBarang}
              </span>
              <h2 className="text-base font-extrabold text-white mt-0.5">
                {item.namaBarang}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-emerald-200 hover:text-white rounded-lg hover:bg-emerald-700/60"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveTab('info')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeTab === 'info'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Detail Spesifikasi
            </button>
            <button
              onClick={() => setActiveTab('mutasi')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeTab === 'mutasi'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Riwayat Mutasi ({itemMutations.length})
            </button>
            <button
              onClick={() => setActiveTab('rawat')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeTab === 'rawat'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Riwayat Pemeliharaan ({itemMaintenance.length})
            </button>
            <button
              onClick={() => setActiveTab('pinjam')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeTab === 'pinjam'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              Peminjaman ({itemLoans.length})
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            {onPrintLabel && (
              <button
                type="button"
                onClick={() => onPrintLabel(item)}
                className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1 shadow-xs cursor-pointer"
                title="Cetak Label Barcode 5x3 cm"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak Label</span>
              </button>
            )}

            {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && onEditItem && (
              <button
                type="button"
                onClick={() => onEditItem(item)}
                className="px-2.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-lg flex items-center gap-1 shadow-xs cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Content */}
        <div className="p-6 max-h-[70vh] overflow-y-auto custom-scrollbar text-xs">
          {activeTab === 'info' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Photo & Barcodes */}
                <div className="space-y-4">
                  <div className="aspect-video sm:aspect-square rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-inner">
                    <img
                      src={item.fotoBarang || 'https://images.unsplash.com/photo-1587831990711-23ca6441447b?w=600&auto=format&fit=crop&q=80'}
                      alt={item.namaBarang}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* QR & Barcode display */}
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 text-center space-y-2">
                    <div className="flex items-center justify-center gap-3">
                      {qrUrl && (
                        <img
                          src={qrUrl}
                          alt="QR Code"
                          className="w-20 h-20 p-1 bg-white rounded-lg shadow-sm border border-slate-200"
                        />
                      )}
                      <div className="text-left text-[11px] text-slate-500">
                        <span className="font-bold text-slate-800 dark:text-slate-200 block">
                          QR Inventaris
                        </span>
                        <p className="text-[10px]">Pindai untuk membuka detail &amp; lapor kerusakan</p>
                      </div>
                    </div>

                    <div
                      className="flex justify-center p-2 bg-white rounded-lg border border-slate-200 overflow-x-auto"
                      dangerouslySetInnerHTML={{ __html: barcodeSvg }}
                    />
                  </div>
                </div>

                {/* Detailed Information Grid */}
                <div className="md:col-span-2 space-y-4">
                  <div className="grid grid-cols-2 gap-3 p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Kategori</span>
                      <span className="font-bold text-slate-900 dark:text-white flex items-center gap-1">
                        <Tag className="w-3.5 h-3.5 text-emerald-600" />
                        {item.kategori}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Merk / Tipe</span>
                      <span className="font-bold text-slate-900 dark:text-white">{item.merk}</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Nomor Seri (S/N)</span>
                      <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                        {item.nomorSeri || '-'}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Tahun Perolehan</span>
                      <span className="font-bold text-slate-900 dark:text-white">{item.tahunPerolehan}</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Harga Perolehan (Rp)</span>
                      <span className="font-extrabold text-emerald-700 dark:text-emerald-400 text-sm">
                        {formatRupiah(item.harga)}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Sumber Dana</span>
                      <span className="font-bold text-slate-900 dark:text-white">{item.sumberDana}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Lokasi Ruangan</span>
                      <span className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                        {item.ruanganNama}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Penanggung Jawab</span>
                      <span className="font-bold text-slate-900 dark:text-white flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-slate-500" />
                        {item.penanggungJawab}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Kondisi Fisik</span>
                      <span
                        className={`inline-block px-2.5 py-0.5 mt-0.5 rounded-full text-[10px] font-bold ${
                          item.kondisi === 'Baik'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : item.kondisi === 'Rusak Ringan'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}
                      >
                        {item.kondisi}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block">Status Inventaris</span>
                      <span className="inline-block px-2.5 py-0.5 mt-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                        {item.status}
                      </span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block font-semibold mb-1">
                      Spesifikasi Teknis
                    </span>
                    <p className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                      {item.spesifikasi || '-'}
                    </p>
                  </div>

                  {item.keterangan && (
                    <div>
                      <span className="text-[10px] text-slate-400 block font-semibold mb-1">
                        Catatan Tambahan
                      </span>
                      <p className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400">
                        {item.keterangan}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Quick Transaction Buttons for Petugas/Admin */}
              {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && (
                <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-end gap-2">
                  {onMutateItem && (
                    <button
                      type="button"
                      onClick={() => onMutateItem(item)}
                      className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <ArrowLeftRight className="w-3.5 h-3.5" />
                      Mutasi Ruangan
                    </button>
                  )}
                  {onMaintainItem && (
                    <button
                      type="button"
                      onClick={() => onMaintainItem(item)}
                      className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Wrench className="w-3.5 h-3.5" />
                      Catat Servis / Perawatan
                    </button>
                  )}
                  {onLoanItem && (
                    <button
                      type="button"
                      onClick={() => onLoanItem(item)}
                      className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <ClipboardList className="w-3.5 h-3.5" />
                      Pinjamkan Barang
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {activeTab === 'mutasi' && (
            <div className="space-y-3">
              <h3 className="font-bold text-slate-800 dark:text-slate-200 text-xs">
                Riwayat Pemindahan Lokasi / Mutasi Ruangan
              </h3>
              {itemMutations.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  Belum ada riwayat mutasi untuk barang ini.
                </div>
              ) : (
                <div className="space-y-2">
                  {itemMutations.map((m) => (
                    <div
                      key={m.id}
                      className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1"
                    >
                      <div className="flex items-center justify-between text-xs font-bold">
                        <span className="text-emerald-700 dark:text-emerald-400 font-mono">
                          {m.nomorMutasi}
                        </span>
                        <span className="text-slate-400">{m.tanggal}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                        <span className="line-through text-slate-400">{m.ruanganAsalNama}</span>
                        <span>➔</span>
                        <span className="font-bold text-emerald-800 dark:text-emerald-300">{m.ruanganTujuanNama}</span>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Alasan: {m.alasanMutasi} • Petugas: {m.petugas}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'rawat' && (
            <div className="space-y-3">
              <h3 className="font-bold text-slate-800 dark:text-slate-200 text-xs">
                Riwayat Perawatan, Kalibrasi &amp; Servis
              </h3>
              {itemMaintenance.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  Belum ada riwayat pemeliharaan tercatat untuk barang ini.
                </div>
              ) : (
                <div className="space-y-2">
                  {itemMaintenance.map((rawat) => (
                    <div
                      key={rawat.id}
                      className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-xs font-bold">
                        <span className="text-amber-700 dark:text-amber-400 font-mono">
                          {rawat.nomorPerawatan}
                        </span>
                        <span className="text-slate-400">{rawat.tanggal}</span>
                      </div>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">
                        {rawat.jenisPerawatan}: {rawat.kerusakan}
                      </p>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300">
                        Tindakan: {rawat.tindakan} (Biaya: {formatRupiah(rawat.biaya)}) • Teknisi: {rawat.teknisi}
                      </p>
                      <div className="text-[10px] text-slate-400">
                        Kondisi: {rawat.kondisiSebelum} ➔ <strong className="text-emerald-600">{rawat.kondisiSesudah}</strong>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'pinjam' && (
            <div className="space-y-3">
              <h3 className="font-bold text-slate-800 dark:text-slate-200 text-xs">
                Riwayat Peminjaman oleh Guru / Kelas
              </h3>
              {itemLoans.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  Belum ada catatan peminjaman untuk barang ini.
                </div>
              ) : (
                <div className="space-y-2">
                  {itemLoans.map((loan) => (
                    <div
                      key={loan.id}
                      className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1"
                    >
                      <div className="flex items-center justify-between text-xs font-bold">
                        <span className="font-mono text-emerald-700 dark:text-emerald-400">
                          {loan.nomorPeminjaman}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] ${
                            loan.status === 'Dikembalikan'
                              ? 'bg-emerald-100 text-emerald-800'
                              : loan.status === 'Terlambat'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {loan.status}
                        </span>
                      </div>
                      <p className="text-slate-800 dark:text-slate-200 font-semibold">
                        Peminjam: {loan.peminjam} ({loan.unitKelas})
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Pinjam: {loan.tanggalPinjam} • Rencana: {loan.rencanaKembali}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
