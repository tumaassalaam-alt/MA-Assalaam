import React from 'react';
import {
  Package,
  DollarSign,
  Building2,
  CheckCircle,
  AlertTriangle,
  XCircle,
  HelpCircle,
  ClipboardList,
  CheckCheck,
  TrendingUp,
  ArrowDownRight,
  ArrowUpRight,
  Activity,
  Layers,
  BarChart3,
  PieChart,
  Calendar,
  Sparkles
} from 'lucide-react';
import {
  Item,
  Room,
  Category,
  Loan,
  Mutation,
  Disposal,
  AuditLog,
  UserRole,
  SchoolProfile,
  TAHUN_PELAJARAN_LIST
} from '../types';
import { formatRupiah } from '../services/barcodeGenerator';

interface DashboardViewProps {
  items: Item[];
  rooms: Room[];
  categories: Category[];
  loans: Loan[];
  mutations: Mutation[];
  disposals: Disposal[];
  auditLogs: AuditLog[];
  userRole: UserRole;
  schoolProfile?: SchoolProfile;
  onUpdateSchoolProfile?: (profile: SchoolProfile) => void;
  onNavigateTab: (tab: any) => void;
  onSelectItem: (item: Item) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  items,
  rooms,
  categories,
  loans,
  mutations,
  disposals,
  auditLogs,
  userRole,
  schoolProfile,
  onUpdateSchoolProfile,
  onNavigateTab,
  onSelectItem
}) => {
  const currentYear = new Date().getFullYear();
  const activeTp = schoolProfile?.tahunPelajaran || '2025/2026';
  const activeStartYear = parseInt(activeTp.split('/')[0]) || currentYear;
  const activeEndYear = parseInt(activeTp.split('/')[1]) || activeStartYear;

  // Statistics Computations
  const totalBarang = items.length;
  const totalNilaiAset = items.reduce((acc, curr) => acc + (curr.harga || 0), 0);
  const totalRuangan = rooms.length;

  const barangBaik = items.filter((i) => i.kondisi === 'Baik').length;
  const barangRusakRingan = items.filter((i) => i.kondisi === 'Rusak Ringan').length;
  const barangRusakBerat = items.filter((i) => i.kondisi === 'Rusak Berat').length;

  const barangHilang = items.filter((i) => i.status === 'Hilang').length;
  const barangDipinjam = items.filter((i) => i.status === 'Dipinjam').length;
  const barangTersedia = items.filter((i) => i.status === 'Tersedia').length;

  const barangMasukTahunIni = items.filter((i) => i.tahunPerolehan === currentYear).length;
  const barangKeluarTahunIni = disposals.filter((d) => d.tanggal.startsWith(currentYear.toString())).length;

  // Chart Computations:
  // 1. Items by category
  const categoryCounts = categories.map((cat) => {
    const count = items.filter((i) => i.kategori === cat.nama || i.kategoriKode === cat.kode).length;
    const value = items
      .filter((i) => i.kategori === cat.nama || i.kategoriKode === cat.kode)
      .reduce((sum, item) => sum + (item.harga || 0), 0);
    return { name: cat.nama, count, value };
  }).sort((a, b) => b.count - a.count);

  // 2. Items by Room
  const roomCounts = rooms.map((r) => {
    const count = items.filter((i) => i.ruanganId === r.id).length;
    const value = items
      .filter((i) => i.ruanganId === r.id)
      .reduce((sum, item) => sum + (item.harga || 0), 0);
    return { name: r.namaRuangan, kode: r.kodeRuangan, count, value };
  }).sort((a, b) => b.count - a.count);

  // 3. Items by Year
  const yearDistribution: { [year: string]: number } = {};
  items.forEach((item) => {
    const y = item.tahunPerolehan || currentYear;
    yearDistribution[y] = (yearDistribution[y] || 0) + 1;
  });
  const yearSorted = Object.entries(yearDistribution).sort(([a], [b]) => parseInt(a) - parseInt(b));

  const maxCategoryCount = Math.max(...categoryCounts.map((c) => c.count), 1);
  const maxRoomCount = Math.max(...roomCounts.map((r) => r.count), 1);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Welcome Card */}
      <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-900 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-1 bg-amber-400 text-slate-950 text-xs font-black rounded-lg uppercase tracking-wider">
                SIM SARPRAS
              </span>
              <div className="flex items-center gap-1.5 bg-black/30 backdrop-blur-xs border border-white/20 px-2.5 py-1 rounded-xl text-xs font-semibold text-emerald-200">
                <Calendar className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="text-emerald-100 text-xs font-medium">Tahun Pelajaran:</span>
                <select
                  value={activeTp}
                  onChange={(e) => {
                    const newVal = e.target.value;
                    if (onUpdateSchoolProfile && schoolProfile) {
                      onUpdateSchoolProfile({ ...schoolProfile, tahunPelajaran: newVal });
                    }
                  }}
                  className="bg-emerald-950 text-amber-300 font-bold border border-emerald-500/50 rounded-lg px-2 py-0.5 text-xs outline-none cursor-pointer focus:ring-1 focus:ring-amber-400"
                >
                  {TAHUN_PELAJARAN_LIST.map((tp) => (
                    <option key={tp} value={tp} className="bg-slate-900 text-white">
                      TP {tp}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <h1 className="text-2xl font-black text-white mt-1.5">
              {schoolProfile?.namaMadrasah || 'Madrasah Aliyah Assalaam Arjasari'}
            </h1>
            <p className="text-xs text-emerald-100 max-w-2xl mt-1">
              Pusat kendali sarana, prasarana, aset inventaris digital, dan rekapitulasi nilai barang secara real-time.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onNavigateTab('scan')}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4" />
              Scan Barcode / QR
            </button>
            <button
              onClick={() => onNavigateTab('laporan')}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl backdrop-blur-xs border border-white/20 transition-all cursor-pointer"
            >
              Lihat Rekap Laporan
            </button>
          </div>
        </div>

        {/* Subtle Decorative Pattern */}
        <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-6">
          <Layers className="w-64 h-64 text-white" />
        </div>
      </div>

      {/* 11 STATISTIC CARDS */}
      <div>
        <h2 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
          <BarChart3 className="w-4 h-4 text-emerald-600" />
          Statistik Utama Sarana &amp; Prasarana
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* 1. Total Barang */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-emerald-500 transition-all">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
              <span className="text-[11px] font-bold">Total Barang</span>
              <Package className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-white">{totalBarang}</div>
            <span className="text-[10px] text-slate-400">Unit tercatat di sistem</span>
          </div>

          {/* 2. Total Nilai Aset */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-emerald-500 transition-all sm:col-span-2">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
              <span className="text-[11px] font-bold">Total Nilai Aset Sarpras</span>
              <DollarSign className="w-4 h-4 text-amber-500" />
            </div>
            <div className="text-xl font-black text-emerald-700 dark:text-emerald-400">
              {formatRupiah(totalNilaiAset)}
            </div>
            <span className="text-[10px] text-slate-400">Akumulasi perolehan aset madrasah</span>
          </div>

          {/* 3. Total Ruangan */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-emerald-500 transition-all">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
              <span className="text-[11px] font-bold">Total Ruangan</span>
              <Building2 className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-white">{totalRuangan}</div>
            <span className="text-[10px] text-slate-400">Ruang &amp; laboratorium</span>
          </div>

          {/* 4. Barang Baik */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-emerald-500 transition-all">
            <div className="flex items-center justify-between text-emerald-600 mb-1">
              <span className="text-[11px] font-bold">Kondisi Baik</span>
              <CheckCircle className="w-4 h-4" />
            </div>
            <div className="text-xl font-black text-emerald-600">{barangBaik}</div>
            <span className="text-[10px] text-slate-400">
              {totalBarang ? Math.round((barangBaik / totalBarang) * 100) : 0}% prima
            </span>
          </div>

          {/* 5. Rusak Ringan */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-amber-500 transition-all">
            <div className="flex items-center justify-between text-amber-600 mb-1">
              <span className="text-[11px] font-bold">Rusak Ringan</span>
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div className="text-xl font-black text-amber-600">{barangRusakRingan}</div>
            <span className="text-[10px] text-slate-400">Perlu perbaikan kecil</span>
          </div>

          {/* 6. Rusak Berat */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-rose-500 transition-all">
            <div className="flex items-center justify-between text-rose-600 mb-1">
              <span className="text-[11px] font-bold">Rusak Berat</span>
              <XCircle className="w-4 h-4" />
            </div>
            <div className="text-xl font-black text-rose-600">{barangRusakBerat}</div>
            <span className="text-[10px] text-slate-400">Tidak dapat difungsikan</span>
          </div>

          {/* 7. Hilang */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-purple-500 transition-all">
            <div className="flex items-center justify-between text-purple-600 mb-1">
              <span className="text-[11px] font-bold">Barang Hilang</span>
              <HelpCircle className="w-4 h-4" />
            </div>
            <div className="text-xl font-black text-purple-600">{barangHilang}</div>
            <span className="text-[10px] text-slate-400">Dalam penelusuran</span>
          </div>

          {/* 8. Dipinjam */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-indigo-500 transition-all">
            <div className="flex items-center justify-between text-indigo-600 mb-1">
              <span className="text-[11px] font-bold">Dipinjam</span>
              <ClipboardList className="w-4 h-4" />
            </div>
            <div className="text-xl font-black text-indigo-600">{barangDipinjam}</div>
            <span className="text-[10px] text-slate-400">Sedang dipinjam guru/unit</span>
          </div>

          {/* 9. Tersedia */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-teal-500 transition-all">
            <div className="flex items-center justify-between text-teal-600 mb-1">
              <span className="text-[11px] font-bold">Tersedia</span>
              <CheckCheck className="w-4 h-4" />
            </div>
            <div className="text-xl font-black text-teal-600">{barangTersedia}</div>
            <span className="text-[10px] text-slate-400">Siap digunakan di ruangan</span>
          </div>

          {/* 10. Masuk Tahun Ini */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-emerald-500 transition-all">
            <div className="flex items-center justify-between text-emerald-600 mb-1">
              <span className="text-[11px] font-bold">Masuk {currentYear}</span>
              <ArrowDownRight className="w-4 h-4" />
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-white">{barangMasukTahunIni}</div>
            <span className="text-[10px] text-slate-400">Pengadaan baru</span>
          </div>

          {/* 11. Keluar / Dihapus Tahun Ini */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:border-rose-500 transition-all">
            <div className="flex items-center justify-between text-rose-600 mb-1">
              <span className="text-[11px] font-bold">Keluar {currentYear}</span>
              <ArrowUpRight className="w-4 h-4" />
            </div>
            <div className="text-xl font-black text-slate-900 dark:text-white">{barangKeluarTahunIni}</div>
            <span className="text-[10px] text-slate-400">Penghapusan aset</span>
          </div>
        </div>
      </div>

      {/* VISUAL CHARTS & ANALYTICS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Kategori Barang Breakdown */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-emerald-600" />
              Jumlah Barang Berdasarkan Kategori
            </h3>
            <span className="text-[10px] text-slate-400">{categories.length} Kategori</span>
          </div>

          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1 custom-scrollbar">
            {categoryCounts.slice(0, 8).map((cat, idx) => {
              const pct = Math.round((cat.count / maxCategoryCount) * 100);
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-800 dark:text-slate-200">{cat.name}</span>
                    <span className="text-emerald-700 dark:text-emerald-400 font-mono">
                      {cat.count} unit ({formatRupiah(cat.value)})
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Kondisi Barang Breakdown */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <PieChart className="w-4 h-4 text-amber-500" />
                Kondisi Fisik Sarana &amp; Prasarana
              </h3>
              <span className="text-[10px] text-slate-400">Total {totalBarang} Item</span>
            </div>

            {/* Visual Condition Progress Bar */}
            <div className="w-full h-4 rounded-full overflow-hidden flex shadow-inner bg-slate-100 dark:bg-slate-800 mb-4">
              <div
                style={{ width: `${totalBarang ? (barangBaik / totalBarang) * 100 : 0}%` }}
                className="bg-emerald-500 transition-all"
                title={`Baik: ${barangBaik}`}
              />
              <div
                style={{ width: `${totalBarang ? (barangRusakRingan / totalBarang) * 100 : 0}%` }}
                className="bg-amber-400 transition-all"
                title={`Rusak Ringan: ${barangRusakRingan}`}
              />
              <div
                style={{ width: `${totalBarang ? (barangRusakBerat / totalBarang) * 100 : 0}%` }}
                className="bg-rose-500 transition-all"
                title={`Rusak Berat: ${barangRusakBerat}`}
              />
            </div>

            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900">
                <span className="text-[10px] text-emerald-800 dark:text-emerald-300 font-bold block">
                  Kondisi Baik
                </span>
                <span className="text-lg font-black text-emerald-600">{barangBaik}</span>
                <span className="text-[10px] text-slate-400 block">
                  {totalBarang ? Math.round((barangBaik / totalBarang) * 100) : 0}%
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900">
                <span className="text-[10px] text-amber-800 dark:text-amber-300 font-bold block">
                  Rusak Ringan
                </span>
                <span className="text-lg font-black text-amber-600">{barangRusakRingan}</span>
                <span className="text-[10px] text-slate-400 block">
                  {totalBarang ? Math.round((barangRusakRingan / totalBarang) * 100) : 0}%
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900">
                <span className="text-[10px] text-rose-800 dark:text-rose-300 font-bold block">
                  Rusak Berat
                </span>
                <span className="text-lg font-black text-rose-600">{barangRusakBerat}</span>
                <span className="text-[10px] text-slate-400 block">
                  {totalBarang ? Math.round((barangRusakBerat / totalBarang) * 100) : 0}%
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-500">Jadwal Servis Berkala:</span>
            <span className="font-semibold text-emerald-700 dark:text-emerald-400">Setiap Awal Semester &amp; Ujian</span>
          </div>
        </div>

        {/* Jumlah Barang per Ruangan */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-blue-600" />
              Jumlah Barang &amp; Nilai Aset per Ruangan
            </h3>
            <button
              onClick={() => onNavigateTab('ruangan')}
              className="text-[11px] font-bold text-emerald-600 hover:underline"
            >
              Lihat Denah Ruangan →
            </button>
          </div>

          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1 custom-scrollbar">
            {roomCounts.slice(0, 6).map((room, idx) => {
              const pct = Math.round((room.count / maxRoomCount) * 100);
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-800 dark:text-slate-200">
                      {room.name} <span className="text-slate-400 font-normal">({room.kode})</span>
                    </span>
                    <span className="text-slate-700 dark:text-slate-300 font-mono">
                      {room.count} unit ({formatRupiah(room.value)})
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-blue-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tren Perolehan & Riwayat Aktivitas Audit */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-amber-500" />
                Aktivitas Audit Terbaru (Log Otomatis)
              </h3>
              <span className="text-[10px] text-slate-400">Keamanan Terproteksi</span>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto pr-1 custom-scrollbar text-xs">
              {auditLogs.slice(0, 5).map((log) => (
                <div
                  key={log.id}
                  className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 space-y-0.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {log.aktivitas}
                    </span>
                    <span className="text-[10px] text-slate-400">{log.jam}</span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                    <span>Oleh: {log.userName}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 font-mono">
                      {log.modul}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-500">Total Transaksi Mutasi &amp; Peminjaman:</span>
            <span className="font-bold text-emerald-700 dark:text-emerald-400">
              {mutations.length} Mutasi • {loans.length} Pinjam
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
