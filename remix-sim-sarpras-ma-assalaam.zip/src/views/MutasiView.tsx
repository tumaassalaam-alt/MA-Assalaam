import React, { useState } from 'react';
import {
  ArrowLeftRight,
  Plus,
  Search,
  Calendar,
  FileSignature,
  Building2,
  Package,
  User,
  CheckCircle,
  X
} from 'lucide-react';
import { Mutation, Item, Room, UserRole, SchoolProfile } from '../types';

interface MutasiViewProps {
  mutations: Mutation[];
  items: Item[];
  rooms: Room[];
  userRole: UserRole;
  schoolProfile: SchoolProfile;
  onSaveMutation: (mut: Mutation) => void;
  onOpenBeritaAcaraMutasi: (mut: Mutation) => void;
}

export const MutasiView: React.FC<MutasiViewProps> = ({
  mutations,
  items,
  rooms,
  userRole,
  schoolProfile,
  onSaveMutation,
  onOpenBeritaAcaraMutasi
}) => {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form Fields
  const [selectedItemCode, setSelectedItemCode] = useState(items[0]?.kodeBarang || '');
  const [ruanganTujuanId, setRuanganTujuanId] = useState(rooms[1]?.id || rooms[0]?.id || '');
  const [alasanMutasi, setAlasanMutasi] = useState('');
  const [petugas, setPetugas] = useState('Bambang Supriyanto (Petugas Sarpras)');
  const [keterangan, setKeterangan] = useState('Disetujui untuk operasional pembelajaran');

  const selectedItem = items.find((i) => i.kodeBarang === selectedItemCode) || items[0];

  const filteredMutations = mutations.filter((m) => {
    const q = search.toLowerCase();
    return (
      m.nomorMutasi.toLowerCase().includes(q) ||
      m.namaBarang.toLowerCase().includes(q) ||
      m.kodeBarang.toLowerCase().includes(q) ||
      m.ruanganAsalNama.toLowerCase().includes(q) ||
      m.ruanganTujuanNama.toLowerCase().includes(q)
    );
  });

  const handleOpenAdd = () => {
    if (items.length === 0) {
      alert('Tidak ada barang untuk dimutasi.');
      return;
    }
    setSelectedItemCode(items[0].kodeBarang);
    setRuanganTujuanId(rooms.find((r) => r.id !== items[0].ruanganId)?.id || rooms[0].id);
    setAlasanMutasi('');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;

    const targetRoom = rooms.find((r) => r.id === ruanganTujuanId);
    if (!targetRoom) return;

    if (targetRoom.id === selectedItem.ruanganId) {
      alert('Ruangan tujuan tidak boleh sama dengan ruangan asal!');
      return;
    }

    const todayStr = new Date().toISOString().split('T')[0];
    const seq = (mutations.length + 1).toString().padStart(3, '0');
    const nomorMutasi = `MUT/MA-ASS/${new Date().getFullYear()}/${(new Date().getMonth() + 1).toString().padStart(2, '0')}/${seq}`;

    const newMutation: Mutation = {
      id: `mut-${Date.now()}`,
      nomorMutasi,
      tanggal: todayStr,
      kodeBarang: selectedItem.kodeBarang,
      namaBarang: selectedItem.namaBarang,
      ruanganAsalId: selectedItem.ruanganId,
      ruanganAsalNama: selectedItem.ruanganNama,
      ruanganTujuanId: targetRoom.id,
      ruanganTujuanNama: targetRoom.namaRuangan,
      penanggungJawabLama: selectedItem.penanggungJawab,
      penanggungJawabBaru: targetRoom.penanggungJawab,
      alasanMutasi: alasanMutasi.trim() || 'Pemenuhan kebutuhan sarana ruangan',
      petugas: petugas.trim(),
      keterangan: keterangan.trim()
    };

    onSaveMutation(newMutation);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <ArrowLeftRight className="w-6 h-6 text-emerald-600" />
            Mutasi &amp; Pemindahan Lokasi Barang
          </h1>
          <p className="text-xs text-slate-500">
            Pencatatan perpindahan sarpras antar-ruangan. Lokasi dan penanggung jawab barang otomatis terbarukan di database.
          </p>
        </div>

        {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && (
          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Catat Mutasi Baru</span>
          </button>
        )}
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nomor mutasi, kode barang, ruangan..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          />
        </div>
      </div>

      {/* Mutation Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">No</th>
                <th className="py-3 px-3">No. Mutasi</th>
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">Barang</th>
                <th className="py-3 px-3">Ruangan Asal</th>
                <th className="py-3 px-3">Ruangan Tujuan</th>
                <th className="py-3 px-3">Alasan Mutasi</th>
                <th className="py-3 px-3">Petugas</th>
                <th className="py-3 px-3 text-right">Berita Acara</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {filteredMutations.map((m, idx) => (
                <tr key={m.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 text-slate-400">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-emerald-700 dark:text-emerald-400 whitespace-nowrap">
                    {m.nomorMutasi}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">{m.tanggal}</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                    <div>{m.namaBarang}</div>
                    <span className="font-mono text-[10px] text-slate-400">{m.kodeBarang}</span>
                  </td>
                  <td className="py-2.5 px-3 text-rose-700 dark:text-rose-400 font-medium">
                    {m.ruanganAsalNama}
                  </td>
                  <td className="py-2.5 px-3 text-emerald-700 dark:text-emerald-400 font-bold">
                    {m.ruanganTujuanNama}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300 max-w-xs truncate">
                    {m.alasanMutasi}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">{m.petugas}</td>
                  <td className="py-2.5 px-3 text-right whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => onOpenBeritaAcaraMutasi(m)}
                      className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors ml-auto cursor-pointer"
                    >
                      <FileSignature className="w-3 h-3 text-emerald-600" />
                      Cetak Berita Acara
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add Mutasi */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <ArrowLeftRight className="w-5 h-5 text-emerald-600" />
                Catat Mutasi / Pemindahan Barang
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Pilih Barang yang Dimutasi <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedItemCode}
                  onChange={(e) => setSelectedItemCode(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                >
                  {items.map((i) => (
                    <option key={i.id} value={i.kodeBarang}>
                      {i.kodeBarang} - {i.namaBarang} (Saat ini di: {i.ruanganNama})
                    </option>
                  ))}
                </select>
              </div>

              {selectedItem && (
                <div className="p-3 bg-slate-100 dark:bg-slate-800/60 rounded-xl space-y-1 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Ruangan Asal:</span>
                    <strong className="text-rose-700 dark:text-rose-400">{selectedItem.ruanganNama}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">PJ Saat Ini:</span>
                    <strong>{selectedItem.penanggungJawab}</strong>
                  </div>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Ruangan Tujuan Baru <span className="text-rose-500">*</span>
                </label>
                <select
                  value={ruanganTujuanId}
                  onChange={(e) => setRuanganTujuanId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold text-emerald-800 dark:text-emerald-300"
                >
                  {rooms.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.namaRuangan} ({r.kodeRuangan}) - PJ: {r.penanggungJawab}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Alasan Pemindahan / Mutasi <span className="text-rose-500">*</span>
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="e.g. Pembagian fasilitas untuk kelas baru atau rotasi laboratorium..."
                  value={alasanMutasi}
                  onChange={(e) => setAlasanMutasi(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nama Petugas Pelaksana
                </label>
                <input
                  type="text"
                  value={petugas}
                  onChange={(e) => setPetugas(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-xs"
                >
                  Simpan &amp; Perbarui Ruangan Barang
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
