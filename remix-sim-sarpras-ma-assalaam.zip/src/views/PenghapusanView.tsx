import React, { useState } from 'react';
import {
  Trash2,
  Plus,
  Search,
  FileSignature,
  AlertOctagon,
  Calendar,
  DollarSign,
  ShieldCheck,
  X
} from 'lucide-react';
import { Disposal, Item, UserRole, SchoolProfile } from '../types';
import { formatRupiah } from '../services/barcodeGenerator';

interface PenghapusanViewProps {
  disposals: Disposal[];
  items: Item[];
  userRole: UserRole;
  schoolProfile: SchoolProfile;
  onSaveDisposal: (disp: Disposal) => void;
  onOpenBeritaAcaraHapus: (disp: Disposal) => void;
}

export const PenghapusanView: React.FC<PenghapusanViewProps> = ({
  disposals,
  items,
  userRole,
  schoolProfile,
  onSaveDisposal,
  onOpenBeritaAcaraHapus
}) => {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form Fields
  const [selectedItemCode, setSelectedItemCode] = useState(items[0]?.kodeBarang || '');
  const [alasanPenghapusan, setAlasanPenghapusan] = useState('Rusak berat permanen & tidak bernilai ekonomis');
  const [metodePenghapusan, setMetodePenghapusan] = useState<Disposal['metodePenghapusan']>('Pemusnahan');
  const [dokumenSK, setDokumenSK] = useState(`SK-HAPUS-MAASS/${new Date().getFullYear()}/01`);
  const [keterangan, setKeterangan] = useState('Penghapusan disetujui Pengurus Yayasan dan Kepala Madrasah');

  const selectedItem = items.find((i) => i.kodeBarang === selectedItemCode) || items[0];

  const filtered = disposals.filter((d) => {
    const q = search.toLowerCase();
    return (
      d.nomorPenghapusan.toLowerCase().includes(q) ||
      d.namaBarang.toLowerCase().includes(q) ||
      d.kodeBarang.toLowerCase().includes(q) ||
      d.alasanPenghapusan.toLowerCase().includes(q) ||
      d.metodePenghapusan.toLowerCase().includes(q)
    );
  });

  const totalNilaiDihapus = disposals.reduce((sum, d) => sum + (d.hargaPerolehan || 0), 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;

    const seq = (disposals.length + 1).toString().padStart(3, '0');
    const nomorPenghapusan = `HAPUS/MA-ASS/${new Date().getFullYear()}/${(new Date().getMonth() + 1).toString().padStart(2, '0')}/${seq}`;

    const newDisp: Disposal = {
      id: `disp-${Date.now()}`,
      nomorPenghapusan,
      tanggal: new Date().toISOString().split('T')[0],
      kodeBarang: selectedItem.kodeBarang,
      namaBarang: selectedItem.namaBarang,
      tahunPerolehan: selectedItem.tahunPerolehan,
      hargaPerolehan: selectedItem.harga,
      kondisiTerakhir: selectedItem.kondisi,
      alasanPenghapusan: alasanPenghapusan.trim(),
      metodePenghapusan,
      persetujuan: `${schoolProfile.kepalaMadrasah} (Kepala Madrasah)`,
      dokumenSK: dokumenSK.trim(),
      keterangan: keterangan.trim()
    };

    onSaveDisposal(newDisp);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Trash2 className="w-6 h-6 text-rose-600" />
            Penghapusan Aset &amp; Barang Afkir
          </h1>
          <p className="text-xs text-slate-500">
            Penghapusan aset (soft delete terproteksi). Data riwayat aset tetap tersimpan permanen dalam buku inventaris historis.
          </p>
        </div>

        {(userRole === 'ADMIN' || userRole === 'PETUGAS INVENTARIS') && (
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="px-3.5 py-2 bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Proses Penghapusan Aset</span>
          </button>
        )}
      </div>

      {/* Summary */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nomor SK, nama barang yang dihapus..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-3 text-xs">
          <span className="text-slate-500">Total Nilai Aset Dihapus:</span>
          <span className="font-extrabold text-rose-600 text-sm font-mono">
            {formatRupiah(totalNilaiDihapus)}
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">No</th>
                <th className="py-3 px-3">No. Penghapusan</th>
                <th className="py-3 px-3">Tanggal</th>
                <th className="py-3 px-3">Barang</th>
                <th className="py-3 px-3">Tahun / Nilai</th>
                <th className="py-3 px-3">Metode</th>
                <th className="py-3 px-3">Alasan</th>
                <th className="py-3 px-3">Persetujuan</th>
                <th className="py-3 px-3 text-right">Berita Acara</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {filtered.map((d, idx) => (
                <tr key={d.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 text-slate-400">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-rose-700 dark:text-rose-400 whitespace-nowrap">
                    {d.nomorPenghapusan}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">{d.tanggal}</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                    <div>{d.namaBarang}</div>
                    <span className="font-mono text-[10px] text-slate-400">{d.kodeBarang}</span>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <div>Thn {d.tahunPerolehan}</div>
                    <span className="font-mono text-slate-400">{formatRupiah(d.hargaPerolehan)}</span>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {d.metodePenghapusan}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 max-w-xs truncate">{d.alasanPenghapusan}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap text-emerald-700 dark:text-emerald-400 font-medium">
                    {d.persetujuan}
                  </td>
                  <td className="py-2.5 px-3 text-right whitespace-nowrap">
                    <button
                      type="button"
                      onClick={() => onOpenBeritaAcaraHapus(d)}
                      className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors ml-auto cursor-pointer"
                    >
                      <FileSignature className="w-3 h-3 text-rose-600" />
                      Cetak Berita Acara
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-rose-700 dark:text-rose-400 flex items-center gap-2">
                <AlertOctagon className="w-5 h-5" />
                Penetapan Penghapusan Aset Inventaris
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Pilih Barang yang Dihapus <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedItemCode}
                  onChange={(e) => setSelectedItemCode(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                >
                  {items.map((i) => (
                    <option key={i.id} value={i.kodeBarang}>
                      {i.kodeBarang} - {i.namaBarang} ({formatRupiah(i.harga)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Metode Penghapusan
                  </label>
                  <select
                    value={metodePenghapusan}
                    onChange={(e) => setMetodePenghapusan(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-semibold"
                  >
                    <option value="Pemusnahan">Pemusnahan</option>
                    <option value="Lelang">Lelang</option>
                    <option value="Hibah / Donasi">Hibah / Donasi</option>
                    <option value="Tukar Menukar">Tukar Menukar</option>
                    <option value="Daur Ulang">Daur Ulang</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Nomor Dokumen SK / Berita Acara
                  </label>
                  <input
                    type="text"
                    value={dokumenSK}
                    onChange={(e) => setDokumenSK(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Alasan Penghapusan Aset <span className="text-rose-500">*</span>
                </label>
                <textarea
                  required
                  rows={2}
                  value={alasanPenghapusan}
                  onChange={(e) => setAlasanPenghapusan(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-900 text-[11px] text-rose-800 dark:text-rose-300">
                Peringatan: Status barang akan diubah menjadi <strong>DIHAPUS</strong>. Barang tidak akan hilang dari database buku inventaris historis madrasah.
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-xl shadow-xs"
                >
                  Konfirmasi Penghapusan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
