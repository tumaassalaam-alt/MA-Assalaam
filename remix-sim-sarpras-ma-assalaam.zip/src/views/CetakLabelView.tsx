import React, { useState, useEffect } from 'react';
import {
  Printer,
  Package,
  Building2,
  Filter,
  CheckSquare,
  Sparkles,
  Download,
  Layers,
  Eye,
  ExternalLink
} from 'lucide-react';
import { Item, Room, Category, SchoolProfile } from '../types';
import {
  generateBarcodeSvg,
  generateQrDataUrl,
  getRoomDoorScanUrl,
  getItemScanUrl
} from '../services/barcodeGenerator';

interface CetakLabelViewProps {
  items: Item[];
  rooms: Room[];
  categories: Category[];
  schoolProfile: SchoolProfile;
  initialSelectedItems?: Item[];
  mode?: 'barang' | 'ruangan';
  onOpenPublicRoom?: (roomId: string) => void;
}

export const CetakLabelView: React.FC<CetakLabelViewProps> = ({
  items,
  rooms,
  categories,
  schoolProfile,
  initialSelectedItems = [],
  mode = 'barang',
  onOpenPublicRoom
}) => {
  const [filterType, setFilterType] = useState<'all' | 'selected' | 'room' | 'category'>(
    initialSelectedItems.length > 0 ? 'selected' : 'all'
  );
  const [targetRoomId, setTargetRoomId] = useState<string>(rooms[0]?.id || '');
  const [selectedDoorRoomId, setSelectedDoorRoomId] = useState<string>('all');
  const [targetCategory, setTargetCategory] = useState<string>(categories[0]?.nama || '');
  const [selectedIds, setSelectedIds] = useState<string[]>(
    initialSelectedItems.map((i) => i.id)
  );

  // QR URLs cache mapped by text
  const [qrCache, setQrCache] = useState<{ [key: string]: string }>({});

  // Active items to print
  let itemsToPrint: Item[] = [];
  if (filterType === 'all') {
    itemsToPrint = items;
  } else if (filterType === 'selected') {
    itemsToPrint = items.filter((i) => selectedIds.includes(i.id));
  } else if (filterType === 'room') {
    itemsToPrint = items.filter((i) => i.ruanganId === targetRoomId);
  } else if (filterType === 'category') {
    itemsToPrint = items.filter((i) => i.kategori === targetCategory);
  }

  // Pre-generate QR codes for print view
  useEffect(() => {
    async function loadQrs() {
      const newCache: { [key: string]: string } = {};
      for (const item of itemsToPrint) {
        if (!qrCache[item.kodeBarang]) {
          const itemUrl = getItemScanUrl(item.kodeBarang);
          newCache[item.kodeBarang] = await generateQrDataUrl(itemUrl);
        }
      }
      for (const room of rooms) {
        if (!qrCache[room.kodeRuangan]) {
          // Encodes full live URL so any smartphone camera connects directly to room inventory!
          const doorUrl = getRoomDoorScanUrl(room.kodeRuangan);
          newCache[room.kodeRuangan] = await generateQrDataUrl(doorUrl);
        }
      }
      setQrCache((prev) => ({ ...prev, ...newCache }));
    }
    loadQrs();
  }, [itemsToPrint, rooms]);

  const displayedRooms =
    selectedDoorRoomId === 'all'
      ? rooms
      : rooms.filter((r) => r.id === selectedDoorRoomId);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Screen Controls Header (Hidden on print) */}
      <div className="no-print bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Printer className="w-6 h-6 text-emerald-600" />
              {mode === 'barang' ? 'Cetak Label Barcode Inventaris (5 × 3 cm)' : 'Cetak Label Pintu Ruangan (A4)'}
            </h1>
            <p className="text-xs text-slate-500">
              Format siap print pada kertas stiker / HVS A4 dengan logo MA Assalaam dan QR Code terverifikasi.
            </p>
          </div>

          <button
            onClick={handlePrint}
            className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer hover:scale-105"
          >
            <Printer className="w-4 h-4 text-amber-300" />
            <span>Mulai Cetak / Print Sekarang</span>
          </button>
        </div>

        {mode === 'barang' ? (
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="font-bold text-slate-700 dark:text-slate-300">Pilihan Cetak:</span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setFilterType('all')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                  filterType === 'all'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                Cetak Semua Barang ({items.length})
              </button>

              <button
                type="button"
                onClick={() => setFilterType('room')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                  filterType === 'room'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                Berdasarkan Ruangan
              </button>

              <button
                type="button"
                onClick={() => setFilterType('category')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                  filterType === 'category'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                Berdasarkan Kategori
              </button>

              <button
                type="button"
                onClick={() => setFilterType('selected')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                  filterType === 'selected'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                Barang Terpilih ({selectedIds.length})
              </button>
            </div>

            {filterType === 'room' && (
              <select
                value={targetRoomId}
                onChange={(e) => setTargetRoomId(e.target.value)}
                className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-bold"
              >
                {rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.namaRuangan} ({r.kodeRuangan})
                  </option>
                ))}
              </select>
            )}

            {filterType === 'category' && (
              <select
                value={targetCategory}
                onChange={(e) => setTargetCategory(e.target.value)}
                className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-bold"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.nama}>
                    {c.nama}
                  </option>
                ))}
              </select>
            )}
          </div>
        ) : (
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="font-bold text-slate-700 dark:text-slate-300">Pilih Ruangan:</span>
            <select
              value={selectedDoorRoomId}
              onChange={(e) => setSelectedDoorRoomId(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-bold text-emerald-800 dark:text-emerald-300"
            >
              <option value="all">Tampilkan Semua Label Ruangan ({rooms.length} Ruang)</option>
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.namaRuangan} ({r.kodeRuangan}) - {r.gedung}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* PRINT CANVAS AREA */}
      {mode === 'barang' ? (
        <div>
          <div className="no-print mb-2 text-xs font-bold text-slate-500 flex items-center justify-between">
            <span>Pratinjau Layout Kertas A4 (Grid 3 Kolom × Stiker 5 × 3 cm):</span>
            <span>Total {itemsToPrint.length} Label Siap Cetak</span>
          </div>

          {itemsToPrint.length === 0 ? (
            <div className="p-12 text-center text-slate-400 bg-white dark:bg-slate-900 rounded-3xl border">
              Tidak ada barang yang dipilih untuk dicetak.
            </div>
          ) : (
            <div className="print-area bg-white p-6 shadow-sm border rounded-2xl max-w-5xl mx-auto">
              {/* Responsive / Print Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 print:grid-cols-3 print:gap-2">
                {itemsToPrint.map((item) => {
                  const barcodeSvg = generateBarcodeSvg(item.kodeBarang);
                  const qr = qrCache[item.kodeBarang];

                  return (
                    <div
                      key={item.id}
                      className="border-2 border-emerald-800 rounded-xl p-2.5 bg-white text-slate-900 flex flex-col justify-between h-[155px] shadow-2xs print:border-slate-800 print:shadow-none print:break-inside-avoid print:p-2"
                      style={{ pageBreakInside: 'avoid' }}
                    >
                      {/* Label Header */}
                      <div className="flex items-center gap-1.5 border-b border-emerald-800 pb-1">
                        <img
                          src={schoolProfile.logoUrl}
                          alt="Logo"
                          className="w-6 h-6 object-contain shrink-0"
                        />
                        <div className="leading-tight overflow-hidden">
                          <span className="text-[9px] font-black text-emerald-900 block truncate">
                            MADRASAH ALIYAH ASSALAAM
                          </span>
                          <span className="text-[7.5px] text-slate-600 block truncate font-medium">
                            INVENTARIS SARPRAS • SASAKGANTUNG
                          </span>
                        </div>
                      </div>

                      {/* Main Label Body */}
                      <div className="flex items-center justify-between gap-1 my-1">
                        <div className="flex-1 overflow-hidden pr-1">
                          <span className="text-[10px] font-black text-slate-950 block truncate">
                            {item.namaBarang}
                          </span>
                          <span className="text-[8.5px] text-slate-600 block truncate">
                            Merk: {item.merk}
                          </span>
                          <span className="text-[8px] font-bold text-emerald-800 block truncate mt-0.5">
                            Lokasi: {item.ruanganNama}
                          </span>
                        </div>

                        {qr && (
                          <img
                            src={qr}
                            alt="QR"
                            className="w-12 h-12 shrink-0 border border-slate-200 p-0.5"
                          />
                        )}
                      </div>

                      {/* Barcode Visual & Code */}
                      <div className="border-t border-slate-200 pt-1 text-center">
                        <div
                          className="flex justify-center max-h-[30px] overflow-hidden"
                          dangerouslySetInnerHTML={{ __html: barcodeSvg }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* ROOM DOOR LABEL PRINT (A4 LAYOUT) */
        <div className="print-area space-y-8">
          {displayedRooms.map((room) => {
            const qr = qrCache[room.kodeRuangan];
            const roomItems = items.filter((i) => i.ruanganId === room.id || i.ruanganNama === room.namaRuangan);
            const doorUrl = getRoomDoorScanUrl(room.kodeRuangan);

            return (
              <div
                key={room.id}
                className="bg-white p-10 max-w-3xl mx-auto rounded-3xl border-4 border-emerald-800 text-slate-900 shadow-md print:shadow-none print:border-4 print:border-black print:p-8 print:m-0 print:max-w-none print:w-full print:break-after-page"
                style={{ pageBreakAfter: 'always' }}
              >
                {/* Official Letterhead */}
                <div className="flex items-center justify-center gap-5 border-b-4 border-emerald-800 pb-5 text-center">
                  <img
                    src={schoolProfile.logoUrl}
                    alt="Logo MA Assalaam"
                    className="w-20 h-20 object-contain"
                  />
                  <div>
                    <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-900">
                      {schoolProfile.yayasan}
                    </h3>
                    <h2 className="text-2xl font-black text-emerald-950 uppercase tracking-wide">
                      {schoolProfile.namaMadrasah}
                    </h2>
                    <p className="text-xs text-slate-600 font-medium">
                      {schoolProfile.alamat}, Desa {schoolProfile.desa}, Kec. {schoolProfile.kecamatan}, Kab. {schoolProfile.kabupaten} {schoolProfile.kodePos}
                    </p>
                    <p className="text-[11px] text-slate-500 font-mono">
                      NPSN: {schoolProfile.npsn} | NSM: {schoolProfile.nsm}
                    </p>
                  </div>
                </div>

                {/* Big Room Identification */}
                <div className="my-8 text-center space-y-2">
                  <span className="text-xs font-black tracking-widest uppercase text-emerald-700 bg-emerald-50 px-4 py-1.5 rounded-full border border-emerald-200">
                    LABEL IDENTIFIKASI PINTU RUANGAN
                  </span>
                  <h1 className="text-3xl font-black text-slate-900 uppercase pt-2">
                    {room.namaRuangan}
                  </h1>
                  <div className="inline-block font-mono text-xl font-extrabold bg-amber-400 text-slate-950 px-6 py-1.5 rounded-2xl shadow-sm">
                    KODE: {room.kodeRuangan}
                  </div>
                </div>

                {/* Details Table */}
                <div className="grid grid-cols-2 gap-4 max-w-lg mx-auto bg-slate-50 p-5 rounded-2xl border border-slate-200 text-xs my-6">
                  <div>
                    <span className="text-slate-500 block">Gedung &amp; Lantai:</span>
                    <span className="font-bold text-slate-900 text-sm">{room.gedung}, {room.lantai}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Penanggung Jawab:</span>
                    <span className="font-bold text-emerald-800 text-sm">{room.penanggungJawab}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Kapasitas / Luas:</span>
                    <span className="font-bold text-slate-900">{room.kapasitas} Orang / {room.luasRuangan} m²</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Total Inventaris:</span>
                    <span className="font-bold text-slate-900">{roomItems.length} Unit Barang</span>
                  </div>
                </div>

                {/* Large QR Code with Scan Instructions */}
                <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-emerald-700 rounded-3xl bg-emerald-50/50 max-w-md mx-auto text-center space-y-3">
                  {qr && (
                    <div
                      className="cursor-pointer group relative"
                      onClick={() => onOpenPublicRoom && onOpenPublicRoom(room.id)}
                      title="Klik untuk langsung membuka daftar inventaris ruangan ini"
                    >
                      <img
                        src={qr}
                        alt="QR Ruangan"
                        className="w-48 h-48 p-2 bg-white rounded-2xl shadow-md border border-slate-300 group-hover:scale-105 transition-transform"
                      />
                      <div className="no-print absolute inset-0 bg-emerald-900/60 rounded-2xl flex flex-col items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity p-2">
                        <Eye className="w-8 h-8 text-amber-300 mb-1" />
                        <span className="text-[11px] font-bold text-center">Klik Buka Inventaris</span>
                      </div>
                    </div>
                  )}

                  <div>
                    <span className="text-sm font-extrabold text-emerald-900 block">
                      PINDAI QR CODE PINTU RUANGAN
                    </span>
                    <p className="text-xs text-slate-600 max-w-xs mt-1">
                      Arahkan kamera HP untuk langsung melihat daftar inventaris seluruh barang di ruangan ini &amp; lapor kerusakan tanpa login.
                    </p>
                  </div>

                  {/* Direct Test Button for Instant Connection */}
                  {onOpenPublicRoom && (
                    <button
                      type="button"
                      onClick={() => onOpenPublicRoom(room.id)}
                      className="no-print mt-2 py-2 px-4 bg-emerald-700 hover:bg-emerald-600 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer hover:scale-105"
                    >
                      <Eye className="w-4 h-4 text-amber-300" />
                      <span>Buka Daftar Inventaris Ruangan Ini ({roomItems.length} Barang)</span>
                    </button>
                  )}

                  <span className="text-[9px] font-mono text-slate-400 block max-w-xs truncate pt-1">
                    Target: {doorUrl}
                  </span>
                </div>

                {/* Footer Sign */}
                <div className="mt-8 pt-6 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                  <span>Dicetak otomatis melalui SIM SARPRAS MA ASSALAAM</span>
                  <span>Kepala Madrasah: <strong>{schoolProfile.kepalaMadrasah}</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
