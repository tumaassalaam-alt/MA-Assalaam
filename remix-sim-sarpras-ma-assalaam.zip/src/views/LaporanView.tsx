import React, { useState } from 'react';
import {
  FileText,
  Printer,
  Download,
  Filter,
  Calendar,
  Layers,
  Building2,
  DollarSign,
  User,
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';
import * as XLSX from 'xlsx';
import {
  Item,
  Room,
  Category,
  Mutation,
  Loan,
  Maintenance,
  Disposal,
  LostItem,
  SchoolProfile,
  UserRole,
  TAHUN_PELAJARAN_LIST
} from '../types';
import { formatRupiah } from '../services/barcodeGenerator';

interface LaporanViewProps {
  items: Item[];
  rooms: Room[];
  categories: Category[];
  mutations: Mutation[];
  loans: Loan[];
  maintenance: Maintenance[];
  disposals: Disposal[];
  lostItems: LostItem[];
  schoolProfile: SchoolProfile;
  userRole: UserRole;
  onUpdateSchoolProfile?: (profile: SchoolProfile) => void;
}

export const LaporanView: React.FC<LaporanViewProps> = ({
  items,
  rooms,
  categories,
  mutations,
  loans,
  maintenance,
  disposals,
  lostItems,
  schoolProfile,
  userRole,
  onUpdateSchoolProfile
}) => {
  const currentYear = new Date().getFullYear();

  // Selected Report Type (15 types)
  const [reportType, setReportType] = useState<string>('seluruh');

  // Active Tahun Pelajaran for Letterhead and Filter
  const [selectedTahunPelajaran, setSelectedTahunPelajaran] = useState<string>(
    schoolProfile?.tahunPelajaran || '2025/2026'
  );

  // Sync if schoolProfile prop updates
  React.useEffect(() => {
    if (schoolProfile?.tahunPelajaran) {
      setSelectedTahunPelajaran(schoolProfile.tahunPelajaran);
    }
  }, [schoolProfile?.tahunPelajaran]);

  // Filters
  const [filterRuangan, setFilterRuangan] = useState('Semua');
  const [filterKategori, setFilterKategori] = useState('Semua');
  const [filterKondisi, setFilterKondisi] = useState('Semua');
  const [filterTahun, setFilterTahun] = useState('Semua');

  const reportOptions = [
    { id: 'seluruh', label: '1. Laporan Seluruh Buku Inventaris Barang' },
    { id: 'ruangan', label: '2. Laporan Inventaris per Ruangan (KIR)' },
    { id: 'kategori', label: '3. Laporan Inventaris per Kategori' },
    { id: 'tahun', label: '4. Laporan per Tahun Pelajaran / Perolehan' },
    { id: 'kondisi', label: '5. Laporan Kondisi Barang (Baik / Rusak)' },
    { id: 'rusak', label: '6. Laporan Khusus Barang Rusak' },
    { id: 'hilang', label: '7. Laporan Rekap Barang Hilang' },
    { id: 'dipinjam', label: '8. Laporan Peminjaman Sarpras' },
    { id: 'mutasi', label: '9. Laporan Riwayat Mutasi Barang' },
    { id: 'pemeliharaan', label: '10. Laporan Biaya & Pemeliharaan' },
    { id: 'penghapusan', label: '11. Laporan Penghapusan Aset' },
    { id: 'nilai_aset', label: '12. Laporan Rekapitulasi Nilai Aset' },
    { id: 'penanggung_jawab', label: '13. Laporan per Penanggung Jawab' },
    { id: 'sumber_dana', label: '14. Laporan per Sumber Dana' },
    { id: 'rekap_sarpras', label: '15. Rekapitulasi Umum Sarpras Madrasah' }
  ];

  // Base item filtering
  const filteredItems = items.filter((item) => {
    const matchRoom = filterRuangan === 'Semua' || item.ruanganId === filterRuangan;
    const matchCat = filterKategori === 'Semua' || item.kategori === filterKategori;
    const matchKondisi = filterKondisi === 'Semua' || item.kondisi === filterKondisi;
    
    let matchTahun = true;
    if (filterTahun !== 'Semua') {
      if (filterTahun.includes('/')) {
        const parts = filterTahun.split('/');
        matchTahun = item.tahunPerolehan.toString() === parts[0] || item.tahunPerolehan.toString() === parts[1];
      } else {
        matchTahun = item.tahunPerolehan.toString() === filterTahun;
      }
    }

    if (reportType === 'rusak') {
      return (item.kondisi === 'Rusak Ringan' || item.kondisi === 'Rusak Berat') && matchRoom && matchCat;
    }
    if (reportType === 'dipinjam') {
      return item.status === 'Dipinjam' && matchRoom;
    }

    return matchRoom && matchCat && matchKondisi && matchTahun;
  });

  const totalNilaiFiltered = filteredItems.reduce((acc, curr) => acc + (curr.harga || 0), 0);

  // Export this active report table to Excel (.xlsx)
  const handleExportExcel = () => {
    let exportData: any[] = [];
    let fileName = `LAPORAN_${reportType.toUpperCase()}_MA_ASSALAAM`;

    if (reportType === 'mutasi') {
      exportData = mutations.map((m, i) => ({
        No: i + 1,
        'No Mutasi': m.nomorMutasi,
        Tanggal: m.tanggal,
        'Kode Barang': m.kodeBarang,
        'Nama Barang': m.namaBarang,
        'Ruang Asal': m.ruanganAsalNama,
        'Ruang Tujuan': m.ruanganTujuanNama,
        Petugas: m.petugas,
        Alasan: m.alasanMutasi
      }));
    } else if (reportType === 'pemeliharaan') {
      exportData = maintenance.map((m, i) => ({
        No: i + 1,
        'No Servis': m.nomorPerawatan,
        Tanggal: m.tanggal,
        'Kode Barang': m.kodeBarang,
        'Nama Barang': m.namaBarang,
        Jenis: m.jenisPerawatan,
        Kerusakan: m.kerusakan,
        Tindakan: m.tindakan,
        'Biaya (Rp)': m.biaya,
        Teknisi: m.teknisi,
        Hasil: m.kondisiSesudah
      }));
    } else if (reportType === 'penghapusan') {
      exportData = disposals.map((d, i) => ({
        No: i + 1,
        'No Penghapusan': d.nomorPenghapusan,
        Tanggal: d.tanggal,
        'Kode Barang': d.kodeBarang,
        'Nama Barang': d.namaBarang,
        Tahun: d.tahunPerolehan,
        'Nilai (Rp)': d.hargaPerolehan,
        Metode: d.metodePenghapusan,
        Alasan: d.alasanPenghapusan,
        Persetujuan: d.persetujuan
      }));
    } else if (reportType === 'hilang') {
      exportData = lostItems.map((l, i) => ({
        No: i + 1,
        'Kode Barang': l.kodeBarang,
        'Nama Barang': l.namaBarang,
        Ruangan: l.ruangan,
        'Penanggung Jawab': l.penanggungJawab,
        'Tgl Hilang': l.tanggalHilang,
        'Nilai (Rp)': l.nilaiBarang,
        Kronologi: l.kronologi,
        Status: l.status
      }));
    } else {
      exportData = filteredItems.map((item, i) => ({
        No: i + 1,
        'Kode Barang': item.kodeBarang,
        'Nama Barang': item.namaBarang,
        Kategori: item.kategori,
        Merk: item.merk,
        Spesifikasi: item.spesifikasi,
        Tahun: item.tahunPerolehan,
        'Harga (Rp)': item.harga,
        'Sumber Dana': item.sumberDana,
        Ruangan: item.ruanganNama,
        'Penanggung Jawab': item.penanggungJawab,
        Kondisi: item.kondisi,
        Status: item.status
      }));
    }

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'LAPORAN');
    XLSX.writeFile(wb, `${fileName}_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Controls Header (Hidden in Print) */}
      <div className="no-print bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-6 h-6 text-emerald-600" />
              Laporan Inventaris Sarana &amp; Prasarana Resmi
            </h1>
            <p className="text-xs text-slate-500">
              Format kop resmi {schoolProfile.namaMadrasah} lengkap dengan pengesahan Kepala Madrasah siap cetak / simpan PDF &amp; Excel.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportExcel}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-300" />
              <span>Download Excel</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer hover:scale-105"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / Download PDF</span>
            </button>
          </div>
        </div>

        {/* Tahun Pelajaran Selector Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-emerald-50/70 dark:bg-emerald-950/40 p-3 rounded-2xl border border-emerald-200 dark:border-emerald-800">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
            <div>
              <span className="font-extrabold text-xs text-emerald-950 dark:text-emerald-200">
                Tahun Pelajaran Kop Surat:
              </span>
              <span className="text-[11px] text-emerald-700 dark:text-emerald-300 ml-1.5 hidden sm:inline">
                (Dapat diubah untuk cetak laporan per tahunnya dari tahun 2025 s/d 2040)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedTahunPelajaran}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedTahunPelajaran(val);
                if (onUpdateSchoolProfile) {
                  onUpdateSchoolProfile({ ...schoolProfile, tahunPelajaran: val });
                }
              }}
              className="px-3 py-1.5 bg-white dark:bg-slate-800 border-2 border-emerald-600 rounded-xl font-black text-emerald-900 dark:text-emerald-200 text-xs cursor-pointer shadow-xs focus:ring-2 focus:ring-emerald-500"
            >
              {TAHUN_PELAJARAN_LIST.map((tp) => (
                <option key={tp} value={tp}>
                  Tahun Pelajaran {tp}
                </option>
              ))}
            </select>

            {onUpdateSchoolProfile && selectedTahunPelajaran !== schoolProfile?.tahunPelajaran && (
              <button
                type="button"
                onClick={() => {
                  onUpdateSchoolProfile({ ...schoolProfile, tahunPelajaran: selectedTahunPelajaran });
                }}
                className="px-2.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-[11px] font-bold transition-colors cursor-pointer"
              >
                Simpan ke Profil
              </button>
            )}
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Pilih Jenis Laporan
            </label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold text-emerald-800 dark:text-emerald-300"
            >
              {reportOptions.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Filter Ruangan
            </label>
            <select
              value={filterRuangan}
              onChange={(e) => setFilterRuangan(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
            >
              <option value="Semua">Semua Ruangan</option>
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.namaRuangan}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Filter Kategori
            </label>
            <select
              value={filterKategori}
              onChange={(e) => setFilterKategori(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
            >
              <option value="Semua">Semua Kategori</option>
              {categories.map((c) => (
                <option key={c.id} value={c.nama}>
                  {c.nama}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Filter Kondisi
            </label>
            <select
              value={filterKondisi}
              onChange={(e) => setFilterKondisi(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
            >
              <option value="Semua">Semua Kondisi</option>
              <option value="Baik">Baik</option>
              <option value="Rusak Ringan">Rusak Ringan</option>
              <option value="Rusak Berat">Rusak Berat</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
              Filter Tahun Pelajaran / Aset
            </label>
            <select
              value={filterTahun}
              onChange={(e) => setFilterTahun(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
            >
              <option value="Semua">Semua Tahun</option>
              <optgroup label="Tahun Pelajaran (2025 - 2040)">
                {TAHUN_PELAJARAN_LIST.map((tp) => (
                  <option key={tp} value={tp}>
                    TP {tp}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Tahun Kalender">
                {Array.from({ length: 16 }, (_, i) => 2025 + i).map((y) => (
                  <option key={y} value={y.toString()}>
                    Tahun {y}
                  </option>
                ))}
              </optgroup>
            </select>
          </div>
        </div>
      </div>

      {/* PRINT AREA: OFFICIAL LETTERHEAD AND REPORT TABLE */}
      <div className="print-area bg-white p-8 max-w-5xl mx-auto rounded-3xl border border-slate-200 shadow-md text-slate-900 print:shadow-none print:border-none print:m-0 print:p-4 print:max-w-none print:w-full">
        {/* Official Letterhead (Kop Surat Resmi MA Assalaam Arjasari) */}
        <div className="border-b-4 border-double border-slate-900 pb-4 mb-6 text-center">
          <div className="flex items-center justify-center gap-5 mb-2">
            <img
              src={schoolProfile.logoUrl}
              alt="Logo"
              className="w-20 h-20 object-contain"
            />
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest text-slate-800">
                {schoolProfile.yayasan}
              </h4>
              <h2 className="text-2xl font-black uppercase text-slate-950 tracking-wide font-serif">
                {schoolProfile.namaMadrasah}
              </h2>
              <p className="text-xs text-slate-600 font-medium">
                {schoolProfile.alamat}, Desa {schoolProfile.desa}, Kec. {schoolProfile.kecamatan}, Kab. {schoolProfile.kabupaten} {schoolProfile.kodePos}
              </p>
              <p className="text-[11px] text-slate-500 font-mono">
                NPSN: {schoolProfile.npsn} | NSM: {schoolProfile.nsm} | Telp: {schoolProfile.telepon} | Email: {schoolProfile.email}
              </p>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-400 text-center">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900">
              {reportOptions.find((r) => r.id === reportType)?.label.slice(3) || 'LAPORAN SARPRAS'}
            </h3>
            <p className="text-xs text-slate-700">
              Periode Tahun Pelajaran: <span className="font-bold text-slate-950">TP {selectedTahunPelajaran}</span> • Dicetak Tanggal: {new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}
            </p>
          </div>
        </div>

        {/* Dynamic Table based on reportType */}
        <div className="overflow-x-auto my-4">
          {reportType === 'mutasi' ? (
            <table className="w-full text-left text-xs border border-slate-300">
              <thead className="bg-slate-100 font-bold border-b border-slate-300">
                <tr>
                  <th className="py-2 px-2.5">No</th>
                  <th className="py-2 px-2.5">No. Mutasi</th>
                  <th className="py-2 px-2.5">Tanggal</th>
                  <th className="py-2 px-2.5">Kode Barang</th>
                  <th className="py-2 px-2.5">Nama Barang</th>
                  <th className="py-2 px-2.5">Ruang Asal</th>
                  <th className="py-2 px-2.5">Ruang Tujuan</th>
                  <th className="py-2 px-2.5">Alasan</th>
                  <th className="py-2 px-2.5">Petugas</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {mutations.map((m, idx) => (
                  <tr key={m.id}>
                    <td className="py-1.5 px-2.5">{idx + 1}</td>
                    <td className="py-1.5 px-2.5 font-mono font-bold">{m.nomorMutasi}</td>
                    <td className="py-1.5 px-2.5">{m.tanggal}</td>
                    <td className="py-1.5 px-2.5 font-mono">{m.kodeBarang}</td>
                    <td className="py-1.5 px-2.5 font-semibold">{m.namaBarang}</td>
                    <td className="py-1.5 px-2.5">{m.ruanganAsalNama}</td>
                    <td className="py-1.5 px-2.5 font-bold">{m.ruanganTujuanNama}</td>
                    <td className="py-1.5 px-2.5">{m.alasanMutasi}</td>
                    <td className="py-1.5 px-2.5">{m.petugas}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : reportType === 'pemeliharaan' ? (
            <table className="w-full text-left text-xs border border-slate-300">
              <thead className="bg-slate-100 font-bold border-b border-slate-300">
                <tr>
                  <th className="py-2 px-2.5">No</th>
                  <th className="py-2 px-2.5">No. Perawatan</th>
                  <th className="py-2 px-2.5">Tanggal</th>
                  <th className="py-2 px-2.5">Kode &amp; Nama Barang</th>
                  <th className="py-2 px-2.5">Jenis Servis</th>
                  <th className="py-2 px-2.5">Tindakan / Kerusakan</th>
                  <th className="py-2 px-2.5">Biaya (Rp)</th>
                  <th className="py-2 px-2.5">Teknisi</th>
                  <th className="py-2 px-2.5">Hasil</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {maintenance.map((m, idx) => (
                  <tr key={m.id}>
                    <td className="py-1.5 px-2.5">{idx + 1}</td>
                    <td className="py-1.5 px-2.5 font-mono font-bold">{m.nomorPerawatan}</td>
                    <td className="py-1.5 px-2.5">{m.tanggal}</td>
                    <td className="py-1.5 px-2.5 font-semibold">
                      {m.namaBarang} <span className="font-mono text-[10px]">({m.kodeBarang})</span>
                    </td>
                    <td className="py-1.5 px-2.5">{m.jenisPerawatan}</td>
                    <td className="py-1.5 px-2.5">{m.tindakan} ({m.kerusakan})</td>
                    <td className="py-1.5 px-2.5 font-mono font-bold">{formatRupiah(m.biaya)}</td>
                    <td className="py-1.5 px-2.5">{m.teknisi}</td>
                    <td className="py-1.5 px-2.5 font-bold">{m.kondisiSesudah}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : reportType === 'penghapusan' ? (
            <table className="w-full text-left text-xs border border-slate-300">
              <thead className="bg-slate-100 font-bold border-b border-slate-300">
                <tr>
                  <th className="py-2 px-2.5">No</th>
                  <th className="py-2 px-2.5">No. SK Hapus</th>
                  <th className="py-2 px-2.5">Tanggal</th>
                  <th className="py-2 px-2.5">Kode &amp; Nama Barang</th>
                  <th className="py-2 px-2.5">Nilai Perolehan</th>
                  <th className="py-2 px-2.5">Metode</th>
                  <th className="py-2 px-2.5">Alasan</th>
                  <th className="py-2 px-2.5">Persetujuan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {disposals.map((d, idx) => (
                  <tr key={d.id}>
                    <td className="py-1.5 px-2.5">{idx + 1}</td>
                    <td className="py-1.5 px-2.5 font-mono font-bold">{d.nomorPenghapusan}</td>
                    <td className="py-1.5 px-2.5">{d.tanggal}</td>
                    <td className="py-1.5 px-2.5 font-semibold">
                      {d.namaBarang} <span className="font-mono text-[10px]">({d.kodeBarang})</span>
                    </td>
                    <td className="py-1.5 px-2.5 font-mono font-bold">{formatRupiah(d.hargaPerolehan)}</td>
                    <td className="py-1.5 px-2.5">{d.metodePenghapusan}</td>
                    <td className="py-1.5 px-2.5">{d.alasanPenghapusan}</td>
                    <td className="py-1.5 px-2.5">{d.persetujuan}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            /* Standard Items Report */
            <table className="w-full text-left text-xs border border-slate-300">
              <thead className="bg-slate-100 font-bold border-b border-slate-300">
                <tr>
                  <th className="py-2 px-2">No</th>
                  <th className="py-2 px-2">Kode Barang</th>
                  <th className="py-2 px-2">Nama Barang</th>
                  <th className="py-2 px-2">Merk / Tipe</th>
                  <th className="py-2 px-2">Tahun</th>
                  <th className="py-2 px-2">Harga (Rp)</th>
                  <th className="py-2 px-2">Lokasi Ruangan</th>
                  <th className="py-2 px-2">Penanggung Jawab</th>
                  <th className="py-2 px-2">Kondisi</th>
                  <th className="py-2 px-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredItems.map((item, idx) => (
                  <tr key={item.id}>
                    <td className="py-1.5 px-2">{idx + 1}</td>
                    <td className="py-1.5 px-2 font-mono font-bold">{item.kodeBarang}</td>
                    <td className="py-1.5 px-2 font-semibold">{item.namaBarang}</td>
                    <td className="py-1.5 px-2">{item.merk}</td>
                    <td className="py-1.5 px-2 font-mono">{item.tahunPerolehan}</td>
                    <td className="py-1.5 px-2 font-mono font-bold">{formatRupiah(item.harga)}</td>
                    <td className="py-1.5 px-2">{item.ruanganNama}</td>
                    <td className="py-1.5 px-2">{item.penanggungJawab}</td>
                    <td className="py-1.5 px-2 font-semibold">{item.kondisi}</td>
                    <td className="py-1.5 px-2">{item.status}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-400">
                <tr>
                  <td colSpan={5} className="py-2 px-2 text-right">
                    TOTAL KESELURUHAN NILAI ASET:
                  </td>
                  <td colSpan={5} className="py-2 px-2 font-mono text-sm font-black text-slate-900">
                    {formatRupiah(totalNilaiFiltered)}
                  </td>
                </tr>
              </tfoot>
            </table>
          )}
        </div>

        {/* Official Signatures */}
        <div className="grid grid-cols-2 gap-8 pt-10 text-center text-xs leading-relaxed">
          <div>
            <p>Mengetahui,</p>
            <p className="font-bold">Kepala Madrasah Aliyah Assalaam</p>
            <div className="h-16" />
            <p className="font-bold underline text-sm">{schoolProfile.kepalaMadrasah}</p>
            <p className="text-[10px] text-slate-600 font-mono">NIP. {schoolProfile.nipKepalaMadrasah || '-'}</p>
          </div>

          <div>
            <p>Bandung, {new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
            <p className="font-bold">Koordinator Sarana &amp; Prasarana</p>
            <div className="h-16" />
            <p className="font-bold underline text-sm">Ahmad Fauzi, S.Kom.</p>
            <p className="text-[10px] text-slate-600">NIP/NUPTK: 198804122019031008</p>
          </div>
        </div>
      </div>
    </div>
  );
};
