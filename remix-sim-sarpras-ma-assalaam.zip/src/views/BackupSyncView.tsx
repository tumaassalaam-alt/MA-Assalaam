import React, { useState } from 'react';
import {
  Database,
  RefreshCw,
  Download,
  Upload,
  FileSpreadsheet,
  FileCode,
  Copy,
  Check,
  ShieldAlert,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  Eye,
  Server
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { StorageService, SheetSettings } from '../services/storage';
import { SpreadsheetSyncService, SyncLogEntry } from '../services/spreadsheetSync';
import { Item, Room, User } from '../types';

interface BackupSyncViewProps {
  currentUser: User | null;
  items: Item[];
  rooms: Room[];
  onImportItems: (newItems: Item[]) => void;
  onRefreshData: () => void;
}

export const BackupSyncView: React.FC<BackupSyncViewProps> = ({
  currentUser,
  items,
  rooms,
  onImportItems,
  onRefreshData
}) => {
  const [activeTab, setActiveTab] = useState<'sync' | 'import' | 'backup' | 'script'>('sync');

  // Sheet Settings
  const [settings, setSettings] = useState<SheetSettings>(StorageService.getSheetSettings());
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ tested: boolean; success: boolean; message: string; details: any } | null>(null);
  const [syncStatusMsg, setSyncStatusMsg] = useState('');

  // Excel Import State
  const [importedPreview, setImportedPreview] = useState<any[]>([]);
  const [importErrors, setImportErrors] = useState<string[]>([]);
  const [duplicateCount, setDuplicateCount] = useState<number>(0);
  const [copiedCode, setCopiedCode] = useState(false);

  // Restore State
  const [restoreStatus, setRestoreStatus] = useState('');
  const [syncLogs, setSyncLogs] = useState<SyncLogEntry[]>([]);

  // Auto-sync event listener
  React.useEffect(() => {
    const handleSyncEvent = () => {
      setSettings(StorageService.getSheetSettings());
    };
    window.addEventListener('sarpras-spreadsheet-sync', handleSyncEvent);
    return () => window.removeEventListener('sarpras-spreadsheet-sync', handleSyncEvent);
  }, []);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    StorageService.saveSheetSettings(settings, currentUser || undefined);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  // Test connection to Google Spreadsheet & Apps Script
  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await SpreadsheetSyncService.testConnection(settings.sheetUrl, settings.scriptUrl);
      setTestResult({ tested: true, ...res });
    } catch (e: any) {
      setTestResult({
        tested: true,
        success: false,
        message: 'Gagal melakukan tes: ' + e.message,
        details: null
      });
    } finally {
      setIsTesting(false);
    }
  };

  // Real two-way synchronization with Google Spreadsheet
  const handlePerformSync = async () => {
    setIsSyncing(true);
    setSyncStatusMsg('Menghubungkan ke Google Spreadsheet MA Assalaam...');
    setSyncLogs([]);

    try {
      const result = await SpreadsheetSyncService.runFullSync((msg) => {
        setSyncStatusMsg(msg);
      });

      setSyncLogs(result.logs);
      setSyncStatusMsg(result.message);
      setSettings(StorageService.getSheetSettings());

      if (result.success) {
        onRefreshData();
      }
    } catch (err: any) {
      setSyncStatusMsg('Terjadi kendala saat sinkronisasi: ' + err.message);
    } finally {
      setIsSyncing(false);
    }
  };

  // Excel / CSV File Read & Validation
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportErrors([]);
    setDuplicateCount(0);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);

        if (!json || json.length === 0) {
          setImportErrors(['File Excel kosong atau format tidak sesuai.']);
          return;
        }

        // Validate columns and check duplicates
        const existingCodes = new Set(items.map((i) => i.kodeBarang.toLowerCase()));
        let dupes = 0;
        const errors: string[] = [];

        const parsed = json.map((row: any, idx) => {
          const kode = (row['Kode Barang'] || row['kodeBarang'] || `MAASS-IMP-${idx + 1}`).toString().trim();
          const nama = (row['Nama Barang'] || row['namaBarang'] || row['Nama'] || '').toString().trim();

          if (!nama) {
            errors.push(`Baris ${idx + 2}: Nama barang tidak boleh kosong.`);
          }

          if (existingCodes.has(kode.toLowerCase())) {
            dupes++;
          }

          return {
            kodeBarang: kode,
            namaBarang: nama || 'Barang Import',
            kategori: (row['Kategori'] || 'Lainnya').toString().trim(),
            kategoriKode: 'IMP',
            merk: (row['Merk'] || '-').toString().trim(),
            spesifikasi: (row['Spesifikasi'] || '-').toString().trim(),
            tahunPerolehan: Number(row['Tahun'] || new Date().getFullYear()),
            harga: Number(row['Harga'] || row['Harga (Rp)'] || 0),
            sumberDana: 'BOS',
            ruanganId: rooms[0]?.id || 'room-1',
            ruanganNama: (row['Ruangan'] || rooms[0]?.namaRuangan || 'Gudang').toString().trim(),
            penanggungJawab: rooms[0]?.penanggungJawab || 'Petugas Sarpras',
            kondisi: (row['Kondisi'] || 'Baik').toString().trim(),
            status: (row['Status'] || 'Tersedia').toString().trim(),
            fotoBarang: 'https://images.unsplash.com/photo-1587831990711-23ca6441447b?w=600&auto=format&fit=crop&q=80',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
        });

        setDuplicateCount(dupes);
        setImportErrors(errors);
        setImportedPreview(parsed);
      } catch (err: any) {
        setImportErrors(['Gagal membaca file Excel: ' + err.message]);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleConfirmImport = () => {
    if (importedPreview.length === 0) return;
    const finalItems: Item[] = importedPreview.map((p, idx) => ({
      ...p,
      id: `itm-import-${Date.now()}-${idx}`
    }));

    onImportItems(finalItems);
    alert(`Berhasil mengimpor ${finalItems.length} barang ke dalam database!`);
    setImportedPreview([]);
  };

  // Restore JSON
  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;
    if (confirm('Restore akan menimpa data saat ini dengan file cadangan. Lanjutkan?')) {
      const res = await StorageService.restoreFromBackup(file, currentUser);
      setRestoreStatus(res.message);
      if (res.success) {
        onRefreshData();
      }
    }
  };

  const codeGsContent = `/**
 * ====================================================================
 * GOOGLE APPS SCRIPT: SIM SARPRAS MA ASSALAAM ARJASARI BANDUNG
 * File: Code.gs (Deploy sebagai Web App / API Endpoint)
 * ====================================================================
 */

const SHEET_NAMES = {
  SETTINGS: 'SETTINGS',
  USERS: 'USERS',
  MADRASAH: 'MADRASAH',
  RUANGAN: 'RUANGAN',
  KATEGORI: 'KATEGORI',
  BARANG: 'BARANG',
  MUTASI: 'MUTASI',
  PEMINJAMAN: 'PEMINJAMAN',
  PEMELIHARAAN: 'PEMELIHARAAN',
  PENGHAPUSAN: 'PENGHAPUSAN',
  BARANG_HILANG: 'BARANG_HILANG',
  BUKU: 'BUKU',
  LOG_AKTIVITAS: 'LOG_AKTIVITAS'
};

function doGet(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const action = (e && e.parameter && e.parameter.action) || 'getAll';
  
  if (action === 'getAll') {
    const data = {
      barang: getSheetData(ss.getSheetByName(SHEET_NAMES.BARANG)),
      ruangan: getSheetData(ss.getSheetByName(SHEET_NAMES.RUANGAN)),
      mutasi: getSheetData(ss.getSheetByName(SHEET_NAMES.MUTASI)),
      peminjaman: getSheetData(ss.getSheetByName(SHEET_NAMES.PEMINJAMAN))
    };
    return ContentService.createTextOutput(JSON.stringify(data))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  return ContentService.createTextOutput(JSON.stringify({ 
    status: 'ONLINE', 
    madrasah: 'Madrasah Aliyah Assalaam Arjasari',
    timestamp: new Date().toISOString()
  })).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    const postData = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();

    // 1. Tulis / Perbarui Data BARANG
    if (postData.items && Array.isArray(postData.items)) {
      let sheet = ss.getSheetByName(SHEET_NAMES.BARANG) || ss.insertSheet(SHEET_NAMES.BARANG);
      sheet.clearContents();
      sheet.appendRow([
        'Kode Barang', 'Nama Barang', 'Kategori', 'Merk', 'Spesifikasi',
        'Tahun', 'Harga (Rp)', 'Ruangan', 'Penanggung Jawab', 'Kondisi', 'Status'
      ]);
      postData.items.forEach(function(itm) {
        sheet.appendRow([
          itm.kodeBarang, itm.namaBarang, itm.kategori, itm.merk, itm.spesifikasi,
          itm.tahunPerolehan, itm.harga, itm.ruanganNama, itm.penanggungJawab, itm.kondisi, itm.status
        ]);
      });
    }

    // 2. Tulis / Perbarui Data RUANGAN
    if (postData.rooms && Array.isArray(postData.rooms)) {
      let sheet = ss.getSheetByName(SHEET_NAMES.RUANGAN) || ss.insertSheet(SHEET_NAMES.RUANGAN);
      sheet.clearContents();
      sheet.appendRow(['Kode Ruangan', 'Nama Ruangan', 'Jenis', 'Gedung', 'Lantai', 'Penanggung Jawab', 'Kondisi']);
      postData.rooms.forEach(function(r) {
        sheet.appendRow([r.kodeRuangan, r.namaRuangan, r.jenisRuangan, r.gedung, r.lantai, r.penanggungJawab, r.kondisiRuangan]);
      });
    }

    // 3. Log Aktivitas
    const logSheet = ss.getSheetByName(SHEET_NAMES.LOG_AKTIVITAS) || ss.insertSheet(SHEET_NAMES.LOG_AKTIVITAS);
    logSheet.appendRow([
      new Date(),
      'SIM SARPRAS MA ASSALAAM ARJASARI',
      postData.action || 'Sync',
      (postData.items ? postData.items.length + ' barang' : 'Pembaruan data')
    ]);

    return ContentService.createTextOutput(JSON.stringify({ 
      success: true, 
      message: 'Data berhasil disinkronkan ke Spreadsheet MA Assalaam Arjasari',
      itemsCount: (postData.items || []).length
    })).setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ 
      success: false, 
      error: err.toString() 
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function getSheetData(sheet) {
  if (!sheet) return [];
  const rows = sheet.getDataRange().getValues();
  if (rows.length < 2) return [];
  const headers = rows[0];
  return rows.slice(1).map(row => {
    let obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(codeGsContent);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Database className="w-6 h-6 text-emerald-600" />
            Database Google Spreadsheet &amp; Backup Sistem
          </h1>
          <p className="text-xs text-slate-500">
            Sinkronisasi otomatis dua arah, ekspor buku kerja Excel multi-sheet, impor data, dan pencadangan terenkripsi.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <button
            onClick={() => setActiveTab('sync')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              activeTab === 'sync'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Sinkronisasi G-Sheet
          </button>
          <button
            onClick={() => setActiveTab('import')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              activeTab === 'import'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Import Excel / CSV
          </button>
          <button
            onClick={() => setActiveTab('backup')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              activeTab === 'backup'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Backup &amp; Restore
          </button>
          <button
            onClick={() => setActiveTab('script')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              activeTab === 'script'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Kode Google Apps Script
          </button>
        </div>
      </div>

      {/* TAB 1: SPREADSHEET SYNC */}
      {activeTab === 'sync' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-emerald-900 to-teal-900 text-white p-6 rounded-3xl shadow-md border border-emerald-800">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold bg-amber-400 text-slate-950 px-2 py-0.5 rounded uppercase flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-800 animate-pulse"></span>
                    Database Otomatis Terhubung
                  </span>
                  <span className="text-[10px] font-mono font-semibold bg-white/20 text-emerald-100 px-2 py-0.5 rounded">
                    Real-time Auto-Sync
                  </span>
                </div>
                <h3 className="text-lg font-black mt-2">
                  Integrasi Otomatis Google Spreadsheet MA Assalaam
                </h3>
                <p className="text-xs text-emerald-100 max-w-xl mt-1">
                  Semua transaksi barang, mutasi, peminjaman, perbaikan, dan profil madrasah otomatis tersambung dan tersinkronisasi dua arah ke Google Spreadsheet.
                </p>
                <div className="text-[11px] text-emerald-200/90 font-mono mt-2 flex items-center gap-2">
                  <span>Terakhir Sinkron:</span>
                  <span className="font-bold text-amber-300">
                    {new Date(settings.lastSyncTime || Date.now()).toLocaleString('id-ID')}
                  </span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
                <a
                  href={settings.sheetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-1.5 cursor-pointer text-center"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-300" />
                  <span>Buka Dokumen Spreadsheet</span>
                </a>

                <button
                  type="button"
                  onClick={handlePerformSync}
                  disabled={isSyncing}
                  className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer hover:scale-105 shrink-0"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Sekarang'}</span>
                </button>
              </div>
            </div>

            {syncStatusMsg && (
              <div className="mt-4 p-3 bg-white/10 rounded-xl text-xs font-semibold text-emerald-200 border border-white/20">
                {syncStatusMsg}
              </div>
            )}

            {syncLogs.length > 0 && (
              <div className="mt-4 p-4 bg-slate-950/90 rounded-2xl font-mono text-[11px] border border-emerald-500/30 space-y-1.5 max-h-52 overflow-y-auto">
                <div className="font-bold text-amber-300 pb-1.5 border-b border-white/10 flex items-center justify-between">
                  <span>Log Proses Sinkronisasi Google Spreadsheet:</span>
                  <span className="text-[10px] text-slate-400">{syncLogs.length} tahapan</span>
                </div>
                {syncLogs.map((log, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <span className="text-slate-500 text-[10px] shrink-0">[{log.time}]</span>
                    <span className={
                      log.type === 'error'
                        ? 'text-rose-400 font-bold'
                        : log.type === 'warning'
                        ? 'text-amber-300 font-semibold'
                        : log.type === 'success'
                        ? 'text-emerald-300 font-bold'
                        : 'text-slate-200'
                    }>
                      {log.message}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Settings form */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs max-w-3xl space-y-6">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white mb-1 flex items-center gap-2">
                <Server className="w-4 h-4 text-emerald-600" />
                Konfigurasi URL Google Spreadsheet &amp; WhatsApp Webhook
              </h3>
              <p className="text-xs text-slate-500">
                Hubungkan lembar kerja Google Sheets untuk sinkronisasi aset sarpras secara real-time.
              </p>
            </div>

            {/* Placeholder Warning Banner */}
            {settings.sheetUrl && settings.sheetUrl.includes('1_SIM_SARPRAS_MA_ASSALAAM_BANDUNG') && (
              <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-2xl text-xs space-y-2">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-extrabold text-amber-900 dark:text-amber-200 block">
                      Perhatian: URL Spreadsheet Masih Berupa Link Contoh (Placeholder)
                    </span>
                    <p className="text-amber-800 dark:text-amber-300 text-[11px] mt-0.5">
                      Untuk menghubungkan data inventaris madrasah, buatlah Google Spreadsheet baru di akun Google Anda, lalu tempelkan URL-nya ke kolom di bawah.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 pt-1 pl-6">
                  <a
                    href="https://sheets.new"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-[11px] transition-colors"
                  >
                    + Buat Spreadsheet Baru (sheets.new)
                  </a>
                  <button
                    type="button"
                    onClick={() => setActiveTab('backup')}
                    className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-200 font-bold rounded-lg text-[11px]"
                  >
                    Unduh File Format Excel Siap Impor
                  </button>
                </div>
              </div>
            )}

            {/* Test Connection Result Box */}
            {testResult && (
              <div className={`p-4 rounded-2xl border text-xs space-y-2 animate-in fade-in ${
                testResult.success
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-100'
                  : 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-100'
              }`}>
                <div className="flex items-start gap-2">
                  {testResult.success ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1 space-y-1">
                    <span className="font-extrabold block text-sm">
                      {testResult.success ? 'Koneksi Berhasil!' : 'Koneksi Belum Berhasil'}
                    </span>
                    <p className="text-[11.5px] leading-relaxed">
                      {testResult.message}
                    </p>

                    {testResult.details?.isRestricted && (
                      <div className="mt-2 p-2.5 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-rose-200 dark:border-rose-900 text-[11px] text-slate-700 dark:text-slate-300 space-y-1">
                        <strong className="text-rose-700 dark:text-rose-300 block">Cara Mengatasi Akses "Dibatasi" (Restricted):</strong>
                        <ol className="list-decimal list-inside space-y-0.5 pl-1">
                          <li>Buka Google Spreadsheet Anda di tab baru.</li>
                          <li>Klik tombol biru <strong>"Bagikan" (Share)</strong> di kanan atas.</li>
                          <li>Ubah <em>Akses umum</em> menjadi <strong>"Siapa saja yang memiliki link"</strong> (Pelihat/Editor).</li>
                          <li>Klik Selesai, lalu klik tombol <em>Uji Koneksi</em> lagi di sini.</li>
                        </ol>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {saveSuccess && (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 text-xs rounded-xl border border-emerald-200">
                Pengaturan berhasil disimpan!
              </div>
            )}

            <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  URL Dokumen Google Spreadsheet
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://docs.google.com/spreadsheets/d/.../edit"
                  value={settings.sheetUrl}
                  onChange={(e) => setSettings({ ...settings, sheetUrl: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Pastikan spreadsheet diatur ke: <strong>"Siapa saja yang memiliki link dapat melihat/mengedit"</strong>.
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  URL Google Apps Script Web App Deployment (Untuk Sinkronisasi Tulis 2 Arah)
                </label>
                <input
                  type="url"
                  placeholder="https://script.google.com/macros/s/.../exec"
                  value={settings.scriptUrl}
                  onChange={(e) => setSettings({ ...settings, scriptUrl: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono text-xs"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Dapatkan dari menu <em>Ekstensi &gt; Apps Script &gt; Terapkan &gt; Deployment Baru &gt; Web App</em> di Google Spreadsheet Anda (lihat tab Kode Google Apps Script).
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nomor WhatsApp Admin / Kepala Madrasah (Untuk Notifikasi Transaksi)
                </label>
                <input
                  type="tel"
                  placeholder="081223456789"
                  value={settings.waAdminNumber}
                  onChange={(e) => setSettings({ ...settings, waAdminNumber: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono font-bold text-emerald-800 dark:text-emerald-300 text-xs"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="autoSyncCheck"
                  checked={settings.autoSync}
                  onChange={(e) => setSettings({ ...settings, autoSync: e.target.checked })}
                  className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="autoSyncCheck" className="font-semibold text-slate-700 dark:text-slate-300">
                  Aktifkan auto-sync real-time setiap ada transaksi mutasi, peminjaman, &amp; lapor kerusakan
                </label>
              </div>

              <div className="pt-2 flex flex-wrap items-center gap-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Simpan Konfigurasi
                </button>
                <button
                  type="button"
                  onClick={handleTestConnection}
                  disabled={isTesting || isSyncing}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  {isTesting ? 'Menguji Koneksi...' : '🔍 Uji Koneksi'}
                </button>
                <button
                  type="button"
                  onClick={handlePerformSync}
                  disabled={isSyncing}
                  className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  {isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Sekarang'}
                </button>
              </div>
            </form>

            {/* Quick Step Guide */}
            <div className="p-4 bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl space-y-2 text-xs">
              <h4 className="font-black text-emerald-950 dark:text-emerald-200 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-emerald-600" />
                Panduan Singkat Menghubungkan Google Spreadsheet MA Assalaam
              </h4>
              <ol className="list-decimal list-inside space-y-1 text-slate-700 dark:text-slate-300 text-[11px] leading-relaxed">
                <li>
                  <strong>Buka Google Spreadsheet:</strong> Pastikan Anda telah memiliki Google Spreadsheet untuk inventaris sarpras.
                </li>
                <li>
                  <strong>Ubah Izin Akses:</strong> Di Spreadsheet, klik tombol <strong>"Bagikan" (Share)</strong> di pojok kanan atas, lalu ubah <em>Akses umum</em> menjadi <strong>"Siapa saja yang memiliki link"</strong> dengan peran <strong>Pelihat (Viewer)</strong> atau <strong>Editor</strong>.
                </li>
                <li>
                  <strong>Tempel Link &amp; Sinkronkan:</strong> Salin URL Spreadsheet ke formulir di atas lalu klik <strong>"Simpan Konfigurasi"</strong> dan <strong>"Sinkronkan Sekarang"</strong>.
                </li>
                <li>
                  <strong>Tulis Otomatis Dua Arah (Opsional):</strong> Buka tab <em>"Kode Google Apps Script"</em> di atas, salin kodenya ke <em>Ekstensi &gt; Apps Script</em> di spreadsheet Anda, lalu Deploy sebagai <strong>Web App (Akses: Siapa saja)</strong> untuk sinkronisasi dua arah otomatis penuh.
                </li>
              </ol>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: EXCEL IMPORT */}
      {activeTab === 'import' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs max-w-3xl">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Upload className="w-4 h-4 text-emerald-600" />
              Impor Data Barang dari File Excel (.xlsx / .csv)
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Kolom wajib didukung: <strong>Kode Barang, Nama Barang, Kategori, Merk, Spesifikasi, Tahun, Harga, Ruangan, Kondisi, Status</strong>.
            </p>

            <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 p-6 rounded-2xl text-center bg-slate-50 dark:bg-slate-800/40">
              <FileSpreadsheet className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
              <label className="cursor-pointer px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs inline-block">
                Pilih File Excel / CSV
                <input
                  type="file"
                  accept=".xlsx, .xls, .csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {importErrors.length > 0 && (
            <div className="p-4 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-2xl space-y-1">
              <div className="font-bold flex items-center gap-1">
                <AlertCircle className="w-4 h-4" />
                Ditemukan Kendala Pada File:
              </div>
              {importErrors.map((err, i) => (
                <div key={i}>{err}</div>
              ))}
            </div>
          )}

          {duplicateCount > 0 && (
            <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 text-xs rounded-2xl">
              Perhatian: Ditemukan <strong>{duplicateCount}</strong> kode barang yang sudah ada di database. Sistem akan memperbarui data tersebut.
            </div>
          )}

          {importedPreview.length > 0 && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
              <div className="p-4 border-b flex items-center justify-between">
                <h4 className="font-bold text-xs">
                  Pratinjau Data Impor ({importedPreview.length} Barang Terdeteksi)
                </h4>
                <button
                  type="button"
                  onClick={handleConfirmImport}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow"
                >
                  Konfirmasi &amp; Simpan ke Database
                </button>
              </div>

              <div className="overflow-x-auto max-h-64">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800 font-semibold border-b">
                    <tr>
                      <th className="py-2 px-3">Kode Barang</th>
                      <th className="py-2 px-3">Nama Barang</th>
                      <th className="py-2 px-3">Kategori</th>
                      <th className="py-2 px-3">Merk</th>
                      <th className="py-2 px-3">Ruangan</th>
                      <th className="py-2 px-3">Kondisi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y text-slate-700 dark:text-slate-300">
                    {importedPreview.slice(0, 10).map((row, idx) => (
                      <tr key={idx}>
                        <td className="py-1.5 px-3 font-mono">{row.kodeBarang}</td>
                        <td className="py-1.5 px-3 font-bold">{row.namaBarang}</td>
                        <td className="py-1.5 px-3">{row.kategori}</td>
                        <td className="py-1.5 px-3">{row.merk}</td>
                        <td className="py-1.5 px-3">{row.ruanganNama}</td>
                        <td className="py-1.5 px-3">{row.kondisi}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: BACKUP & RESTORE */}
      {activeTab === 'backup' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Download Backups */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Download className="w-4 h-4 text-emerald-600" />
              Unduh File Cadangan Database
            </h3>
            <p className="text-xs text-slate-500">
              Simpan salinan data lengkap secara berkala demi keamanan jangka panjang sarpras madrasah.
            </p>

            <div className="space-y-3 pt-2">
              <button
                type="button"
                onClick={() => StorageService.exportToExcelWorkbook()}
                className="w-full py-3 px-4 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-amber-300" />
                <span>Download Buku Kerja Spreadsheet Excel (.xlsx)</span>
              </button>

              <button
                type="button"
                onClick={() => StorageService.exportFullBackup()}
                className="w-full py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Database className="w-4 h-4 text-emerald-400" />
                <span>Download Full Database Cadangan JSON (.json)</span>
              </button>
            </div>
          </div>

          {/* Restore Backup */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-extrabold text-rose-700 dark:text-rose-400 flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Pemulihan Database (Restore)
            </h3>
            <p className="text-xs text-slate-500">
              Pilih file cadangan JSON yang sebelumnya telah diunduh dari SIM SARPRAS MA Assalaam.
            </p>

            <div className="border-2 border-dashed border-rose-300 dark:border-rose-900 p-4 rounded-2xl text-center bg-rose-50/40 dark:bg-rose-950/20">
              <label className="cursor-pointer px-4 py-2 bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs rounded-xl shadow-xs inline-block">
                Pilih File JSON Restore
                <input
                  type="file"
                  accept=".json"
                  onChange={handleRestoreFile}
                  className="hidden"
                />
              </label>
            </div>

            {restoreStatus && (
              <div className="p-3 bg-emerald-50 text-emerald-800 text-xs rounded-xl border border-emerald-200 font-semibold">
                {restoreStatus}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: CODE.GS APPS SCRIPT GENERATOR */}
      {activeTab === 'script' && (
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <FileCode className="w-4 h-4 text-emerald-600" />
                File Google Apps Script (Code.gs)
              </h3>
              <p className="text-xs text-slate-500">
                Salin kode berikut ke Google Apps Script pada Spreadsheet Anda untuk mengaktifkan sinkronisasi otomatis.
              </p>
            </div>

            <button
              type="button"
              onClick={copyToClipboard}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedCode ? 'Tersalin!' : 'Salin Kode Code.gs'}</span>
            </button>
          </div>

          <pre className="p-4 bg-slate-950 text-emerald-400 rounded-2xl text-xs font-mono overflow-x-auto max-h-96 custom-scrollbar border border-slate-800">
            {codeGsContent}
          </pre>
        </div>
      )}
    </div>
  );
};
