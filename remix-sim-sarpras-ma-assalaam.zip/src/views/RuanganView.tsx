import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Search,
  Filter,
  QrCode,
  Printer,
  Package,
  DollarSign,
  User,
  MapPin,
  Edit2,
  Trash2,
  Layers,
  FileSpreadsheet,
  CheckCircle,
  Eye,
  Camera,
  X,
  Upload,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { Room, Item, UserRole, SchoolProfile } from '../types';
import { formatRupiah, generateQrDataUrl } from '../services/barcodeGenerator';
import { compressImage } from '../services/imageUtils';

interface RuanganViewProps {
  rooms: Room[];
  items: Item[];
  userRole: UserRole;
  schoolProfile: SchoolProfile;
  onSaveRoom: (room: Room) => void;
  onDeleteRoom: (roomId: string) => void;
  onOpenPublicRoom: (roomId: string) => void;
  onOpenScanner: () => void;
  onPrintRoomLabel: (room: Room) => void;
}

export const RuanganView: React.FC<RuanganViewProps> = ({
  rooms,
  items,
  userRole,
  schoolProfile,
  onSaveRoom,
  onDeleteRoom,
  onOpenPublicRoom,
  onOpenScanner,
  onPrintRoomLabel
}) => {
  const [search, setSearch] = useState('');
  const [selectedGedung, setSelectedGedung] = useState('Semua');
  const [viewMode, setViewMode] = useState<'card' | 'table'>('card');

  // Modal State for Add/Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [modalError, setModalError] = useState('');
  const [toastMessage, setToastMessage] = useState('');

  // Form State
  const [kodeRuangan, setKodeRuangan] = useState('');
  const [namaRuangan, setNamaRuangan] = useState('');
  const [jenisRuangan, setJenisRuangan] = useState('Ruang Kelas');
  const [gedung, setGedung] = useState('Gedung A (Utama)');
  const [lantai, setLantai] = useState('Lantai 1');
  const [luasRuangan, setLuasRuangan] = useState('64');
  const [penanggungJawab, setPenanggungJawab] = useState('');
  const [kapasitas, setKapasitas] = useState<number>(36);
  const [kondisiRuangan, setKondisiRuangan] = useState<Room['kondisiRuangan']>('Baik');
  const [keterangan, setKeterangan] = useState('');
  const [fotoRuangan, setFotoRuangan] = useState('');

  const gedungs = ['Semua', ...Array.from(new Set(rooms.map((r) => r.gedung)))];

  const filteredRooms = rooms.filter((r) => {
    const matchSearch =
      r.namaRuangan.toLowerCase().includes(search.toLowerCase()) ||
      r.kodeRuangan.toLowerCase().includes(search.toLowerCase()) ||
      r.penanggungJawab.toLowerCase().includes(search.toLowerCase());
    const matchGedung = selectedGedung === 'Semua' || r.gedung === selectedGedung;
    return matchSearch && matchGedung;
  });

  const jenisList = [
    'Ruang Kepala Madrasah',
    'Ruang Guru',
    'Ruang TU',
    'Ruang Kelas',
    'Laboratorium',
    'Perpustakaan',
    'UKS',
    'BK',
    'Mushola/Masjid',
    'Asrama',
    'Dapur',
    'Gudang',
    'Toilet',
    'Ruang Organisasi',
    'Ruang Komputer',
    'Ruang Multimedia',
    'Lapangan',
    'Ruang lainnya'
  ];

  const handleOpenAdd = () => {
    setEditingRoom(null);
    setModalError('');
    setKodeRuangan(`R-KLS-${Math.floor(10 + Math.random() * 90)}`);
    setNamaRuangan('');
    setJenisRuangan('Ruang Kelas');
    setGedung('Gedung A (Ruang Kelas)');
    setLantai('Lantai 1');
    setLuasRuangan('64');
    setPenanggungJawab('Koordinator Sarpras');
    setKapasitas(36);
    setKondisiRuangan('Baik');
    setKeterangan('');
    setFotoRuangan('https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=600&auto=format&fit=crop&q=80');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (r: Room) => {
    setEditingRoom(r);
    setModalError('');
    setKodeRuangan(r.kodeRuangan);
    setNamaRuangan(r.namaRuangan);
    setJenisRuangan(r.jenisRuangan);
    setGedung(r.gedung);
    setLantai(r.lantai);
    setLuasRuangan(r.luasRuangan);
    setPenanggungJawab(r.penanggungJawab);
    setKapasitas(r.kapasitas);
    setKondisiRuangan(r.kondisiRuangan);
    setKeterangan(r.keterangan);
    setFotoRuangan(r.fotoRuangan);
    setIsModalOpen(true);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploadingPhoto(true);
      setModalError('');
      try {
        const compressed = await compressImage(file, 800, 800, 0.75);
        setFotoRuangan(compressed);
      } catch (err: any) {
        console.warn('Image compression warning, using fallback reader:', err);
        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            setFotoRuangan(event.target.result as string);
          }
        };
        reader.readAsDataURL(file);
      } finally {
        setIsUploadingPhoto(false);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setModalError('');

    if (!kodeRuangan.trim() || !namaRuangan.trim()) {
      setModalError('Kode ruangan dan nama ruangan wajib diisi.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Smart parsing if user entered format like "80 / 36"
      let parsedLuas = luasRuangan.trim();
      let parsedKapasitas = Number(kapasitas) || 0;

      if (parsedLuas.includes('/')) {
        const parts = parsedLuas.split('/');
        parsedLuas = parts[0].trim();
        const secondPart = parseInt(parts[1].trim(), 10);
        if (!isNaN(secondPart) && secondPart > 0) {
          parsedKapasitas = secondPart;
        }
      }

      const roomData: Room = {
        id: editingRoom ? editingRoom.id : `room-${Date.now()}`,
        kodeRuangan: kodeRuangan.trim().toUpperCase(),
        namaRuangan: namaRuangan.trim(),
        jenisRuangan,
        gedung: gedung.trim() || 'Gedung A',
        lantai: lantai.trim() || 'Lantai 1',
        luasRuangan: parsedLuas || '64',
        penanggungJawab: penanggungJawab.trim() || 'Koordinator Sarpras',
        kapasitas: parsedKapasitas || 36,
        kondisiRuangan,
        keterangan: keterangan.trim(),
        fotoRuangan: fotoRuangan || 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&auto=format&fit=crop&q=80'
      };

      await onSaveRoom(roomData);
      setIsModalOpen(false);
      setToastMessage(`Data ruangan "${roomData.namaRuangan}" berhasil disimpan!`);
      setTimeout(() => setToastMessage(''), 4000);
    } catch (err: any) {
      setModalError('Gagal menyimpan ruangan: ' + (err.message || 'Terjadi kesalahan sistem'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Building2 className="w-6 h-6 text-emerald-600" />
            Data Master Ruangan &amp; Denah Gedung
          </h1>
          <p className="text-xs text-slate-500">
            Kelola data fisik gedung, penanggung jawab, kapasitas, serta kode QR pintu tiap ruangan.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {userRole === 'ADMIN' && (
            <button
              type="button"
              onClick={handleOpenAdd}
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Ruangan Baru</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenScanner}
            className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Camera className="w-4 h-4" />
            <span>Scan QR Ruangan</span>
          </button>
        </div>
      </div>

      {/* Filter and View Toggles */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari ruangan / penanggung jawab..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
            />
          </div>

          <select
            value={selectedGedung}
            onChange={(e) => setSelectedGedung(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-semibold"
          >
            {gedungs.map((g) => (
              <option key={g} value={g}>
                Gedung: {g}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1 self-end sm:self-center">
          <button
            onClick={() => setViewMode('card')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
              viewMode === 'card'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Kartu Ruangan
          </button>
          <button
            onClick={() => setViewMode('table')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
              viewMode === 'table'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Tabel Lengkap
          </button>
        </div>
      </div>

      {/* Room Cards View */}
      {viewMode === 'card' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredRooms.map((room) => {
            const roomItems = items.filter((i) => i.ruanganId === room.id);
            const totalVal = roomItems.reduce((sum, itm) => sum + (itm.harga || 0), 0);

            return (
              <div
                key={room.id}
                className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col justify-between hover:shadow-md transition-shadow group"
              >
                <div>
                  {/* Photo Header */}
                  <div className="h-44 relative bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <img
                      src={room.fotoRuangan}
                      alt={room.namaRuangan}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 left-3 px-2.5 py-1 bg-emerald-800/90 text-amber-300 text-[11px] font-mono font-extrabold rounded-lg backdrop-blur-xs">
                      {room.kodeRuangan}
                    </div>
                    <div className="absolute top-3 right-3 px-2 py-0.5 bg-slate-900/80 text-white text-[10px] font-bold rounded-md backdrop-blur-xs">
                      {room.kondisiRuangan}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 space-y-3">
                    <div>
                      <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block">
                        {room.jenisRuangan}
                      </span>
                      <h3 className="text-base font-extrabold text-slate-900 dark:text-white leading-tight">
                        {room.namaRuangan}
                      </h3>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-300">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Lokasi Gedung</span>
                        <span className="font-semibold">{room.gedung}, {room.lantai}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Penanggung Jawab</span>
                        <span className="font-semibold text-slate-900 dark:text-white truncate block">
                          {room.penanggungJawab}
                        </span>
                      </div>
                    </div>

                    {/* Stats inside room */}
                    <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Total Barang</span>
                        <span className="font-black text-slate-900 dark:text-white">{roomItems.length} Unit</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block">Nilai Aset</span>
                        <span className="font-black text-emerald-700 dark:text-emerald-400">
                          {formatRupiah(totalVal)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="p-4 bg-slate-50/70 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => onOpenPublicRoom(room.id)}
                    className="flex-1 py-1.5 px-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    title="Buka Inventaris Lengkap Ruangan (Tanpa Login)"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Daftar Barang</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onPrintRoomLabel(room)}
                    className="p-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl font-bold transition-colors cursor-pointer"
                    title="Cetak Label QR Pintu Ruangan (A4)"
                  >
                    <Printer className="w-4 h-4" />
                  </button>

                  {userRole === 'ADMIN' && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleOpenEdit(room)}
                        className="p-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-700 dark:text-slate-200 rounded-xl transition-colors cursor-pointer"
                        title="Edit Ruangan"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteRoom(room.id)}
                        className="p-2 bg-rose-100 dark:bg-rose-950/60 hover:bg-rose-200 text-rose-700 dark:text-rose-300 rounded-xl transition-colors cursor-pointer"
                        title="Hapus Ruangan"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Table View */
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/70 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">No</th>
                  <th className="py-3 px-4">Kode Ruang</th>
                  <th className="py-3 px-4">Nama Ruangan</th>
                  <th className="py-3 px-4">Jenis</th>
                  <th className="py-3 px-4">Gedung / Lantai</th>
                  <th className="py-3 px-4">Penanggung Jawab</th>
                  <th className="py-3 px-4">Barang</th>
                  <th className="py-3 px-4">Nilai Aset</th>
                  <th className="py-3 px-4">Kondisi</th>
                  <th className="py-3 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                {filteredRooms.map((r, idx) => {
                  const rItems = items.filter((i) => i.ruanganId === r.id);
                  const val = rItems.reduce((acc, curr) => acc + (curr.harga || 0), 0);
                  return (
                    <tr key={r.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                      <td className="py-2.5 px-4 text-slate-400">{idx + 1}</td>
                      <td className="py-2.5 px-4 font-mono font-bold text-emerald-700 dark:text-emerald-400">
                        {r.kodeRuangan}
                      </td>
                      <td className="py-2.5 px-4 font-bold text-slate-900 dark:text-white">
                        {r.namaRuangan}
                      </td>
                      <td className="py-2.5 px-4">{r.jenisRuangan}</td>
                      <td className="py-2.5 px-4">{r.gedung}, {r.lantai}</td>
                      <td className="py-2.5 px-4">{r.penanggungJawab}</td>
                      <td className="py-2.5 px-4 font-bold">{rItems.length} Unit</td>
                      <td className="py-2.5 px-4 font-semibold text-emerald-700 dark:text-emerald-400">
                        {formatRupiah(val)}
                      </td>
                      <td className="py-2.5 px-4">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                          {r.kondisiRuangan}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-right space-x-1">
                        <button
                          type="button"
                          onClick={() => onOpenPublicRoom(r.id)}
                          className="px-2.5 py-1 text-[11px] font-bold bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg"
                        >
                          Lihat Barang
                        </button>
                        <button
                          type="button"
                          onClick={() => onPrintRoomLabel(r)}
                          className="px-2 py-1 text-[11px] font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg"
                        >
                          Cetak QR
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Add / Edit Ruangan */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-600" />
                {editingRoom ? 'Edit Data Ruangan' : 'Tambah Ruangan Baru'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Error in Modal */}
            {modalError && (
              <div className="mt-3 p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-xl text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                <span className="leading-snug">{modalError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Kode Ruangan (Format e.g. R-KLS-X-01) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={kodeRuangan}
                    onChange={(e) => setKodeRuangan(e.target.value.toUpperCase())}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Nama Ruangan <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Ruang Kelas X-A"
                    value={namaRuangan}
                    onChange={(e) => setNamaRuangan(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Jenis Ruangan
                  </label>
                  <select
                    value={jenisRuangan}
                    onChange={(e) => setJenisRuangan(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  >
                    {jenisList.map((j) => (
                      <option key={j} value={j}>{j}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Penanggung Jawab Ruangan
                  </label>
                  <input
                    type="text"
                    placeholder="Nama Wali Kelas / Koordinator"
                    value={penanggungJawab}
                    onChange={(e) => setPenanggungJawab(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Gedung
                  </label>
                  <input
                    type="text"
                    value={gedung}
                    onChange={(e) => setGedung(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Lantai
                  </label>
                  <input
                    type="text"
                    value={lantai}
                    onChange={(e) => setLantai(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Luas (m²)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 80"
                    value={luasRuangan}
                    onChange={(e) => setLuasRuangan(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Kapasitas (Orang)
                  </label>
                  <input
                    type="number"
                    min={1}
                    placeholder="36"
                    value={kapasitas}
                    onChange={(e) => setKapasitas(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Kondisi Fisik Ruangan
                </label>
                <select
                  value={kondisiRuangan}
                  onChange={(e) => setKondisiRuangan(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                >
                  <option value="Baik">Baik (Siap Pakai)</option>
                  <option value="Rusak Ringan">Rusak Ringan</option>
                  <option value="Rusak Sedang">Rusak Sedang</option>
                  <option value="Perlu Renovasi">Perlu Renovasi</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Foto Ruangan {isUploadingPhoto && <span className="text-amber-500 font-normal animate-pulse">(Mengompresi foto...)</span>}
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="flex-1 text-xs text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:bg-emerald-100 file:text-emerald-800"
                  />
                  {fotoRuangan && (
                    <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-emerald-500 shrink-0">
                      <img src={fotoRuangan} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Keterangan / Fasilitas Tambahan
                </label>
                <textarea
                  rows={2}
                  value={keterangan}
                  onChange={(e) => setKeterangan(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  disabled={isSubmitting}
                  className="px-4 py-2 font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || isUploadingPhoto}
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-60 text-white font-bold rounded-xl shadow-xs flex items-center gap-2 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Menyimpan Ruangan...</span>
                    </>
                  ) : (
                    <span>Simpan Ruangan</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Floating Success Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 bg-emerald-800 text-white text-xs font-bold rounded-2xl shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-bottom-3">
          <CheckCircle className="w-5 h-5 text-amber-300 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
