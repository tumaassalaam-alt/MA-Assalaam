import React, { useState } from 'react';
import {
  CheckSquare,
  Building2,
  Calendar,
  AlertCircle,
  CheckCircle2,
  FileSignature,
  Printer,
  Save,
  HelpCircle,
  Eye,
  Camera
} from 'lucide-react';
import {
  Room,
  Item,
  StockOpnameSession,
  StockOpnameItemCheck,
  UserRole,
  SchoolProfile
} from '../types';
import { StorageService } from '../services/storage';

interface StockOpnameViewProps {
  rooms: Room[];
  items: Item[];
  userRole: UserRole;
  schoolProfile: SchoolProfile;
  sessions: StockOpnameSession[];
  onSaveSession: (session: StockOpnameSession) => void;
}

export const StockOpnameView: React.FC<StockOpnameViewProps> = ({
  rooms,
  items,
  userRole,
  schoolProfile,
  sessions,
  onSaveSession
}) => {
  const [activeTab, setActiveTab] = useState<'check' | 'history'>('check');
  const [selectedRoomId, setSelectedRoomId] = useState(rooms[0]?.id || '');
  const [petugas, setPetugas] = useState('Bambang Supriyanto & Ahmad Fauzi');
  const [catatanKesimpulan, setCatatanKesimpulan] = useState('');
  const [activePrintSession, setActivePrintSession] = useState<StockOpnameSession | null>(null);

  const currentRoom = rooms.find((r) => r.id === selectedRoomId) || rooms[0];
  const roomItems = items.filter((i) => i.ruanganId === currentRoom?.id);

  // Local state for checking items in current room
  const [checkList, setCheckList] = useState<{ [kodeBarang: string]: StockOpnameItemCheck }>({});

  // Sync checklist when room changes
  React.useEffect(() => {
    const initial: { [k: string]: StockOpnameItemCheck } = {};
    roomItems.forEach((itm) => {
      initial[itm.kodeBarang] = {
        kodeBarang: itm.kodeBarang,
        namaBarang: itm.namaBarang,
        kondisiSistem: itm.kondisi,
        ditemukan: true,
        kondisiAktual: itm.kondisi,
        perluPerbaikan: itm.kondisi !== 'Baik',
        fotoDiperbarui: false,
        catatanFisik: ''
      };
    });
    setCheckList(initial);
  }, [selectedRoomId, roomItems.length]);

  const handleToggleDitemukan = (kode: string) => {
    setCheckList((prev) => ({
      ...prev,
      [kode]: {
        ...prev[kode],
        ditemukan: !prev[kode]?.ditemukan
      }
    }));
  };

  const handleChangeKondisiAktual = (kode: string, newKondisi: any) => {
    setCheckList((prev) => ({
      ...prev,
      [kode]: {
        ...prev[kode],
        kondisiAktual: newKondisi,
        perluPerbaikan: newKondisi !== 'Baik'
      }
    }));
  };

  const handleCatatanFisik = (kode: string, note: string) => {
    setCheckList((prev) => ({
      ...prev,
      [kode]: {
        ...prev[kode],
        catatanFisik: note
      }
    }));
  };

  // Live Discrepancy Computations
  const checks = Object.values(checkList);
  const totalSistem = roomItems.length;
  const totalDitemukan = checks.filter((c) => c.ditemukan).length;
  const totalHilang = totalSistem - totalDitemukan;
  const totalKondisiBerubah = checks.filter((c) => c.kondisiSistem !== c.kondisiAktual).length;
  const totalRusak = checks.filter((c) => c.kondisiAktual === 'Rusak Berat' || c.kondisiAktual === 'Rusak Ringan').length;

  const handleSaveOpname = () => {
    const seq = (sessions.length + 1).toString().padStart(3, '0');
    const nomorOpname = `OPNAME/MA-ASS/${new Date().getFullYear()}/${(new Date().getMonth() + 1).toString().padStart(2, '0')}/${seq}`;

    const newSession: StockOpnameSession = {
      id: `opn-${Date.now()}`,
      nomorOpname,
      tanggal: new Date().toISOString().split('T')[0],
      ruanganId: currentRoom.id,
      ruanganNama: currentRoom.namaRuangan,
      petugasPemeriksa: petugas.trim(),
      totalBarangSistem: totalSistem,
      totalDitemukan,
      totalHilang,
      totalKondisiBerubah,
      totalRusak,
      totalBarangTambahan: 0,
      items: checks,
      catatanKesimpulan: catatanKesimpulan.trim() || 'Pemeriksaan fisik sarpras ruangan telah dilaksanakan dengan tertib.',
      status: 'Selesai'
    };

    onSaveSession(newSession);
    setActivePrintSession(newSession);

    // If there were missing items or condition changed, trigger notification & audit
    if (totalHilang > 0 || totalKondisiBerubah > 0) {
      const waAdmin = StorageService.getSheetSettings().waAdminNumber;
      StorageService.sendWhatsAppNotification(
        waAdmin,
        'Kepala Madrasah & Tim Sarpras',
        'Stock Opname',
        `📋 *HASIL STOCK OPNAME - RUANG ${currentRoom.namaRuangan}*\n` +
        `Total Barang Sistem: ${totalSistem}\n` +
        `Ditemukan: ${totalDitemukan}\n` +
        `Selisih Tidak Ditemukan: ${totalHilang}\n` +
        `Kondisi Berubah: ${totalKondisiBerubah}\n\n` +
        `_Laporan Berita Acara Stock Opname telah disimpan di SIM SARPRAS._`
      );
    }

    alert('Sesi Stock Opname berhasil disimpan dan Berita Acara siap dicetak!');
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <CheckSquare className="w-6 h-6 text-emerald-600" />
            Stock Opname &amp; Checklist Fisik Inventaris
          </h1>
          <p className="text-xs text-slate-500">
            Pemeriksaan fisik sarana prasarana per ruangan, analisis selisih sistem vs temuan aktual, dan penerbitan Berita Acara Opname.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('check')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
              activeTab === 'check'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Form Checklist Ruangan
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
              activeTab === 'history'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            Riwayat Opname ({sessions.length})
          </button>
        </div>
      </div>

      {activeTab === 'check' && (
        <div className="space-y-6">
          {/* Room Selection & Examiner Info */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-emerald-600" />
                Pilih Ruangan yang Diperiksa
              </label>
              <select
                value={selectedRoomId}
                onChange={(e) => setSelectedRoomId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold text-slate-900 dark:text-white"
              >
                {rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.namaRuangan} ({r.kodeRuangan}) - {r.gedung}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Nama Petugas Pemeriksa
              </label>
              <input
                type="text"
                value={petugas}
                onChange={(e) => setPetugas(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Tanggal Pemeriksaan Fisik
              </label>
              <input
                type="date"
                defaultValue={new Date().toISOString().split('T')[0]}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
              />
            </div>
          </div>

          {/* REALTIME DISCREPANCY SCOREBOARD */}
          <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-5 rounded-3xl shadow-md border border-slate-700">
            <h3 className="text-xs font-black uppercase tracking-wider text-amber-400 mb-3 flex items-center gap-1.5">
              <CheckSquare className="w-4 h-4" />
              Laporan Selisih: Data Sistem vs Hasil Pemeriksaan Fisik
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-center">
              <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
                <span className="text-[10px] text-slate-400 block font-bold">Barang di Sistem</span>
                <span className="text-xl font-black text-white">{totalSistem}</span>
              </div>

              <div className="p-3 bg-emerald-500/10 rounded-2xl border border-emerald-500/30">
                <span className="text-[10px] text-emerald-300 block font-bold">Fisik Ditemukan</span>
                <span className="text-xl font-black text-emerald-400">{totalDitemukan}</span>
              </div>

              <div className="p-3 bg-rose-500/10 rounded-2xl border border-rose-500/30">
                <span className="text-[10px] text-rose-300 block font-bold">Tidak Ditemukan</span>
                <span className="text-xl font-black text-rose-400">{totalHilang}</span>
              </div>

              <div className="p-3 bg-amber-500/10 rounded-2xl border border-amber-500/30">
                <span className="text-[10px] text-amber-300 block font-bold">Kondisi Berubah</span>
                <span className="text-xl font-black text-amber-400">{totalKondisiBerubah}</span>
              </div>

              <div className="p-3 bg-blue-500/10 rounded-2xl border border-blue-500/30">
                <span className="text-[10px] text-blue-300 block font-bold">Barang Rusak</span>
                <span className="text-xl font-black text-blue-400">{totalRusak}</span>
              </div>
            </div>
          </div>

          {/* Interactive Checklist Table */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
                Checklist Item Barang di {currentRoom.namaRuangan} ({roomItems.length} Barang)
              </h3>
              <span className="text-xs text-slate-500">Klik status fisik untuk menyesuaikan</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-3">Status Fisik</th>
                    <th className="py-3 px-3">Kode Inventaris</th>
                    <th className="py-3 px-3">Nama Barang</th>
                    <th className="py-3 px-3">Kondisi Sistem</th>
                    <th className="py-3 px-3">Kondisi Aktual Lapangan</th>
                    <th className="py-3 px-3">Catatan / Keterangan Fisik</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  {roomItems.map((item) => {
                    const c = checkList[item.kodeBarang] || {
                      ditemukan: true,
                      kondisiAktual: item.kondisi,
                      catatanFisik: ''
                    };

                    return (
                      <tr
                        key={item.id}
                        className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/40 ${
                          !c.ditemukan ? 'bg-rose-50/50 dark:bg-rose-950/20' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3">
                          <button
                            type="button"
                            onClick={() => handleToggleDitemukan(item.kodeBarang)}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-colors cursor-pointer flex items-center gap-1 ${
                              c.ditemukan
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300'
                                : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-300'
                            }`}
                          >
                            {c.ditemukan ? (
                              <>
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                <span>Ditemukan</span>
                              </>
                            ) : (
                              <>
                                <AlertCircle className="w-3 h-3 text-rose-600" />
                                <span>Tidak Ada</span>
                              </>
                            )}
                          </button>
                        </td>

                        <td className="py-2.5 px-3 font-mono font-bold text-emerald-700 dark:text-emerald-400">
                          {item.kodeBarang}
                        </td>

                        <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                          {item.namaBarang}
                        </td>

                        <td className="py-2.5 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800">
                            {item.kondisi}
                          </span>
                        </td>

                        <td className="py-2.5 px-3">
                          <select
                            disabled={!c.ditemukan}
                            value={c.kondisiAktual}
                            onChange={(e) => handleChangeKondisiAktual(item.kodeBarang, e.target.value)}
                            className="px-2 py-1 bg-white dark:bg-slate-800 border rounded-lg text-xs font-bold"
                          >
                            <option value="Baik">Baik</option>
                            <option value="Rusak Ringan">Rusak Ringan</option>
                            <option value="Rusak Berat">Rusak Berat</option>
                          </select>
                        </td>

                        <td className="py-2.5 px-3">
                          <input
                            type="text"
                            placeholder="Catatan fisik..."
                            value={c.catatanFisik || ''}
                            onChange={(e) => handleCatatanFisik(item.kodeBarang, e.target.value)}
                            className="w-full px-2 py-1 bg-slate-50 dark:bg-slate-800 border rounded-lg text-xs"
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Bottom Save Action */}
            <div className="p-5 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="w-full sm:flex-1">
                <input
                  type="text"
                  placeholder="Kesimpulan hasil opname ruangan (opsional)..."
                  value={catatanKesimpulan}
                  onChange={(e) => setCatatanKesimpulan(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <button
                type="button"
                onClick={handleSaveOpname}
                className="w-full sm:w-auto px-6 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer hover:scale-105"
              >
                <Save className="w-4 h-4 text-amber-300" />
                <span>Simpan Hasil Opname &amp; Buat Berita Acara</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* History Tab */}
      {activeTab === 'history' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          {sessions.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-xs">
              Belum ada riwayat stock opname yang tersimpan. Lakukan pemeriksaan di tab Form Checklist.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {sessions.map((sess) => (
                <div key={sess.id} className="p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400 text-xs">
                        {sess.nomorOpname}
                      </span>
                      <span className="text-[10px] text-slate-400">• {sess.tanggal}</span>
                    </div>
                    <h4 className="text-sm font-extrabold text-slate-900 dark:text-white mt-0.5">
                      Ruang: {sess.ruanganNama}
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      Pemeriksa: {sess.petugasPemeriksa} • {sess.catatanKesimpulan}
                    </p>
                    <div className="flex items-center gap-3 text-xs font-semibold mt-2">
                      <span className="text-slate-600">Sistem: {sess.totalBarangSistem}</span>
                      <span className="text-emerald-600">Ditemukan: {sess.totalDitemukan}</span>
                      <span className="text-rose-600">Selisih: {sess.totalHilang}</span>
                      <span className="text-amber-600">Kondisi Berubah: {sess.totalKondisiBerubah}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setActivePrintSession(sess)}
                    className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Printer className="w-4 h-4 text-emerald-600" />
                    <span>Cetak Berita Acara Opname</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Official Stock Opname Berita Acara Print Modal */}
      {activePrintSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-4xl w-full p-8 shadow-2xl text-slate-900 my-auto print:m-0 print:p-6 print:border-none print:shadow-none print:w-full">
            {/* Action Bar */}
            <div className="no-print flex items-center justify-between pb-4 border-b mb-6">
              <span className="font-extrabold text-sm text-emerald-800">
                Berita Acara Stock Opname Inventaris (Siap Cetak)
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" />
                  Print / Simpan PDF
                </button>
                <button
                  type="button"
                  onClick={() => setActivePrintSession(null)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Tutup
                </button>
              </div>
            </div>

            {/* Official Kop Surat */}
            <div className="text-center border-b-2 border-slate-900 pb-4 mb-6">
              <div className="flex items-center justify-center gap-4 mb-2">
                <img
                  src={schoolProfile.logoUrl}
                  alt="Logo"
                  className="w-16 h-16 object-contain"
                />
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    {schoolProfile.yayasan}
                  </h4>
                  <h2 className="text-xl font-black uppercase text-slate-900">
                    {schoolProfile.namaMadrasah}
                  </h2>
                  <p className="text-[11px] text-slate-600">
                    {schoolProfile.alamat}, Desa {schoolProfile.desa}, Kec. {schoolProfile.kecamatan}, Kab. {schoolProfile.kabupaten} {schoolProfile.kodePos}
                  </p>
                  <p className="text-[10px] text-slate-500 font-mono">
                    NPSN: {schoolProfile.npsn} | NSM: {schoolProfile.nsm} | Telp: {schoolProfile.telepon}
                  </p>
                </div>
              </div>
              <div className="border-t border-slate-400 pt-3">
                <h3 className="text-sm font-black uppercase tracking-widest text-slate-900">
                  BERITA ACARA HASIL STOCK OPNAME INVENTARIS
                </h3>
                <span className="font-mono text-xs text-slate-700">
                  Nomor: {activePrintSession.nomorOpname}
                </span>
              </div>
            </div>

            {/* Content text */}
            <div className="space-y-4 text-xs leading-relaxed">
              <p>
                Pada hari ini, tanggal <strong>{activePrintSession.tanggal}</strong>, telah dilaksanakan pemeriksaan fisik sarana dan prasarana (Stock Opname) bertempat di <strong>{activePrintSession.ruanganNama}</strong> {schoolProfile.namaMadrasah} oleh petugas pemeriksa yang ditugaskan: <strong>{activePrintSession.petugasPemeriksa}</strong>.
              </p>

              {/* Rekapitulasi Tabel Hasil */}
              <div className="border border-slate-300 rounded-xl overflow-hidden my-4">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 font-bold border-b border-slate-300">
                    <tr>
                      <th className="py-2 px-3">Uraian Pemeriksaan Fisik</th>
                      <th className="py-2 px-3 text-center">Jumlah Item</th>
                      <th className="py-2 px-3">Keterangan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="py-1.5 px-3">Total Barang Tercatat Dalam Sistem</td>
                      <td className="py-1.5 px-3 text-center font-bold">{activePrintSession.totalBarangSistem} Unit</td>
                      <td className="py-1.5 px-3">Sesuai basis data</td>
                    </tr>
                    <tr>
                      <td className="py-1.5 px-3">Barang Fisik Berhasil Ditemukan</td>
                      <td className="py-1.5 px-3 text-center font-bold text-emerald-800">{activePrintSession.totalDitemukan} Unit</td>
                      <td className="py-1.5 px-3">Ada di ruangan</td>
                    </tr>
                    <tr>
                      <td className="py-1.5 px-3">Selisih Barang Tidak Ditemukan</td>
                      <td className="py-1.5 px-3 text-center font-bold text-rose-800">{activePrintSession.totalHilang} Unit</td>
                      <td className="py-1.5 px-3">Perlu penelusuran</td>
                    </tr>
                    <tr>
                      <td className="py-1.5 px-3">Barang Mengalami Perubahan Kondisi Fisik</td>
                      <td className="py-1.5 px-3 text-center font-bold text-amber-800">{activePrintSession.totalKondisiBerubah} Unit</td>
                      <td className="py-1.5 px-3">Telah diperbarui</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <p>
                <strong>Catatan &amp; Kesimpulan Pemeriksaan:</strong> {activePrintSession.catatanKesimpulan}
              </p>

              <p>
                Demikian Berita Acara Stock Opname ini dibuat dengan sebenarnya dalam rangkap secukupnya untuk dipergunakan sebagaimana mestinya.
              </p>

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-8 pt-8 text-center text-xs">
                <div>
                  <p>Petugas Pemeriksa Sarpras,</p>
                  <div className="h-16" />
                  <p className="font-bold underline">{activePrintSession.petugasPemeriksa}</p>
                  <p className="text-[10px] text-slate-500">Tim Inventaris Sarpras</p>
                </div>

                <div>
                  <p>Mengetahui,</p>
                  <p>Kepala Madrasah Aliyah Assalaam,</p>
                  <div className="h-14" />
                  <p className="font-bold underline">{schoolProfile.kepalaMadrasah}</p>
                  <p className="text-[10px] text-slate-500 font-mono">NIP. {schoolProfile.nipKepalaMadrasah || '-'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
