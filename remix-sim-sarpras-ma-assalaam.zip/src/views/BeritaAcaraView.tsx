import React, { useState } from 'react';
import {
  FileSignature,
  Printer,
  Calendar,
  Building2,
  Package,
  User,
  CheckCircle2,
  Download
} from 'lucide-react';
import {
  Item,
  Room,
  Mutation,
  Loan,
  Disposal,
  SchoolProfile
} from '../types';
import { formatRupiah } from '../services/barcodeGenerator';

interface BeritaAcaraViewProps {
  items: Item[];
  rooms: Room[];
  mutations: Mutation[];
  loans: Loan[];
  disposals: Disposal[];
  schoolProfile: SchoolProfile;
  initialType?: 'pemeriksaan' | 'serah_terima' | 'mutasi' | 'penghapusan' | 'peminjaman';
}

export const BeritaAcaraView: React.FC<BeritaAcaraViewProps> = ({
  items,
  rooms,
  mutations,
  loans,
  disposals,
  schoolProfile,
  initialType = 'pemeriksaan'
}) => {
  const [docType, setDocType] = useState<
    'pemeriksaan' | 'serah_terima' | 'mutasi' | 'penghapusan' | 'peminjaman'
  >(initialType);

  // Selected item / transaction for document
  const [selectedMutationId, setSelectedMutationId] = useState(mutations[0]?.id || '');
  const [selectedLoanId, setSelectedLoanId] = useState(loans[0]?.id || '');
  const [selectedDisposalId, setSelectedDisposalId] = useState(disposals[0]?.id || '');
  const [selectedRoomId, setSelectedRoomId] = useState(rooms[0]?.id || '');
  const [penerimaNama, setPenerimaNama] = useState('Ust. Aep Saepudin, S.Ag.');
  const [penerimaJabatan, setPenerimaJabatan] = useState('Wali Kelas X-A');

  const activeMutation = mutations.find((m) => m.id === selectedMutationId) || mutations[0];
  const activeLoan = loans.find((l) => l.id === selectedLoanId) || loans[0];
  const activeDisposal = disposals.find((d) => d.id === selectedDisposalId) || disposals[0];
  const activeRoom = rooms.find((r) => r.id === selectedRoomId) || rooms[0];
  const roomItems = items.filter((i) => i.ruanganId === activeRoom?.id);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Header controls (No print) */}
      <div className="no-print bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <FileSignature className="w-6 h-6 text-emerald-600" />
              Generator Dokumen Berita Acara Resmi
            </h1>
            <p className="text-xs text-slate-500">
              Dokumen legal pertanggungjawaban sarpras madrasah dengan format standar kementerian agama &amp; yayasan.
            </p>
          </div>

          <button
            type="button"
            onClick={handlePrint}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer hover:scale-105"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak Dokumen / Simpan PDF</span>
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex flex-wrap gap-2 text-xs">
          <button
            onClick={() => setDocType('pemeriksaan')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              docType === 'pemeriksaan'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            1. BA Pemeriksaan Inventaris
          </button>

          <button
            onClick={() => setDocType('serah_terima')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              docType === 'serah_terima'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            2. BA Serah Terima Barang
          </button>

          <button
            onClick={() => setDocType('mutasi')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              docType === 'mutasi'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            3. BA Mutasi Barang
          </button>

          <button
            onClick={() => setDocType('penghapusan')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              docType === 'penghapusan'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            4. BA Penghapusan Barang
          </button>

          <button
            onClick={() => setDocType('peminjaman')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
              docType === 'peminjaman'
                ? 'bg-emerald-700 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            5. BA Peminjaman Barang
          </button>
        </div>

        {/* Sub-selector based on document type */}
        <div className="pt-2 text-xs flex flex-wrap items-center gap-3">
          {docType === 'mutasi' && (
            <div className="flex items-center gap-2">
              <span className="font-bold">Pilih Transaksi Mutasi:</span>
              <select
                value={selectedMutationId}
                onChange={(e) => setSelectedMutationId(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
              >
                {mutations.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.nomorMutasi} - {m.namaBarang} ({m.ruanganAsalNama} ➔ {m.ruanganTujuanNama})
                  </option>
                ))}
              </select>
            </div>
          )}

          {docType === 'peminjaman' && (
            <div className="flex items-center gap-2">
              <span className="font-bold">Pilih Transaksi Peminjaman:</span>
              <select
                value={selectedLoanId}
                onChange={(e) => setSelectedLoanId(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
              >
                {loans.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.nomorPeminjaman} - {l.namaBarang} ({l.peminjam})
                  </option>
                ))}
              </select>
            </div>
          )}

          {docType === 'penghapusan' && (
            <div className="flex items-center gap-2">
              <span className="font-bold">Pilih Transaksi Penghapusan:</span>
              <select
                value={selectedDisposalId}
                onChange={(e) => setSelectedDisposalId(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
              >
                {disposals.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.nomorPenghapusan} - {d.namaBarang}
                  </option>
                ))}
              </select>
            </div>
          )}

          {(docType === 'pemeriksaan' || docType === 'serah_terima') && (
            <div className="flex items-center gap-2">
              <span className="font-bold">Pilih Ruangan:</span>
              <select
                value={selectedRoomId}
                onChange={(e) => setSelectedRoomId(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border rounded-xl font-bold"
              >
                {rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.namaRuangan} ({r.kodeRuangan})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* PRINT AREA */}
      <div className="print-area bg-white p-8 sm:p-12 max-w-4xl mx-auto rounded-3xl border border-slate-200 shadow-md text-slate-900 print:shadow-none print:border-none print:m-0 print:p-4 print:max-w-none print:w-full">
        {/* Official Kop Surat */}
        <div className="border-b-4 border-double border-slate-900 pb-4 mb-6 text-center">
          <div className="flex items-center justify-center gap-5 mb-2">
            <img
              src={schoolProfile.logoUrl}
              alt="Logo"
              className="w-20 h-20 object-contain"
            />
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest text-slate-800">
                {schoolProfile.yayasan}
              </h4>
              <h2 className="text-2xl font-black uppercase text-slate-950 tracking-wide font-serif">
                {schoolProfile.namaMadrasah}
              </h2>
              <p className="text-xs text-slate-600 font-medium">
                {schoolProfile.alamat}, Desa {schoolProfile.desa}, Kec. {schoolProfile.kecamatan}, Kab. {schoolProfile.kabupaten} {schoolProfile.kodePos}
              </p>
              <p className="text-[11px] text-slate-500 font-mono">
                NPSN: {schoolProfile.npsn} | NSM: {schoolProfile.nsm} | Telp: {schoolProfile.telepon}
              </p>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-400 text-center">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-900">
              {docType === 'pemeriksaan' && 'BERITA ACARA PEMERIKSAAN INVENTARIS SARPRAS'}
              {docType === 'serah_terima' && 'BERITA ACARA SERAH TERIMA BARANG INVENTARIS'}
              {docType === 'mutasi' && 'BERITA ACARA MUTASI / PEMINDAHAN BARANG'}
              {docType === 'penghapusan' && 'BERITA ACARA PENGHAPUSAN ASET MADRASAH'}
              {docType === 'peminjaman' && 'BERITA ACARA PEMINJAMAN SARANA PRASARANA'}
            </h3>
            <p className="text-xs text-slate-600 font-mono">
              Nomor: BA/MA-ASS/{docType.toUpperCase()}/{new Date().getFullYear()}/001 • Tahun Pelajaran {schoolProfile.tahunPelajaran || '2025/2026'}
            </p>
          </div>
        </div>

        {/* Body content based on docType */}
        <div className="space-y-4 text-xs leading-relaxed">
          <p>
            Pada hari ini, tanggal <strong>{new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</strong>, bertempat di lingkungan {schoolProfile.namaMadrasah} Bandung, kami yang bertanda tangan di bawah ini:
          </p>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <div className="grid grid-cols-4 gap-2">
              <span className="font-bold">1. Nama:</span>
              <span className="col-span-3">Ahmad Fauzi, S.Kom.</span>
              <span className="font-bold">Jabatan:</span>
              <span className="col-span-3">Koordinator Sarana &amp; Prasarana (Pihak Pertama)</span>
            </div>

            <div className="border-t border-slate-200 pt-2 grid grid-cols-4 gap-2">
              <span className="font-bold">2. Nama:</span>
              <span className="col-span-3">
                {docType === 'mutasi' ? activeMutation?.penanggungJawabBaru : penerimaNama}
              </span>
              <span className="font-bold">Jabatan:</span>
              <span className="col-span-3">
                {docType === 'mutasi' ? 'Penanggung Jawab Ruangan Baru' : penerimaJabatan} (Pihak Kedua)
              </span>
            </div>
          </div>

          {/* Contextual Narrative */}
          {docType === 'pemeriksaan' && (
            <div>
              <p>
                Telah melaksanakan pemeriksaan fisik secara berkala terhadap seluruh sarana dan prasarana yang berada pada <strong>{activeRoom.namaRuangan} ({activeRoom.kodeRuangan})</strong> dengan rincian barang sebagai berikut:
              </p>
              <table className="w-full text-left text-xs border border-slate-300 my-3">
                <thead className="bg-slate-100 font-bold border-b border-slate-300">
                  <tr>
                    <th className="py-1.5 px-2">No</th>
                    <th className="py-1.5 px-2">Kode Barang</th>
                    <th className="py-1.5 px-2">Nama Barang</th>
                    <th className="py-1.5 px-2">Merk / Spesifikasi</th>
                    <th className="py-1.5 px-2">Kondisi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {roomItems.slice(0, 10).map((itm, i) => (
                    <tr key={itm.id}>
                      <td className="py-1 px-2">{i + 1}</td>
                      <td className="py-1 px-2 font-mono">{itm.kodeBarang}</td>
                      <td className="py-1 px-2 font-semibold">{itm.namaBarang}</td>
                      <td className="py-1 px-2">{itm.merk} - {itm.spesifikasi}</td>
                      <td className="py-1 px-2 font-bold">{itm.kondisi}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p>Total aset terverifikasi di ruangan ini sejumlah <strong>{roomItems.length}</strong> unit barang dalam kondisi siap digunakan.</p>
            </div>
          )}

          {docType === 'mutasi' && activeMutation && (
            <div>
              <p>
                Menyatakan dengan sesungguhnya telah melakukan mutasi / pemindahan aset sarpras inventaris:
              </p>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5 my-2">
                <div>Kode Barang: <strong>{activeMutation.kodeBarang}</strong></div>
                <div>Nama Barang: <strong>{activeMutation.namaBarang}</strong></div>
                <div>Ruangan Asal: <strong>{activeMutation.ruanganAsalNama}</strong> (PJ: {activeMutation.penanggungJawabLama})</div>
                <div>Ruangan Tujuan: <strong>{activeMutation.ruanganTujuanNama}</strong> (PJ: {activeMutation.penanggungJawabBaru})</div>
                <div>Alasan Mutasi: <em>{activeMutation.alasanMutasi}</em></div>
              </div>
              <p>Terhitung sejak penandatanganan berita acara ini, tanggung jawab pemeliharaan beralih sepenuhnya kepada Pihak Kedua.</p>
            </div>
          )}

          {docType === 'peminjaman' && activeLoan && (
            <div>
              <p>
                Pihak Pertama telah meminjamkan barang aset inventaris kepada Pihak Kedua dengan rincian:
              </p>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1 my-2">
                <div>Nomor Pinjam: <strong>{activeLoan.nomorPeminjaman}</strong></div>
                <div>Barang: <strong>{activeLoan.namaBarang}</strong> ({activeLoan.kodeBarang})</div>
                <div>Jumlah: <strong>{activeLoan.jumlah} Unit</strong></div>
                <div>Tanggal Pinjam: <strong>{activeLoan.tanggalPinjam}</strong></div>
                <div>Batas Rencana Kembali: <strong>{activeLoan.rencanaKembali}</strong></div>
                <div>Keperluan: {activeLoan.keterangan}</div>
              </div>
              <p>Pihak Kedua bertanggung jawab penuh menjaga keutuhan dan mengembalikan barang sesuai batas waktu dalam kondisi prima.</p>
            </div>
          )}

          {docType === 'penghapusan' && activeDisposal && (
            <div>
              <p>
                Berdasarkan hasil verifikasi tim sarpras dan persetujuan pimpinan madrasah, telah diputuskan penghapusan aset:
              </p>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1 my-2">
                <div>Nomor SK Penghapusan: <strong>{activeDisposal.nomorPenghapusan}</strong></div>
                <div>Barang: <strong>{activeDisposal.namaBarang}</strong> ({activeDisposal.kodeBarang})</div>
                <div>Tahun Perolehan: <strong>{activeDisposal.tahunPerolehan}</strong> (Harga: {formatRupiah(activeDisposal.hargaPerolehan)})</div>
                <div>Kondisi Terakhir: <strong>{activeDisposal.kondisiTerakhir}</strong></div>
                <div>Metode Penghapusan: <strong>{activeDisposal.metodePenghapusan}</strong></div>
                <div>Alasan: {activeDisposal.alasanPenghapusan}</div>
              </div>
              <p>Aset tersebut secara administratif dikeluarkan dari daftar aset aktif dan tercatat pada buku aset afkir madrasah.</p>
            </div>
          )}

          <p className="pt-2">
            Demikian Berita Acara ini kami buat dengan sebenarnya tanpa ada paksaan dari pihak manapun, untuk dipergunakan sebagaimana mestinya.
          </p>

          {/* Signatures */}
          <div className="grid grid-cols-3 gap-4 pt-10 text-center text-xs">
            <div>
              <p>Pihak Pertama,</p>
              <div className="h-16" />
              <p className="font-bold underline">Ahmad Fauzi, S.Kom.</p>
              <p className="text-[10px] text-slate-500">Koordinator Sarpras</p>
            </div>

            <div>
              <p>Pihak Kedua,</p>
              <div className="h-16" />
              <p className="font-bold underline">
                {docType === 'mutasi' ? activeMutation?.penanggungJawabBaru : penerimaNama}
              </p>
              <p className="text-[10px] text-slate-500">Penerima Kuasa</p>
            </div>

            <div>
              <p>Mengetahui,</p>
              <p>Kepala MA Assalaam</p>
              <div className="h-14" />
              <p className="font-bold underline">{schoolProfile.kepalaMadrasah}</p>
              <p className="text-[10px] text-slate-500 font-mono">NIP. {schoolProfile.nipKepalaMadrasah || '-'}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
