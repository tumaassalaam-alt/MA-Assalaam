import * as XLSX from 'xlsx';
import {
  SchoolProfile,
  Category,
  Room,
  Item,
  User,
  Mutation,
  Loan,
  Maintenance,
  Disposal,
  LostItem,
  LibraryBook,
  DamageReport,
  AuditLog,
  StockOpnameSession,
  WhatsAppNotification
} from '../types';
import {
  defaultSchoolProfile,
  defaultCategories,
  defaultRooms,
  defaultItems,
  defaultUsers,
  defaultMutations,
  defaultLoans,
  defaultMaintenance,
  defaultDisposals,
  defaultLostItems,
  defaultBooks,
  defaultDamageReports,
  defaultAuditLogs
} from '../data/defaultData';

const STORAGE_KEYS = {
  PROFILE: 'sim_sarpras_school_profile',
  CATEGORIES: 'sim_sarpras_categories',
  ROOMS: 'sim_sarpras_rooms',
  ITEMS: 'sim_sarpras_items',
  USERS: 'sim_sarpras_users',
  MUTATIONS: 'sim_sarpras_mutations',
  LOANS: 'sim_sarpras_loans',
  MAINTENANCE: 'sim_sarpras_maintenance',
  DISPOSALS: 'sim_sarpras_disposals',
  LOST_ITEMS: 'sim_sarpras_lost_items',
  BOOKS: 'sim_sarpras_books',
  DAMAGE_REPORTS: 'sim_sarpras_damage_reports',
  AUDIT_LOGS: 'sim_sarpras_audit_logs',
  STOCK_OPNAME: 'sim_sarpras_stock_opname',
  WA_LOGS: 'sim_sarpras_wa_logs',
  CURRENT_USER: 'sim_sarpras_current_user',
  SHEET_SETTINGS: 'sim_sarpras_sheet_settings'
};

export interface SheetSettings {
  sheetUrl: string;
  scriptUrl: string;
  autoSync: boolean;
  lastSyncTime?: string;
  waAdminNumber: string;
  connected?: boolean;
}

export class StorageService {
  // --- Initialize with defaults if empty & migrate existing data ---
  static init(): void {
    const profileRaw = localStorage.getItem(STORAGE_KEYS.PROFILE);
    if (!profileRaw) {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(defaultSchoolProfile));
    } else {
      try {
        const parsed = JSON.parse(profileRaw);
        let updated = false;
        if (!parsed.namaMadrasah || parsed.namaMadrasah.includes('Sasakgantung') || parsed.namaMadrasah === 'Madrasah Aliyah Assalaam') {
          parsed.namaMadrasah = 'Madrasah Aliyah Assalaam Arjasari';
          updated = true;
        }
        if (!parsed.tahunPelajaran) {
          parsed.tahunPelajaran = '2025/2026';
          updated = true;
        }
        if (parsed.logoUrl && parsed.logoUrl.includes('SASAKGANTUNG BANDUNG')) {
          parsed.logoUrl = defaultSchoolProfile.logoUrl;
          updated = true;
        }
        if (updated) {
          localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(parsed));
        }
      } catch (e) {
        localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(defaultSchoolProfile));
      }
    }

    if (!localStorage.getItem(STORAGE_KEYS.CATEGORIES)) {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(defaultCategories));
    }
    if (!localStorage.getItem(STORAGE_KEYS.ROOMS)) {
      localStorage.setItem(STORAGE_KEYS.ROOMS, JSON.stringify(defaultRooms));
    }
    if (!localStorage.getItem(STORAGE_KEYS.ITEMS)) {
      localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(defaultItems));
    }
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(defaultUsers));
    }
    if (!localStorage.getItem(STORAGE_KEYS.MUTATIONS)) {
      localStorage.setItem(STORAGE_KEYS.MUTATIONS, JSON.stringify(defaultMutations));
    }
    if (!localStorage.getItem(STORAGE_KEYS.LOANS)) {
      localStorage.setItem(STORAGE_KEYS.LOANS, JSON.stringify(defaultLoans));
    }
    if (!localStorage.getItem(STORAGE_KEYS.MAINTENANCE)) {
      localStorage.setItem(STORAGE_KEYS.MAINTENANCE, JSON.stringify(defaultMaintenance));
    }
    if (!localStorage.getItem(STORAGE_KEYS.DISPOSALS)) {
      localStorage.setItem(STORAGE_KEYS.DISPOSALS, JSON.stringify(defaultDisposals));
    }
    if (!localStorage.getItem(STORAGE_KEYS.LOST_ITEMS)) {
      localStorage.setItem(STORAGE_KEYS.LOST_ITEMS, JSON.stringify(defaultLostItems));
    }
    if (!localStorage.getItem(STORAGE_KEYS.BOOKS)) {
      localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(defaultBooks));
    }
    if (!localStorage.getItem(STORAGE_KEYS.DAMAGE_REPORTS)) {
      localStorage.setItem(STORAGE_KEYS.DAMAGE_REPORTS, JSON.stringify(defaultDamageReports));
    }
    if (!localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS)) {
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(defaultAuditLogs));
    }
    if (!localStorage.getItem(STORAGE_KEYS.STOCK_OPNAME)) {
      localStorage.setItem(STORAGE_KEYS.STOCK_OPNAME, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.WA_LOGS)) {
      localStorage.setItem(STORAGE_KEYS.WA_LOGS, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.SHEET_SETTINGS)) {
      const defaultSettings: SheetSettings = {
        sheetUrl: 'https://docs.google.com/spreadsheets/d/1_SIM_SARPRAS_MA_ASSALAAM_BANDUNG/edit',
        scriptUrl: '',
        autoSync: true,
        lastSyncTime: new Date().toISOString(),
        waAdminNumber: '081223456789',
        connected: true
      };
      localStorage.setItem(STORAGE_KEYS.SHEET_SETTINGS, JSON.stringify(defaultSettings));
    }

    // Ensure tumaassalaam@gmail.com is present in local users
    try {
      const usersRaw = localStorage.getItem(STORAGE_KEYS.USERS);
      if (usersRaw) {
        const parsedUsers: User[] = JSON.parse(usersRaw);
        if (!parsedUsers.some(u => u.email.toLowerCase() === 'tumaassalaam@gmail.com' || u.username.toLowerCase() === 'tumaassalaam')) {
          parsedUsers.unshift(defaultUsers[0]);
          localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(parsedUsers));
        }
      }
    } catch (e) {}

    // Pull central database from server so all sessions/devices share the exact same state
    this.fetchServerDatabase();
  }

  // --- Central Server Database Synchronization ---
  static async fetchServerDatabase(): Promise<boolean> {
    try {
      const res = await fetch('/api/database');
      if (!res.ok) return false;
      const data = await res.json();
      if (data.success && data.database) {
        const db = data.database;
        if (db.schoolProfile) localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(db.schoolProfile));
        if (db.categories) localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(db.categories));
        if (db.rooms) localStorage.setItem(STORAGE_KEYS.ROOMS, JSON.stringify(db.rooms));
        if (db.items) localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(db.items));
        if (db.users) localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(db.users));
        if (db.mutations) localStorage.setItem(STORAGE_KEYS.MUTATIONS, JSON.stringify(db.mutations));
        if (db.loans) localStorage.setItem(STORAGE_KEYS.LOANS, JSON.stringify(db.loans));
        if (db.maintenance) localStorage.setItem(STORAGE_KEYS.MAINTENANCE, JSON.stringify(db.maintenance));
        if (db.disposals) localStorage.setItem(STORAGE_KEYS.DISPOSALS, JSON.stringify(db.disposals));
        if (db.lostItems) localStorage.setItem(STORAGE_KEYS.LOST_ITEMS, JSON.stringify(db.lostItems));
        if (db.books) localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(db.books));
        if (db.damageReports) localStorage.setItem(STORAGE_KEYS.DAMAGE_REPORTS, JSON.stringify(db.damageReports));
        if (db.auditLogs) localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(db.auditLogs));
        if (db.stockOpnames) localStorage.setItem(STORAGE_KEYS.STOCK_OPNAME, JSON.stringify(db.stockOpnames));
        if (db.sheetSettings) {
          const localSettings = this.getSheetSettings();
          const localHasRealUrl = localSettings.sheetUrl && !localSettings.sheetUrl.includes('1_SIM_SARPRAS_MA_ASSALAAM_BANDUNG');
          const serverIsDummy = !db.sheetSettings.sheetUrl || db.sheetSettings.sheetUrl.includes('1_SIM_SARPRAS_MA_ASSALAAM_BANDUNG');
          if (localHasRealUrl && serverIsDummy) {
            this.syncToServer();
          } else {
            localStorage.setItem(STORAGE_KEYS.SHEET_SETTINGS, JSON.stringify(db.sheetSettings));
          }
        }

        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('sarpras-database-synced'));
        }
        return true;
      }
    } catch (e) {
      console.warn('Could not fetch server database, using cached local data:', e);
    }
    return false;
  }

  static async syncToServer(actorEmail?: string): Promise<boolean> {
    const current = this.getCurrentUser();
    const actor = actorEmail || current?.email || current?.username;
    if (!actor) return false;

    try {
      const payload = {
        actorEmail: actor,
        data: {
          schoolProfile: this.getSchoolProfile(),
          categories: this.getCategories(),
          rooms: this.getRooms(),
          items: this.getItems(),
          users: this.getUsers(),
          mutations: this.getMutations(),
          loans: this.getLoans(),
          maintenance: this.getMaintenance(),
          disposals: this.getDisposals(),
          lostItems: this.getLostItems(),
          books: this.getBooks(),
          damageReports: this.getDamageReports(),
          auditLogs: this.getAuditLogs(),
          stockOpnames: this.getStockOpnameSessions(),
          sheetSettings: this.getSheetSettings()
        }
      };

      const res = await fetch('/api/database/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      return res.ok;
    } catch (e) {
      console.warn('Background sync to server warning:', e);
      return false;
    }
  }

  // --- Automatic synchronization trigger with Google Spreadsheet ---
  static triggerAutoSync(actionSummary?: string): void {
    const settings = this.getSheetSettings();
    if (!settings.autoSync) return;

    const timestamp = new Date().toISOString();
    const updatedSettings: SheetSettings = {
      ...settings,
      lastSyncTime: timestamp,
      connected: true
    };
    localStorage.setItem(STORAGE_KEYS.SHEET_SETTINGS, JSON.stringify(updatedSettings));

    // If Google Apps Script Web App URL is present, push background sync
    if (settings.scriptUrl && settings.scriptUrl.startsWith('http')) {
      try {
        const payload = {
          action: 'auto_sync',
          timestamp,
          summary: actionSummary || 'Pembaruan data otomatis',
          items: this.getItems(),
          rooms: this.getRooms(),
          mutations: this.getMutations(),
          loans: this.getLoans(),
          maintenance: this.getMaintenance(),
          disposals: this.getDisposals(),
          lostItems: this.getLostItems(),
          books: this.getBooks(),
          profile: this.getSchoolProfile()
        };

        // 1. Try server proxy push to handle 302 redirects and CORS
        fetch('/api/spreadsheet/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ scriptUrl: settings.scriptUrl, payload })
        }).catch(() => {
          // 2. Direct browser fallback
          fetch(settings.scriptUrl, {
            method: 'POST',
            mode: 'no-cors',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          }).catch((err) => {
            console.warn('Background spreadsheet sync warning:', err);
          });
        });
      } catch (err) {
        // silent catch
      }
    }

    // Broadcast sync event to UI components (Header, BackupSyncView, etc.)
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('sarpras-spreadsheet-sync', {
          detail: { timestamp, action: actionSummary }
        })
      );
    }
  }

  // --- Auth & Session ---
  static getCurrentUser(): User | null {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return data ? JSON.parse(data) : null;
  }

  static setCurrentUser(user: User | null): void {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  }

  static async login(usernameOrEmail: string, pass?: string): Promise<{ success: boolean; user?: User; message?: string }> {
    const cleanUser = usernameOrEmail.trim().toLowerCase();

    // 1. Authenticate with server database API first
    try {
      const res = await fetch('/api/database/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: cleanUser, password: pass })
      });
      const data = await res.json();
      if (res.ok && data.success && data.user) {
        this.setCurrentUser(data.user);
        this.addAuditLog(data.user, 'Login ke dalam sistem SIM SARPRAS MA ASSALAAM', 'Autentikasi');
        this.fetchServerDatabase();
        return { success: true, user: data.user };
      } else {
        return {
          success: false,
          message: data.message || `Akses Ditolak: Email atau Akun "${usernameOrEmail}" belum terdaftar dalam database aplikasi ini!`
        };
      }
    } catch (e) {
      // 2. Offline fallback to local cached users
      const users = this.getUsers();
      const found = users.find(u => u.username.toLowerCase() === cleanUser || u.email.toLowerCase() === cleanUser);
      if (!found) {
        return {
          success: false,
          message: `Akses Ditolak: Email atau Akun "${usernameOrEmail}" belum terdaftar dalam database aplikasi ini!`
        };
      }
      if (!found.aktif) {
        return { success: false, message: 'Akun Anda dinonaktifkan oleh Administrator.' };
      }
      if (found.password && pass && found.password !== pass) {
        return { success: false, message: 'Password salah!' };
      }
      this.setCurrentUser(found);
      this.addAuditLog(found, 'Login ke dalam sistem SIM SARPRAS MA ASSALAAM', 'Autentikasi');
      return { success: true, user: found };
    }
  }

  static registerUser(newUser: Omit<User, 'id' | 'createdAt'>): { success: boolean; user?: User; message?: string } {
    const users = this.getUsers();
    const cleanUsername = newUser.username.trim().toLowerCase();

    if (users.some(u => u.username.toLowerCase() === cleanUsername)) {
      return { success: false, message: 'Username sudah digunakan, silakan pilih username lain.' };
    }
    if (users.some(u => u.email.toLowerCase() === newUser.email.trim().toLowerCase())) {
      return { success: false, message: 'Email sudah terdaftar dalam sistem.' };
    }

    const created: User = {
      ...newUser,
      id: `usr-${Date.now()}`,
      username: cleanUsername,
      createdAt: new Date().toISOString()
    };

    users.push(created);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    this.syncToServer(this.getCurrentUser()?.email || created.email);

    this.addAuditLog(created, `Pendaftaran akun baru: ${created.nama} (${created.role})`, 'Pengguna');
    return { success: true, user: created };
  }

  static logout(): void {
    const user = this.getCurrentUser();
    if (user) {
      this.addAuditLog(user, 'Logout dari sistem SIM SARPRAS MA ASSALAAM', 'Autentikasi');
    }
    this.setCurrentUser(null);
  }

  // --- Audit Logging ---
  static addAuditLog(
    user: User | { nama: string; role: string; id: string } | null,
    aktivitas: string,
    modul: string,
    dataSebelum?: string,
    dataSesudah?: string
  ): void {
    const logs = this.getAuditLogs();
    const now = new Date();
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId: user?.id || 'guest',
      userName: user ? `${user.nama} (${user.role})` : 'Tamu / Umum (Tanpa Login)',
      userRole: user?.role || 'UMUM',
      timestamp: now.toISOString(),
      tanggal: now.toLocaleDateString('id-ID'),
      jam: now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      aktivitas,
      modul,
      dataSebelum,
      dataSesudah
    };
    logs.unshift(newLog);
    // keep last 500 logs
    if (logs.length > 500) logs.pop();
    localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(logs));
  }

  static getAuditLogs(): AuditLog[] {
    const data = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
    return data ? JSON.parse(data) : [];
  }

  // --- WhatsApp Notification Trigger ---
  static sendWhatsAppNotification(
    targetNomor: string,
    targetNama: string,
    kategori: WhatsAppNotification['kategori'],
    pesan: string
  ): WhatsAppNotification {
    const logs = this.getWhatsAppLogs();
    const notif: WhatsAppNotification = {
      id: `wa-${Date.now()}`,
      timestamp: new Date().toISOString(),
      targetNomor,
      targetNama,
      kategori,
      pesan,
      status: 'Terkirim'
    };
    logs.unshift(notif);
    localStorage.setItem(STORAGE_KEYS.WA_LOGS, JSON.stringify(logs));
    return notif;
  }

  static getWhatsAppLogs(): WhatsAppNotification[] {
    const data = localStorage.getItem(STORAGE_KEYS.WA_LOGS);
    return data ? JSON.parse(data) : [];
  }

  // Helper to open real WhatsApp chat with prefilled message
  static openWhatsApp(phone: string, text: string): void {
    let clean = phone.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) clean = '62' + clean.slice(1);
    const url = `https://wa.me/${clean}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  }

  // Safe LocalStorage Set with Quota Handling
  static safeSetItem(key: string, value: string): boolean {
    try {
      localStorage.setItem(key, value);
      return true;
    } catch (e: any) {
      console.warn(`[StorageService] LocalStorage quota reached for "${key}", trimming non-essential cached data...`, e);
      try {
        // Prune older audit logs and wa logs to free up space
        const logs = this.getAuditLogs();
        if (logs.length > 25) {
          localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(logs.slice(0, 25)));
        }
        localStorage.removeItem(STORAGE_KEYS.WA_LOGS);
        localStorage.setItem(key, value);
        return true;
      } catch (retryErr) {
        console.error(`[StorageService] Unable to save to localStorage:`, retryErr);
        return false;
      }
    }
  }

  // --- Generic Getters & Setters ---
  static getSchoolProfile(): SchoolProfile {
    const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
    return data ? JSON.parse(data) : defaultSchoolProfile;
  }
  static saveSchoolProfile(profile: SchoolProfile, actor?: User): void {
    const old = this.getSchoolProfile();
    this.safeSetItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    this.addAuditLog(actor || null, 'Memperbarui profil madrasah & tahun pelajaran', 'Master Data', old.namaMadrasah, profile.namaMadrasah);
    this.triggerAutoSync('Pembaruan profil madrasah & tahun pelajaran');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getCategories(): Category[] {
    const data = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    return data ? JSON.parse(data) : defaultCategories;
  }
  static saveCategories(cats: Category[], actor?: User): void {
    this.safeSetItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(cats));
    this.addAuditLog(actor || null, 'Memperbarui data master kategori barang', 'Kategori');
    this.triggerAutoSync('Pembaruan master kategori barang');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getRooms(): Room[] {
    const data = localStorage.getItem(STORAGE_KEYS.ROOMS);
    return data ? JSON.parse(data) : defaultRooms;
  }
  static async saveRooms(rooms: Room[], actor?: User, specificRoom?: Room, deletedRoomId?: string): Promise<boolean> {
    this.safeSetItem(STORAGE_KEYS.ROOMS, JSON.stringify(rooms));
    this.addAuditLog(actor || null, 'Memperbarui data master ruangan', 'Ruangan');
    this.triggerAutoSync('Pembaruan data ruangan');

    const actorEmail = actor?.email || actor?.username || this.getCurrentUser()?.email;

    // 1. Direct fast server update for room
    if (specificRoom) {
      try {
        await fetch('/api/database/room/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ actorEmail, room: specificRoom })
        });
      } catch (e) {
        console.warn('Direct room save to server error:', e);
      }
    } else if (deletedRoomId) {
      try {
        await fetch('/api/database/room/delete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ actorEmail, roomId: deletedRoomId })
        });
      } catch (e) {}
    }

    // 2. Full background sync
    return await this.syncToServer(actorEmail);
  }

  static getItems(): Item[] {
    const data = localStorage.getItem(STORAGE_KEYS.ITEMS);
    return data ? JSON.parse(data) : defaultItems;
  }
  static saveItems(items: Item[], actor?: User, customActivity?: string): void {
    this.safeSetItem(STORAGE_KEYS.ITEMS, JSON.stringify(items));
    if (customActivity) {
      this.addAuditLog(actor || null, customActivity, 'Inventaris Barang');
    }
    this.triggerAutoSync(customActivity || 'Pembaruan data inventaris barang');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getUsers(): User[] {
    const data = localStorage.getItem(STORAGE_KEYS.USERS);
    return data ? JSON.parse(data) : defaultUsers;
  }
  static saveUsers(users: User[], actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    this.addAuditLog(actor || null, 'Memperbarui daftar pengguna sistem', 'Pengguna');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getMutations(): Mutation[] {
    const data = localStorage.getItem(STORAGE_KEYS.MUTATIONS);
    return data ? JSON.parse(data) : defaultMutations;
  }
  static saveMutations(muts: Mutation[], actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.MUTATIONS, JSON.stringify(muts));
    this.addAuditLog(actor || null, 'Mencatat mutasi barang', 'Mutasi');
    this.triggerAutoSync('Pencatatan mutasi barang');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getLoans(): Loan[] {
    const data = localStorage.getItem(STORAGE_KEYS.LOANS);
    return data ? JSON.parse(data) : defaultLoans;
  }
  static saveLoans(loans: Loan[], actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.LOANS, JSON.stringify(loans));
    this.addAuditLog(actor || null, 'Memperbarui data peminjaman barang', 'Peminjaman');
    this.triggerAutoSync('Pembaruan data peminjaman');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getMaintenance(): Maintenance[] {
    const data = localStorage.getItem(STORAGE_KEYS.MAINTENANCE);
    return data ? JSON.parse(data) : defaultMaintenance;
  }
  static saveMaintenance(maint: Maintenance[], actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.MAINTENANCE, JSON.stringify(maint));
    this.addAuditLog(actor || null, 'Memperbarui riwayat pemeliharaan barang', 'Pemeliharaan');
    this.triggerAutoSync('Pencatatan pemeliharaan / perbaikan barang');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getDisposals(): Disposal[] {
    const data = localStorage.getItem(STORAGE_KEYS.DISPOSALS);
    return data ? JSON.parse(data) : defaultDisposals;
  }
  static saveDisposals(disps: Disposal[], actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.DISPOSALS, JSON.stringify(disps));
    this.addAuditLog(actor || null, 'Mencatat penghapusan aset barang', 'Penghapusan');
    this.triggerAutoSync('Penghapusan aset barang');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getLostItems(): LostItem[] {
    const data = localStorage.getItem(STORAGE_KEYS.LOST_ITEMS);
    return data ? JSON.parse(data) : defaultLostItems;
  }
  static saveLostItems(items: LostItem[], actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.LOST_ITEMS, JSON.stringify(items));
    this.addAuditLog(actor || null, 'Memperbarui catatan barang hilang', 'Barang Hilang');
    this.triggerAutoSync('Pencatatan barang hilang');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getBooks(): LibraryBook[] {
    const data = localStorage.getItem(STORAGE_KEYS.BOOKS);
    return data ? JSON.parse(data) : defaultBooks;
  }
  static saveBooks(books: LibraryBook[], actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(books));
    this.addAuditLog(actor || null, 'Memperbarui data buku perpustakaan', 'Inventaris Buku');
    this.triggerAutoSync('Pembaruan inventaris buku');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getDamageReports(): DamageReport[] {
    const data = localStorage.getItem(STORAGE_KEYS.DAMAGE_REPORTS);
    return data ? JSON.parse(data) : defaultDamageReports;
  }
  static saveDamageReports(reps: DamageReport[], actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.DAMAGE_REPORTS, JSON.stringify(reps));
    this.triggerAutoSync('Laporan kerusakan barang baru');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getStockOpnameSessions(): StockOpnameSession[] {
    const data = localStorage.getItem(STORAGE_KEYS.STOCK_OPNAME);
    return data ? JSON.parse(data) : [];
  }
  static saveStockOpnameSessions(sessions: StockOpnameSession[], actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.STOCK_OPNAME, JSON.stringify(sessions));
    this.addAuditLog(actor || null, 'Menyimpan sesi Stock Opname inventaris', 'Stock Opname');
    this.triggerAutoSync('Pemeriksaan fisik / Stock opname sarpras');
    this.syncToServer(actor?.email || actor?.username);
  }

  static getSheetSettings(): SheetSettings {
    const data = localStorage.getItem(STORAGE_KEYS.SHEET_SETTINGS);
    return data ? JSON.parse(data) : {
      sheetUrl: 'https://docs.google.com/spreadsheets/d/1_SIM_SARPRAS_MA_ASSALAAM_BANDUNG/edit',
      scriptUrl: '',
      autoSync: true,
      lastSyncTime: new Date().toISOString(),
      waAdminNumber: '081223456789'
    };
  }
  static saveSheetSettings(settings: SheetSettings, actor?: User): void {
    localStorage.setItem(STORAGE_KEYS.SHEET_SETTINGS, JSON.stringify(settings));
    this.addAuditLog(actor || null, 'Memperbarui konfigurasi integrasi Google Spreadsheet & WhatsApp', 'Pengaturan');
    this.syncToServer(actor?.email || actor?.username);
  }

  // --- Export Full Database to JSON ---
  static exportFullBackup(): void {
    const fullData = {
      version: '1.0.0',
      appName: 'SIM SARPRAS MA ASSALAAM',
      exportedAt: new Date().toISOString(),
      schoolProfile: this.getSchoolProfile(),
      categories: this.getCategories(),
      rooms: this.getRooms(),
      items: this.getItems(),
      users: this.getUsers(),
      mutations: this.getMutations(),
      loans: this.getLoans(),
      maintenance: this.getMaintenance(),
      disposals: this.getDisposals(),
      lostItems: this.getLostItems(),
      books: this.getBooks(),
      damageReports: this.getDamageReports(),
      auditLogs: this.getAuditLogs(),
      stockOpnames: this.getStockOpnameSessions(),
      sheetSettings: this.getSheetSettings()
    };

    const blob = new Blob([JSON.stringify(fullData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `BACKUP_SIM_SARPRAS_MA_ASSALAAM_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  }

  // --- Restore from JSON file ---
  static async restoreFromBackup(file: File, actor: User): Promise<{ success: boolean; message: string }> {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);

      if (!parsed.appName || !parsed.items) {
        return { success: false, message: 'Format file cadangan tidak valid!' };
      }

      if (parsed.schoolProfile) localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(parsed.schoolProfile));
      if (parsed.categories) localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(parsed.categories));
      if (parsed.rooms) localStorage.setItem(STORAGE_KEYS.ROOMS, JSON.stringify(parsed.rooms));
      if (parsed.items) localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(parsed.items));
      if (parsed.users) localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(parsed.users));
      if (parsed.mutations) localStorage.setItem(STORAGE_KEYS.MUTATIONS, JSON.stringify(parsed.mutations));
      if (parsed.loans) localStorage.setItem(STORAGE_KEYS.LOANS, JSON.stringify(parsed.loans));
      if (parsed.maintenance) localStorage.setItem(STORAGE_KEYS.MAINTENANCE, JSON.stringify(parsed.maintenance));
      if (parsed.disposals) localStorage.setItem(STORAGE_KEYS.DISPOSALS, JSON.stringify(parsed.disposals));
      if (parsed.lostItems) localStorage.setItem(STORAGE_KEYS.LOST_ITEMS, JSON.stringify(parsed.lostItems));
      if (parsed.books) localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(parsed.books));
      if (parsed.damageReports) localStorage.setItem(STORAGE_KEYS.DAMAGE_REPORTS, JSON.stringify(parsed.damageReports));
      if (parsed.auditLogs) localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(parsed.auditLogs));
      if (parsed.stockOpnames) localStorage.setItem(STORAGE_KEYS.STOCK_OPNAME, JSON.stringify(parsed.stockOpnames));

      this.addAuditLog(actor, 'Melakukan restore database lengkap dari file cadangan', 'Backup & Restore');
      return { success: true, message: 'Database berhasil dipulihkan secara menyeluruh!' };
    } catch (err: any) {
      return { success: false, message: 'Gagal memproses file cadangan: ' + err.message };
    }
  }

  // --- Excel Workbook Multi-Sheet Export (Google Spreadsheet Architecture) ---
  static exportToExcelWorkbook(): void {
    const wb = XLSX.utils.book_new();

    const itemsData = this.getItems().map((item, idx) => ({
      No: idx + 1,
      'Kode Barang': item.kodeBarang,
      'Nama Barang': item.namaBarang,
      Kategori: item.kategori,
      Merk: item.merk,
      Spesifikasi: item.spesifikasi,
      'Nomor Seri': item.nomorSeri || '-',
      Tahun: item.tahunPerolehan,
      'Harga (Rp)': item.harga,
      'Sumber Dana': item.sumberDana,
      Ruangan: item.ruanganNama,
      'Penanggung Jawab': item.penanggungJawab,
      Kondisi: item.kondisi,
      Status: item.status,
      Keterangan: item.keterangan || '-'
    }));

    const roomsData = this.getRooms().map((r, idx) => ({
      No: idx + 1,
      'Kode Ruangan': r.kodeRuangan,
      'Nama Ruangan': r.namaRuangan,
      Jenis: r.jenisRuangan,
      Gedung: r.gedung,
      Lantai: r.lantai,
      'Luas (m2)': r.luasRuangan,
      'Penanggung Jawab': r.penanggungJawab,
      Kapasitas: r.kapasitas,
      Kondisi: r.kondisiRuangan,
      Keterangan: r.keterangan
    }));

    const loansData = this.getLoans().map((l, idx) => ({
      No: idx + 1,
      'No Peminjaman': l.nomorPeminjaman,
      Tanggal: l.tanggal,
      Peminjam: l.peminjam,
      Unit: l.unitKelas,
      'Kode Barang': l.kodeBarang,
      'Nama Barang': l.namaBarang,
      Jumlah: l.jumlah,
      'Tgl Pinjam': l.tanggalPinjam,
      'Rencana Kembali': l.rencanaKembali,
      Status: l.status
    }));

    const mutationsData = this.getMutations().map((m, idx) => ({
      No: idx + 1,
      'No Mutasi': m.nomorMutasi,
      Tanggal: m.tanggal,
      'Kode Barang': m.kodeBarang,
      'Nama Barang': m.namaBarang,
      'Ruang Asal': m.ruanganAsalNama,
      'Ruang Tujuan': m.ruanganTujuanNama,
      'PJ Lama': m.penanggungJawabLama,
      'PJ Baru': m.penanggungJawabBaru,
      Alasan: m.alasanMutasi,
      Petugas: m.petugas
    }));

    const booksData = this.getBooks().map((b, idx) => ({
      No: idx + 1,
      'Kode Buku': b.kodeBuku,
      ISBN: b.isbn,
      Judul: b.judul,
      Penulis: b.penulis,
      Penerbit: b.penerbit,
      Tahun: b.tahun,
      Kategori: b.kategori,
      Jumlah: b.jumlah,
      Rak: b.lokasiRak,
      Kondisi: b.kondisi
    }));

    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(itemsData), 'BARANG');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(roomsData), 'RUANGAN');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(loansData), 'PEMINJAMAN');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(mutationsData), 'MUTASI');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(booksData), 'BUKU');

    XLSX.writeFile(wb, `SIM_SARPRAS_MA_ASSALAAM_${new Date().toISOString().split('T')[0]}.xlsx`);
  }
}
