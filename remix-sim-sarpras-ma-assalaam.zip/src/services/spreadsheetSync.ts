import * as XLSX from 'xlsx';
import { StorageService } from './storage';
import { Item, Room, Mutation, Loan, KondisiBarang, StatusBarang } from '../types';

export interface SyncLogEntry {
  time: string;
  type: 'info' | 'success' | 'warning' | 'error';
  message: string;
}

export interface SyncResult {
  success: boolean;
  message: string;
  itemsImported?: number;
  roomsImported?: number;
  logs: SyncLogEntry[];
  timestamp: string;
}

export class SpreadsheetSyncService {
  /**
   * Extract clean Spreadsheet ID or published key from Google Sheets URL
   */
  static extractSpreadsheetId(url: string): string | null {
    if (!url) return null;
    const cleanUrl = url.trim();

    // Check published sheet key (/d/e/2PACX-...)
    const pubMatch = cleanUrl.match(/\/spreadsheets\/d\/e\/([a-zA-Z0-9-_]+)/);
    if (pubMatch) return pubMatch[1];

    // Standard sheet ID
    const match = cleanUrl.match(/\/spreadsheets\/(?:u\/\d+\/)?d\/([a-zA-Z0-9-_]{15,})/);
    if (match && match[1]) return match[1];

    // Drive URL
    const driveMatch = cleanUrl.match(/(?:open\?id=|file\/d\/)([a-zA-Z0-9-_]{15,})/);
    if (driveMatch) return driveMatch[1];

    if (/^[a-zA-Z0-9-_]{20,}$/.test(cleanUrl)) return cleanUrl;
    return null;
  }

  /**
   * Test connection to Google Spreadsheet & Google Apps Script
   */
  static async testConnection(
    sheetUrl: string,
    scriptUrl?: string
  ): Promise<{ success: boolean; message: string; details: any }> {
    try {
      const res = await fetch('/api/spreadsheet/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sheetUrl, scriptUrl })
      });
      const data = await res.json();
      return {
        success: data.success || false,
        message: data.message || (data.success ? 'Koneksi berhasil terhubung!' : 'Koneksi gagal.'),
        details: data
      };
    } catch (e: any) {
      return {
        success: false,
        message: 'Gagal menghubungi server aplikasi: ' + e.message,
        details: null
      };
    }
  }

  /**
   * Pull and sync data from Google Spreadsheet and/or Google Apps Script Web App
   */
  static async pullFromSpreadsheet(
    sheetUrl?: string,
    scriptUrl?: string,
    onProgress?: (msg: string) => void
  ): Promise<SyncResult> {
    const logs: SyncLogEntry[] = [];
    const addLog = (type: SyncLogEntry['type'], message: string) => {
      logs.push({ time: new Date().toLocaleTimeString('id-ID'), type, message });
      if (onProgress) onProgress(message);
    };

    const cleanSheetUrl = (sheetUrl || '').trim();
    const cleanScriptUrl = (scriptUrl || '').trim();
    const sheetId = this.extractSpreadsheetId(cleanSheetUrl);

    if (!sheetId && !cleanScriptUrl) {
      addLog('error', 'URL Google Spreadsheet belum dikonfigurasi. Harap masukkan tautan Google Spreadsheet Anda pada menu pengaturan.');
      return {
        success: false,
        message: 'URL Google Spreadsheet belum diisi.',
        logs,
        timestamp: new Date().toISOString()
      };
    }

    if (sheetId && sheetId.includes('1_SIM_SARPRAS_MA_ASSALAAM_BANDUNG') && !cleanScriptUrl) {
      const msg = 'URL Spreadsheet masih menggunakan contoh dummy. Silakan masukkan URL Google Spreadsheet Anda sendiri di formulir pengaturan.';
      addLog('warning', msg);
      return {
        success: false,
        message: msg,
        logs,
        timestamp: new Date().toISOString()
      };
    }

    let itemsImported = 0;
    let roomsImported = 0;
    let anySuccess = false;

    // 1. Try pulling via backend proxy (handles CSV or script fallback automatically)
    if (cleanSheetUrl || cleanScriptUrl) {
      addLog('info', 'Menghubungkan ke layanan Google Spreadsheet...');
      try {
        const proxyRes = await fetch('/api/spreadsheet/pull', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sheetUrl: cleanSheetUrl, scriptUrl: cleanScriptUrl, sheetName: 'BARANG' })
        });
        const json = await proxyRes.json();

        // Case A: Result returned from Google Apps Script Web App JSON
        if (json.success && json.fromScript && json.data) {
          addLog('success', 'Berhasil terhubung ke Google Apps Script Web App!');
          const rawItems = json.data.barang || json.data.items || [];
          if (Array.isArray(rawItems) && rawItems.length > 0) {
            const existingRooms = StorageService.getRooms();
            const mappedItems: Item[] = rawItems.map((row: any, idx: number) => {
              const kode = (row['Kode Barang'] || row['kodeBarang'] || row['Kode'] || `MAASS-GS-${idx + 1}`).toString().trim();
              const nama = (row['Nama Barang'] || row['namaBarang'] || row['Nama'] || 'Barang Inventaris').toString().trim();
              const kategori = (row['Kategori'] || row['kategori'] || 'Lainnya').toString().trim();
              const merk = (row['Merk'] || row['merk'] || '-').toString().trim();
              const spek = (row['Spesifikasi'] || row['spesifikasi'] || row['Spek'] || '-').toString().trim();
              const tahun = parseInt(row['Tahun'] || row['tahunPerolehan'] || '2026', 10) || 2026;
              const harga = parseInt(row['Harga'] || row['Harga (Rp)'] || row['harga'] || '0', 10) || 0;
              const ruanganNama = (row['Ruangan'] || row['ruanganNama'] || existingRooms[0]?.namaRuangan || 'Ruang Guru').toString().trim();
              const pj = (row['Penanggung Jawab'] || row['penanggungJawab'] || 'Petugas Sarpras').toString().trim();
              const kondisi = (row['Kondisi'] || row['kondisi'] || 'Baik').toString().trim() as KondisiBarang;
              const status = (row['Status'] || row['status'] || 'Tersedia').toString().trim() as StatusBarang;
              const matchedRoom = existingRooms.find((r) => r.namaRuangan.toLowerCase() === ruanganNama.toLowerCase());

              return {
                id: `itm-gs-${idx + 1}-${Date.now()}`,
                kodeBarang: kode,
                namaBarang: nama,
                kategori,
                kategoriKode: kategori.slice(0, 3).toUpperCase(),
                merk,
                spesifikasi: spek,
                tahunPerolehan: tahun,
                harga,
                sumberDana: 'BOS',
                ruanganId: matchedRoom ? matchedRoom.id : (existingRooms[0]?.id || 'room-1'),
                ruanganNama: matchedRoom ? matchedRoom.namaRuangan : ruanganNama,
                penanggungJawab: pj,
                kondisi: (['Baik', 'Rusak Ringan', 'Rusak Berat'].includes(kondisi) ? kondisi : 'Baik') as KondisiBarang,
                status: (['Tersedia', 'Dipinjam', 'Mutasi', 'Diperbaiki', 'Dihapus', 'Hilang'].includes(status) ? status : 'Tersedia') as StatusBarang,
                fotoBarang: 'https://images.unsplash.com/photo-1587831990711-23ca6441447b?w=600&auto=format&fit=crop&q=80',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
              };
            });

            if (mappedItems.length > 0) {
              StorageService.saveItems(mappedItems, undefined, `Sinkronisasi otomatis ${mappedItems.length} barang dari Google Apps Script`);
              itemsImported = mappedItems.length;
              anySuccess = true;
              addLog('success', `Berhasil mengimpor ${itemsImported} aset barang dari Google Sheets via Apps Script!`);
            }
          }

          if (Array.isArray(json.data.ruangan) && json.data.ruangan.length > 0) {
            roomsImported = json.data.ruangan.length;
            addLog('success', `Ditemukan ${roomsImported} ruangan dari Google Spreadsheet.`);
          }
        }
        // Case B: Result returned as CSV string
        else if (json.success && json.csvData) {
          try {
            const workbook = XLSX.read(json.csvData, { type: 'string' });
            const sheetName = workbook.SheetNames[0];
            const jsonRows: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

            if (jsonRows && jsonRows.length > 0) {
              addLog('success', `Berhasil membaca ${jsonRows.length} baris data barang dari CSV Google Spreadsheet.`);
              const existingRooms = StorageService.getRooms();

              const parsedItems: Item[] = jsonRows.map((row, idx) => {
                const kode = (row['Kode Barang'] || row['kodeBarang'] || row['Kode'] || `MAASS-IMP-${idx + 1}`).toString().trim();
                const nama = (row['Nama Barang'] || row['namaBarang'] || row['Nama'] || 'Barang Inventaris').toString().trim();
                const kategori = (row['Kategori'] || row['kategori'] || 'Lainnya').toString().trim();
                const merk = (row['Merk'] || row['merk'] || '-').toString().trim();
                const spek = (row['Spesifikasi'] || row['spesifikasi'] || row['Spek'] || '-').toString().trim();
                const tahun = parseInt(row['Tahun'] || row['tahunPerolehan'] || row['Tahun Perolehan'] || '2026', 10) || 2026;
                const harga = parseInt(row['Harga'] || row['Harga (Rp)'] || row['harga'] || '0', 10) || 0;
                const ruanganNama = (row['Ruangan'] || row['ruanganNama'] || row['Ruang'] || existingRooms[0]?.namaRuangan || 'Ruang Guru').toString().trim();
                const pj = (row['Penanggung Jawab'] || row['penanggungJawab'] || row['PJ'] || existingRooms[0]?.penanggungJawab || 'Petugas Sarpras').toString().trim();
                const kondisi = (row['Kondisi'] || row['kondisi'] || 'Baik').toString().trim() as KondisiBarang;
                const status = (row['Status'] || row['status'] || 'Tersedia').toString().trim() as StatusBarang;
                const matchedRoom = existingRooms.find((r) => r.namaRuangan.toLowerCase() === ruanganNama.toLowerCase());

                return {
                  id: `itm-sync-${idx + 1}-${Date.now()}`,
                  kodeBarang: kode,
                  namaBarang: nama,
                  kategori,
                  kategoriKode: kategori.slice(0, 3).toUpperCase(),
                  merk,
                  spesifikasi: spek,
                  tahunPerolehan: tahun,
                  harga,
                  sumberDana: 'BOS',
                  ruanganId: matchedRoom ? matchedRoom.id : (existingRooms[0]?.id || 'room-1'),
                  ruanganNama: matchedRoom ? matchedRoom.namaRuangan : ruanganNama,
                  penanggungJawab: pj,
                  kondisi: (['Baik', 'Rusak Ringan', 'Rusak Berat'].includes(kondisi) ? kondisi : 'Baik') as KondisiBarang,
                  status: (['Tersedia', 'Dipinjam', 'Mutasi', 'Diperbaiki', 'Dihapus', 'Hilang'].includes(status) ? status : 'Tersedia') as StatusBarang,
                  fotoBarang: 'https://images.unsplash.com/photo-1587831990711-23ca6441447b?w=600&auto=format&fit=crop&q=80',
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString()
                };
              });

              if (parsedItems.length > 0) {
                StorageService.saveItems(parsedItems, undefined, `Sinkronisasi otomatis ${parsedItems.length} barang dari Google Spreadsheet`);
                itemsImported = parsedItems.length;
                anySuccess = true;
                addLog('success', `Sinkronisasi database lokal berhasil diperbarui (${itemsImported} data barang)!`);
              }
            } else {
              addLog('warning', 'Sheet ditemukan tetapi tidak ada baris data atau tabel masih kosong.');
            }
          } catch (err: any) {
            addLog('error', `Gagal memproses data CSV: ${err.message}`);
          }
        } else if (json.error) {
          addLog(json.isRestricted ? 'error' : 'warning', json.error);
        }
      } catch (e: any) {
        addLog('warning', 'Gagal memanggil endpoint proxy: ' + e.message);
      }
    }

    // 2. Direct browser fetch fallback if proxy failed and sheetId is available
    if (!anySuccess && sheetId && !sheetId.includes('1_SIM_SARPRAS_MA_ASSALAAM_BANDUNG')) {
      addLog('info', 'Mencoba koneksi langsung dari peramban (Direct Browser Fallback)...');
      try {
        const candidateUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`;
        const res = await fetch(candidateUrl);
        if (res.ok) {
          const text = await res.text();
          if (!text.includes('<!DOCTYPE html>') && !text.includes('accounts.google.com') && text.trim().length > 0) {
            const workbook = XLSX.read(text, { type: 'string' });
            const sheetName = workbook.SheetNames[0];
            const rows: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
            if (rows && rows.length > 0) {
              addLog('success', `Berhasil membaca ${rows.length} baris langsung dari Google Spreadsheet!`);
              anySuccess = true;
            }
          }
        }
      } catch (err) {
        // Direct fetch CORS
      }
    }

    // Update last sync time
    const settings = StorageService.getSheetSettings();
    const updatedSettings = {
      ...settings,
      lastSyncTime: new Date().toISOString(),
      connected: anySuccess
    };
    StorageService.saveSheetSettings(updatedSettings);

    return {
      success: anySuccess,
      message: anySuccess
        ? `Sinkronisasi berhasil! ${itemsImported} data barang sinkron dengan Google Spreadsheet.`
        : (logs.find(l => l.type === 'error')?.message || 'Belum dapat terhubung ke Google Spreadsheet. Periksa hak akses "Bagikan" pada spreadsheet Anda atau pasang Google Apps Script Web App.'),
      itemsImported,
      roomsImported,
      logs,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Push current data to Google Apps Script Web App
   */
  static async pushToGoogleAppsScript(
    scriptUrl: string,
    onProgress?: (msg: string) => void
  ): Promise<SyncResult> {
    const logs: SyncLogEntry[] = [];
    const addLog = (type: SyncLogEntry['type'], message: string) => {
      logs.push({ time: new Date().toLocaleTimeString('id-ID'), type, message });
      if (onProgress) onProgress(message);
    };

    if (!scriptUrl || !scriptUrl.startsWith('http')) {
      addLog('error', 'URL Web App Google Apps Script belum diatur.');
      return {
        success: false,
        message: 'URL Google Apps Script tidak valid.',
        logs,
        timestamp: new Date().toISOString()
      };
    }

    addLog('info', 'Mempersiapkan data lokal untuk dikirim ke Google Spreadsheet...');
    const payload = {
      action: 'sync_all',
      timestamp: new Date().toISOString(),
      profile: StorageService.getSchoolProfile(),
      items: StorageService.getItems(),
      rooms: StorageService.getRooms(),
      mutations: StorageService.getMutations(),
      loans: StorageService.getLoans(),
      maintenance: StorageService.getMaintenance(),
      disposals: StorageService.getDisposals(),
      lostItems: StorageService.getLostItems(),
      books: StorageService.getBooks()
    };

    addLog('info', `Mengirimkan ${payload.items.length} barang, ${payload.rooms.length} ruangan, & riwayat transaksi ke Google Apps Script...`);

    let pushSuccess = false;

    // 1. Try server proxy
    try {
      const proxyRes = await fetch('/api/spreadsheet/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scriptUrl, payload })
      });
      if (proxyRes.ok) {
        const resData = await proxyRes.json();
        if (resData.success) {
          pushSuccess = true;
          addLog('success', 'Google Apps Script berhasil menerima dan menulis data ke Google Sheets!');
        }
      }
    } catch (e) {}

    // 2. Direct fetch with no-cors fallback if proxy did not succeed
    if (!pushSuccess) {
      try {
        await fetch(scriptUrl, {
          method: 'POST',
          mode: 'no-cors',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        pushSuccess = true;
        addLog('success', 'Permintaan sinkronisasi terkirim ke Google Apps Script Web App!');
      } catch (err: any) {
        addLog('error', `Gagal mengirim ke Google Apps Script: ${err.message}`);
      }
    }

    return {
      success: pushSuccess,
      message: pushSuccess
        ? 'Data aplikasi berhasil terkirim ke Google Spreadsheet!'
        : 'Gagal mengirim data ke Google Apps Script.',
      logs,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Run full two-way synchronization
   */
  static async runFullSync(
    onProgress?: (msg: string) => void
  ): Promise<SyncResult> {
    const settings = StorageService.getSheetSettings();
    const combinedLogs: SyncLogEntry[] = [];

    const handleProgress = (msg: string) => {
      if (onProgress) onProgress(msg);
    };

    // 1. Pull data if sheetUrl or scriptUrl is present
    let pullResult: SyncResult | null = null;
    if (settings.sheetUrl || settings.scriptUrl) {
      pullResult = await this.pullFromSpreadsheet(settings.sheetUrl, settings.scriptUrl, handleProgress);
      combinedLogs.push(...pullResult.logs);
    } else {
      combinedLogs.push({
        time: new Date().toLocaleTimeString('id-ID'),
        type: 'warning',
        message: 'URL Google Spreadsheet belum diisi. Masukkan tautan spreadsheet pada menu Pengaturan.'
      });
    }

    // 2. Push data if scriptUrl is present
    let pushResult: SyncResult | null = null;
    if (settings.scriptUrl && settings.scriptUrl.startsWith('http')) {
      pushResult = await this.pushToGoogleAppsScript(settings.scriptUrl, handleProgress);
      combinedLogs.push(...pushResult.logs);
    }

    const isSuccess = (pullResult && pullResult.success) || (pushResult && pushResult.success) || false;

    return {
      success: isSuccess,
      message: isSuccess
        ? 'Sinkronisasi otomatis dengan Google Spreadsheet berhasil diselesaikan!'
        : (pullResult?.message || 'Sinkronisasi selesai dengan beberapa catatan.'),
      itemsImported: pullResult?.itemsImported || 0,
      roomsImported: pullResult?.roomsImported || 0,
      logs: combinedLogs,
      timestamp: new Date().toISOString()
    };
  }
}
