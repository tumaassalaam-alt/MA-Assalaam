import QRCode from 'qrcode';

/**
 * Get full web URL to view a room directly without login (for door QR codes)
 */
export function getRoomDoorScanUrl(kodeRuangan: string): string {
  if (typeof window !== 'undefined') {
    return `${window.location.origin}${window.location.pathname}?ruangan=${encodeURIComponent(kodeRuangan)}`;
  }
  return `?ruangan=${encodeURIComponent(kodeRuangan)}`;
}

/**
 * Get full web URL to view an item directly (for inventory QR codes)
 */
export function getItemScanUrl(kodeBarang: string): string {
  if (typeof window !== 'undefined') {
    return `${window.location.origin}${window.location.pathname}?barang=${encodeURIComponent(kodeBarang)}`;
  }
  return `?barang=${encodeURIComponent(kodeBarang)}`;
}

/**
 * Generate high-res Data URL QR Code
 */
export async function generateQrDataUrl(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      width: 256,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#ffffff'
      },
      errorCorrectionLevel: 'M'
    });
  } catch (err) {
    console.error('Error generating QR code:', err);
    return '';
  }
}

/**
 * Generate Code 128-B visual SVG Barcode representation
 */
export function generateBarcodeSvg(code: string): string {
  // Simple deterministic pattern generator for clean visual 1D barcode
  const hash = code.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const bars: { width: number; isBlack: boolean }[] = [];
  
  // Start guard
  bars.push({ width: 2, isBlack: true });
  bars.push({ width: 1, isBlack: false });
  bars.push({ width: 2, isBlack: true });

  for (let i = 0; i < code.length; i++) {
    const charCode = code.charCodeAt(i);
    const pattern = (charCode * 7 + i * 13 + hash) % 16;
    for (let bit = 0; bit < 4; bit++) {
      const isBlack = ((pattern >> bit) & 1) === 1;
      const w = ((charCode + bit) % 3) + 1;
      bars.push({ width: w, isBlack });
    }
  }

  // Stop guard
  bars.push({ width: 2, isBlack: true });
  bars.push({ width: 1, isBlack: false });
  bars.push({ width: 3, isBlack: true });

  let totalWidth = 0;
  bars.forEach(b => totalWidth += b.width);

  const scale = 2;
  const svgWidth = totalWidth * scale + 20;
  const svgHeight = 65;

  let currentX = 10;
  let rects = '';
  for (const bar of bars) {
    const barW = bar.width * scale;
    if (bar.isBlack) {
      rects += `<rect x="${currentX}" y="2" width="${barW}" height="42" fill="#111827" />`;
    }
    currentX += barW;
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${svgWidth} ${svgHeight}" width="${svgWidth}" height="${svgHeight}">
    <rect width="${svgWidth}" height="${svgHeight}" fill="#ffffff" />
    ${rects}
    <text x="${svgWidth / 2}" y="58" font-family="Courier New, monospace" font-size="11" font-weight="bold" fill="#111827" text-anchor="middle" letter-spacing="1.5">${code}</text>
  </svg>`;
}

/**
 * Format currency to Indonesian Rupiah (Rp)
 */
export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

/**
 * Calculate next sequential code for inventory: MAASS-[KAT]-[TAHUN]-[0001...]
 */
export function generateNextItemCode(kategoriKode: string, tahun: number, existingCodes: string[]): string {
  const cleanKat = (kategoriKode || 'BRG').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const prefix = `MAASS-${cleanKat}-${tahun}-`;
  
  // Find highest number with same prefix
  let maxSeq = 0;
  for (const code of existingCodes) {
    if (code && code.startsWith(prefix)) {
      const numPart = parseInt(code.substring(prefix.length), 10);
      if (!isNaN(numPart) && numPart > maxSeq) {
        maxSeq = numPart;
      }
    }
  }

  const nextNum = (maxSeq + 1).toString().padStart(4, '0');
  return `${prefix}${nextNum}`;
}
