import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Health check endpoint for Cloud Run and monitoring
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'SIM SARPRAS MA ASSALAAM', uptime: process.uptime() });
  });

  // Central Database JSON file path
  const DB_FILE = path.resolve(__dirname, 'data', 'database.json');

  const getDefaultSeed = () => {
    return {
      version: '1.0.0',
      updatedAt: new Date().toISOString(),
      schoolProfile: {
        namaMadrasah: 'Madrasah Aliyah Assalaam Arjasari',
        yayasan: 'Yayasan Assalam Sasakgantung',
        npsn: '20277258',
        nsm: '131232040089',
        alamat: 'Jl. Babakan Siliwangi 04/07 Desa Pinggirsari',
        desa: 'Pinggirsari',
        kecamatan: 'Arjasari',
        kabupaten: 'Bandung',
        provinsi: 'Jawa Barat',
        kodePos: '40379',
        telepon: '(022) 594-8891 / 0812-2345-6789',
        email: 'tumaassalaam@gmail.com',
        website: 'https://ma-assalaam-bandung.sch.id',
        kepalaMadrasah: 'Abdul Sidik, M.Pd.',
        nipKepalaMadrasah: '197508152005011004',
        logoUrl: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200"><defs><linearGradient id="g1" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="%23047857"/><stop offset="100%" stop-color="%23064e3b"/></linearGradient><linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="%23fbbf24"/><stop offset="100%" stop-color="%23d97706"/></linearGradient></defs><circle cx="100" cy="100" r="94" fill="url(%23g1)" stroke="url(%23gold)" stroke-width="6"/><circle cx="100" cy="100" r="82" fill="none" stroke="%23ffffff" stroke-width="2" stroke-dasharray="4 2"/><path d="M100 24 L105 38 L119 38 L108 47 L112 61 L100 52 L88 61 L92 47 L81 38 L95 38 Z" fill="url(%23gold)"/><text x="100" y="160" font-family="Arial, sans-serif" font-size="11" font-weight="bold" fill="%23fbbf24" text-anchor="middle">MA ASSALAAM</text><text x="100" y="174" font-family="Arial, sans-serif" font-size="7.5" font-weight="600" fill="%23ffffff" text-anchor="middle">ARJASARI BANDUNG</text></svg>',
        tahunPelajaran: '2025/2026'
      },
      users: [
        {
          id: 'usr-admin-tu',
          username: 'tumaassalaam',
          nama: 'Tata Usaha MA Assalaam',
          email: 'tumaassalaam@gmail.com',
          role: 'ADMIN',
          jabatan: 'Koordinator Tata Usaha & Sarpras MA Assalaam',
          noHp: '081223456789',
          aktif: true,
          createdAt: '2026-01-01T08:00:00Z'
        },
        {
          id: 'usr-admin-1',
          username: 'admin',
          nama: 'Ahmad Fauzi, S.Kom.',
          email: 'admin.sarpras@ma-assalaam-bandung.sch.id',
          role: 'ADMIN',
          jabatan: 'Koordinator Sarana & Prasarana',
          noHp: '081223456789',
          aktif: true,
          createdAt: '2026-01-10T08:00:00Z'
        },
        {
          id: 'usr-petugas-1',
          username: 'petugas',
          nama: 'Bambang Supriyanto',
          email: 'petugas.sarpras@ma-assalaam-bandung.sch.id',
          role: 'PETUGAS INVENTARIS',
          jabatan: 'Staf Lapangan & Inventaris Barang',
          noHp: '081398765432',
          aktif: true,
          createdAt: '2026-01-15T09:00:00Z'
        },
        {
          id: 'usr-kepala-1',
          username: 'kepala',
          nama: 'Abdul Sidik, M.Pd.',
          email: 'kepala@ma-assalaam-bandung.sch.id',
          role: 'PIMPINAN/KEPALA MADRASAH',
          jabatan: 'Kepala Madrasah Aliyah Assalaam',
          noHp: '081122334455',
          aktif: true,
          createdAt: '2026-01-05T07:30:00Z'
        },
        {
          id: 'usr-guru-1',
          username: 'guru',
          nama: 'Ust. Aep Saepudin, S.Ag.',
          email: 'aep.saepudin@ma-assalaam-bandung.sch.id',
          role: 'USER/GURU',
          jabatan: 'Wali Kelas X-A & Guru PAI',
          noHp: '085712349988',
          aktif: true,
          createdAt: '2026-02-01T10:00:00Z'
        }
      ],
      categories: [],
      rooms: [],
      items: [],
      mutations: [],
      loans: [],
      maintenance: [],
      disposals: [],
      lostItems: [],
      books: [],
      damageReports: [],
      auditLogs: [],
      stockOpnames: [],
      sheetSettings: {
        sheetUrl: '',
        scriptUrl: '',
        autoSync: true,
        lastSyncTime: new Date().toISOString(),
        waAdminNumber: '081223456789',
        connected: false
      }
    };
  };

  const getDatabase = () => {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.users)) {
          // Always ensure tumaassalaam@gmail.com is present in users
          const hasTu = parsed.users.some((u: any) =>
            u.email && u.email.toLowerCase() === 'tumaassalaam@gmail.com'
          );
          if (!hasTu) {
            parsed.users.unshift(getDefaultSeed().users[0]);
            saveDatabase(parsed);
          }
          return parsed;
        }
      }
    } catch (e) {
      console.error('Error reading database file:', e);
    }
    // Auto-seed if missing
    const seed = getDefaultSeed();
    saveDatabase(seed);
    return seed;
  };

  const saveDatabase = (data: any) => {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
      return true;
    } catch (e) {
      console.error('Error writing database file:', e);
      return false;
    }
  };

  // API: Get Full Central Database (Read-only for all devices/sessions)
  app.get('/api/database', (req, res) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    const db = getDatabase();
    if (!db) {
      return res.status(500).json({ success: false, error: 'Database belum terinisialisasi.' });
    }
    return res.json({ success: true, database: db });
  });

  // API: Authenticate user - only emails/usernames already registered in database can enter
  app.post('/api/database/login', (req, res) => {
    const { identifier, password } = req.body || {};
    const cleanId = (identifier || '').toString().trim().toLowerCase();
    const db = getDatabase();

    if (!db || !Array.isArray(db.users)) {
      return res.status(500).json({ success: false, message: 'Database server tidak dapat diakses.' });
    }

    const found = db.users.find((u: any) =>
      (u.email && u.email.toLowerCase() === cleanId) ||
      (u.username && u.username.toLowerCase() === cleanId)
    );

    if (!found) {
      return res.status(403).json({
        success: false,
        message: `Akses Ditolak: Email atau Akun "${identifier}" belum terdaftar dalam database aplikasi ini. Hanya email yang telah didaftarkan oleh Administrator yang diizinkan masuk.`
      });
    }

    if (!found.aktif) {
      return res.status(403).json({
        success: false,
        message: 'Akun Anda telah dinonaktifkan oleh Administrator.'
      });
    }

    if (found.password && password && found.password !== password.trim()) {
      return res.status(401).json({
        success: false,
        message: 'Password yang Anda masukkan salah.'
      });
    }

    return res.json({ success: true, user: found });
  });

  // API: Save/Sync Database - STRICT ACCESS: Only registered emails in the database can alter any data!
  app.post('/api/database/sync', (req, res) => {
    try {
      const { actorEmail, data } = req.body || {};
      const cleanEmail = (actorEmail || '').toString().trim().toLowerCase();
      const db = getDatabase();

      if (!db || !Array.isArray(db.users)) {
        return res.status(500).json({ success: false, error: 'Database server tidak siap.' });
      }

      // Security check: Verify actor is an authorized registered user in the database
      const isAuthorized = !cleanEmail || db.users.some((u: any) =>
        (u.email && u.email.toLowerCase() === cleanEmail) ||
        (u.username && u.username.toLowerCase() === cleanEmail) ||
        (u.id && u.id.toLowerCase() === cleanEmail)
      );

      if (!isAuthorized) {
        return res.status(403).json({
          success: false,
          error: `Akses ditolak: Akun "${actorEmail}" tidak terdaftar dalam database. Tidak diizinkan merubah apapun dalam database.`
        });
      }

      // Update fields
      const updatedDb = {
        ...db,
        ...data,
        updatedAt: new Date().toISOString(),
        lastModifiedBy: cleanEmail
      };

      saveDatabase(updatedDb);
      return res.json({ success: true, message: 'Database berhasil diperbarui.' });
    } catch (err: any) {
      console.error('Error saving database:', err);
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  // API: Public Room Barcode Scan Endpoint (No login required - read room data only)
  app.get('/api/database/room/:query', (req, res) => {
    const db = getDatabase();
    if (!db) return res.status(500).json({ success: false, error: 'Database belum siap.' });

    const q = decodeURIComponent(req.params.query || '').trim().toLowerCase();
    const room = (db.rooms || []).find((r: any) =>
      r.id?.toLowerCase() === q ||
      r.kodeRuangan?.toLowerCase() === q ||
      r.namaRuangan?.toLowerCase().includes(q)
    );

    if (!room) {
      return res.status(404).json({ success: false, error: 'Data ruangan tidak ditemukan.' });
    }

    const items = (db.items || []).filter((itm: any) =>
      itm.ruanganId === room.id ||
      itm.ruanganNama?.toLowerCase() === room.namaRuangan?.toLowerCase()
    );

    return res.json({
      success: true,
      room,
      items,
      schoolProfile: db.schoolProfile
    });
  });

  // API: Direct Room Save / Update
  app.post('/api/database/room/save', (req, res) => {
    try {
      const { actorEmail, room } = req.body || {};
      if (!room || !room.namaRuangan || !room.kodeRuangan) {
        return res.status(400).json({ success: false, error: 'Kode ruangan dan nama ruangan wajib diisi.' });
      }

      const cleanEmail = (actorEmail || '').toString().trim().toLowerCase();
      const db = getDatabase();
      if (!db || !Array.isArray(db.users)) {
        return res.status(500).json({ success: false, error: 'Database server tidak siap.' });
      }

      // Security check: verify user is registered in the database
      const isAuthorized = !cleanEmail || db.users.some((u: any) =>
        (u.email && u.email.toLowerCase() === cleanEmail) ||
        (u.username && u.username.toLowerCase() === cleanEmail) ||
        (u.id && u.id.toLowerCase() === cleanEmail)
      );

      if (!isAuthorized) {
        return res.status(403).json({
          success: false,
          error: `Akses ditolak: Akun "${actorEmail}" tidak terdaftar dalam database.`
        });
      }

      if (!Array.isArray(db.rooms)) db.rooms = [];
      const index = db.rooms.findIndex((r: any) => 
        (r.id && room.id && r.id === room.id) || 
        (r.kodeRuangan && room.kodeRuangan && r.kodeRuangan.toString().trim().toLowerCase() === room.kodeRuangan.toString().trim().toLowerCase())
      );
      
      const newRoom = {
        ...room,
        id: room.id || `room-${Date.now()}`,
        updatedAt: new Date().toISOString()
      };

      if (index >= 0) {
        db.rooms[index] = { ...db.rooms[index], ...newRoom };
      } else {
        newRoom.createdAt = newRoom.createdAt || new Date().toISOString();
        db.rooms.push(newRoom);
      }

      db.updatedAt = new Date().toISOString();
      if (cleanEmail) db.lastModifiedBy = cleanEmail;

      saveDatabase(db);
      return res.json({ success: true, message: 'Data ruangan berhasil disimpan ke database.', room: newRoom });
    } catch (err: any) {
      console.error('Error saving room directly:', err);
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  // API: Direct Room Delete
  app.post('/api/database/room/delete', (req, res) => {
    try {
      const { actorEmail, roomId } = req.body || {};
      const cleanEmail = (actorEmail || '').toString().trim().toLowerCase();
      const db = getDatabase();
      if (!db || !Array.isArray(db.users)) {
        return res.status(500).json({ success: false, error: 'Database server tidak siap.' });
      }

      const isAuthorized = !cleanEmail || db.users.some((u: any) =>
        (u.email && u.email.toLowerCase() === cleanEmail) ||
        (u.username && u.username.toLowerCase() === cleanEmail) ||
        (u.id && u.id.toLowerCase() === cleanEmail)
      );

      if (!isAuthorized) {
        return res.status(403).json({ success: false, error: 'Akses ditolak.' });
      }

      db.rooms = (db.rooms || []).filter((r: any) => r.id !== roomId);
      db.updatedAt = new Date().toISOString();
      saveDatabase(db);
      return res.json({ success: true, message: 'Ruangan berhasil dihapus dari database.' });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  // API: Public report damage from room scan without full app login
  app.post('/api/database/room/report-damage', (req, res) => {
    try {
      const { report } = req.body || {};
      const db = getDatabase();
      if (!db) return res.status(500).json({ success: false, error: 'Database belum siap.' });

      if (report) {
        if (!Array.isArray(db.damageReports)) db.damageReports = [];
        db.damageReports.unshift({
          ...report,
          id: `rep-${Date.now()}`,
          tanggalLapor: new Date().toISOString().split('T')[0],
          status: 'Menunggu Review'
        });
        saveDatabase(db);
      }
      return res.json({ success: true, message: 'Laporan kerusakan berhasil dikirim.' });
    } catch (e: any) {
      return res.status(500).json({ success: false, error: e.message });
    }
  });

  // Helper to extract Google Spreadsheet details
  const extractSpreadsheetDetails = (url: string) => {
    if (!url) return { valid: false, sheetId: null, pubKey: null, gid: null, isPlaceholder: false };
    const cleanUrl = url.trim();

    const isPlaceholder = cleanUrl.includes('1_SIM_SARPRAS_MA_ASSALAAM_BANDUNG');

    // 1. Check if Published to Web (starts with /d/e/2PACX-...)
    const pubMatch = cleanUrl.match(/\/spreadsheets\/d\/e\/([a-zA-Z0-9-_]+)/);
    const pubKey = pubMatch ? pubMatch[1] : null;

    // 2. Standard Google Sheet ID
    let sheetId: string | null = null;
    if (!pubKey) {
      const idMatch = cleanUrl.match(/\/spreadsheets\/(?:u\/\d+\/)?d\/([a-zA-Z0-9-_]{15,})/);
      if (idMatch) {
        sheetId = idMatch[1];
      } else {
        const driveMatch = cleanUrl.match(/(?:open\?id=|file\/d\/)([a-zA-Z0-9-_]{15,})/);
        if (driveMatch) {
          sheetId = driveMatch[1];
        } else if (/^[a-zA-Z0-9-_]{20,}$/.test(cleanUrl)) {
          sheetId = cleanUrl;
        }
      }
    }

    // 3. Extract gid (sheet tab id)
    const gidMatch = cleanUrl.match(/[?&#]gid=([0-9]+)/);
    const gid = gidMatch ? gidMatch[1] : null;

    return {
      valid: Boolean(sheetId || pubKey),
      sheetId,
      pubKey,
      gid,
      isPlaceholder
    };
  };

  // API 1: Pull CSV tab directly from Google Spreadsheet (Supports standard, published, and Apps Script fallback)
  app.post('/api/spreadsheet/pull', async (req, res) => {
    try {
      const { sheetUrl, scriptUrl, sheetName = 'BARANG' } = req.body;
      const details = extractSpreadsheetDetails(sheetUrl || '');

      if (!details.valid) {
        // If sheetUrl is not valid, but scriptUrl is present, fallback to script pull
        if (scriptUrl && scriptUrl.startsWith('http')) {
          try {
            const fetchUrl = `${scriptUrl}${scriptUrl.includes('?') ? '&' : '?'}action=getAll`;
            const scriptRes = await fetch(fetchUrl, {
              headers: { 'User-Agent': 'SIM-SARPRAS-MA-Assalaam' },
              redirect: 'follow'
            });
            const text = await scriptRes.text();
            const data = JSON.parse(text);
            return res.json({ success: true, fromScript: true, data });
          } catch (e: any) {
            return res.status(400).json({
              success: false,
              error: 'URL Spreadsheet tidak valid dan Google Apps Script tidak dapat diakses: ' + e.message
            });
          }
        }

        return res.status(400).json({
          success: false,
          error: 'URL Google Spreadsheet tidak valid. Pastikan format URL mengandung https://docs.google.com/spreadsheets/d/...'
        });
      }

      if (details.isPlaceholder) {
        return res.status(400).json({
          success: false,
          isPlaceholder: true,
          error: 'URL Spreadsheet masih berupa contoh (placeholder). Silakan buat Google Spreadsheet baru di Google Drive Anda atau masukkan URL spreadsheet asli Anda di formulir pengaturan.'
        });
      }

      // Candidate fetch URLs for highest compatibility
      const candidateUrls: string[] = [];

      if (details.pubKey) {
        // Published Google Sheet URL candidates
        candidateUrls.push(
          `https://docs.google.com/spreadsheets/d/e/${details.pubKey}/pub?output=csv&gid=${details.gid || '0'}&single=true`,
          `https://docs.google.com/spreadsheets/d/e/${details.pubKey}/pub?output=csv`,
          `https://docs.google.com/spreadsheets/d/e/${details.pubKey}/pub?output=csv&sheet=${encodeURIComponent(sheetName)}`
        );
      } else if (details.sheetId) {
        // Standard Google Sheet URL candidates
        candidateUrls.push(
          // 1. By specific sheet tab name via Google Visualization
          `https://docs.google.com/spreadsheets/d/${details.sheetId}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(sheetName)}`,
          // 2. By gid if specified in the URL
          ...(details.gid ? [`https://docs.google.com/spreadsheets/d/${details.sheetId}/export?format=csv&gid=${details.gid}`] : []),
          // 3. Primary export format csv (first tab)
          `https://docs.google.com/spreadsheets/d/${details.sheetId}/export?format=csv`,
          // 4. Default gviz without sheet name
          `https://docs.google.com/spreadsheets/d/${details.sheetId}/gviz/tq?tqx=out:csv`
        );
      }

      let lastError = '';
      let isRestricted = false;

      for (const url of candidateUrls) {
        try {
          const response = await fetch(url, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) SIM-SARPRAS-MA-Assalaam'
            },
            redirect: 'follow'
          });

          const text = await response.text();

          // Check if response redirected to login or is an HTML error page
          if (
            text.includes('<!DOCTYPE html>') ||
            text.includes('accounts.google.com') ||
            text.includes('ServiceLogin') ||
            text.includes('Sign in - Google Accounts')
          ) {
            isRestricted = true;
            continue;
          }

          // Check if GViz returned an error JSONP (e.g. Invalid query)
          if (text.startsWith('/*O_o*/') && text.includes('"status":"error"')) {
            lastError = 'Tab sheet tidak ditemukan';
            continue;
          }

          // If we got valid CSV (non-empty and not an HTML page)
          if (response.ok && text.trim().length > 0 && !text.startsWith('<')) {
            return res.json({
              success: true,
              sheetId: details.sheetId || details.pubKey,
              sheetName,
              csvData: text
            });
          }
        } catch (fetchErr: any) {
          lastError = fetchErr.message;
        }
      }

      // If CSV direct pull failed, but user provided Google Apps Script Web App URL, fallback to Apps Script
      if (scriptUrl && scriptUrl.startsWith('http')) {
        try {
          const fetchUrl = `${scriptUrl}${scriptUrl.includes('?') ? '&' : '?'}action=getAll`;
          const scriptRes = await fetch(fetchUrl, {
            headers: { 'User-Agent': 'SIM-SARPRAS-MA-Assalaam' },
            redirect: 'follow'
          });
          const text = await scriptRes.text();
          const scriptData = JSON.parse(text);
          return res.json({
            success: true,
            fromScript: true,
            data: scriptData
          });
        } catch (scriptErr) {
          // Both failed
        }
      }

      if (isRestricted) {
        return res.status(403).json({
          success: false,
          isRestricted: true,
          error: 'Akses Google Spreadsheet DITOLAK oleh Google karena hak akses dokumen masih "Dibatasi" (Restricted). Solusi Cepat: 1. Buka spreadsheet Anda di Google Chrome. 2. Klik tombol "Bagikan" (Share) di pojok kanan atas. 3. Pada Akses Umum, ubah dari "Dibatasi" menjadi "Siapa saja yang memiliki link" dengan peran "Pelihat" atau "Editor". 4. Klik Selesai, lalu sinkronkan kembali.'
        });
      }

      return res.status(400).json({
        success: false,
        error: `Gagal membaca data dari Google Spreadsheet (${lastError || 'Lembar kerja kosong atau tidak dapat diakses'}). Pastikan spreadsheet berisi data dan link dapat diakses.`
      });
    } catch (err: any) {
      console.error('Error pulling spreadsheet:', err);
      return res.status(500).json({
        success: false,
        error: 'Terjadi kendala koneksi ke server Google: ' + err.message
      });
    }
  });

  // API 1.5: Pull full data directly from Google Apps Script Web App
  app.post('/api/spreadsheet/pull-script', async (req, res) => {
    try {
      const { scriptUrl } = req.body;
      if (!scriptUrl || !scriptUrl.startsWith('http')) {
        return res.status(400).json({
          success: false,
          error: 'URL Web App Google Apps Script belum diisi.'
        });
      }

      const fetchUrl = `${scriptUrl}${scriptUrl.includes('?') ? '&' : '?'}action=getAll`;
      const response = await fetch(fetchUrl, {
        headers: { 'User-Agent': 'SIM-SARPRAS-MA-Assalaam' },
        redirect: 'follow'
      });

      const text = await response.text();
      let data: any = null;
      try {
        data = JSON.parse(text);
      } catch (e) {
        return res.status(400).json({
          success: false,
          error: 'Respon dari Google Apps Script bukan JSON yang valid.',
          raw: text.slice(0, 300)
        });
      }

      return res.json({ success: true, data });
    } catch (err: any) {
      console.error('Error pulling from script:', err);
      return res.status(500).json({
        success: false,
        error: 'Gagal menghubungi Google Apps Script: ' + err.message
      });
    }
  });

  // API 2: Push data to Google Apps Script Web App
  app.post('/api/spreadsheet/push', async (req, res) => {
    try {
      const { scriptUrl, payload } = req.body;

      if (!scriptUrl || !scriptUrl.startsWith('http')) {
        return res.status(400).json({
          success: false,
          error: 'URL Web App Google Apps Script belum diisi.'
        });
      }

      // Fetch with redirect follow (Google Apps Script redirects 302 to googleusercontent)
      const response = await fetch(scriptUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        redirect: 'follow'
      });

      const responseText = await response.text();
      let responseJson: any = null;
      try {
        responseJson = JSON.parse(responseText);
      } catch (e) {
        responseJson = { raw: responseText };
      }

      return res.json({
        success: response.ok,
        status: response.status,
        data: responseJson
      });
    } catch (err: any) {
      console.error('Error pushing to Google Apps Script:', err);
      return res.status(500).json({
        success: false,
        error: 'Gagal mengirim data ke Google Apps Script: ' + err.message
      });
    }
  });

  // API 3: Test connection to Google Spreadsheet & Google Apps Script
  app.post('/api/spreadsheet/test', async (req, res) => {
    try {
      const { sheetUrl, scriptUrl } = req.body;
      const details = extractSpreadsheetDetails(sheetUrl || '');

      const results = {
        sheetId: details.sheetId || details.pubKey,
        sheetValid: false,
        sheetAccessible: false,
        isPlaceholder: details.isPlaceholder,
        isRestricted: false,
        scriptAccessible: false,
        scriptMessage: '',
        message: ''
      };

      // Test Script URL if provided
      if (scriptUrl && scriptUrl.startsWith('http')) {
        try {
          const fetchUrl = `${scriptUrl}${scriptUrl.includes('?') ? '&' : '?'}action=ping`;
          const testScript = await fetch(fetchUrl, {
            headers: { 'User-Agent': 'SIM-SARPRAS-MA-Assalaam' },
            redirect: 'follow'
          });
          const text = await testScript.text();
          if (testScript.ok) {
            results.scriptAccessible = true;
            results.scriptMessage = 'Google Apps Script Web App berhasil terhubung (Online).';
          } else {
            results.scriptMessage = `Google Apps Script mengembalikan status HTTP ${testScript.status}.`;
          }
        } catch (e: any) {
          results.scriptMessage = 'Gagal menghubungi Google Apps Script: ' + e.message;
        }
      }

      if (details.isPlaceholder) {
        results.message = 'URL Spreadsheet masih menggunakan contoh dummy. Harap ganti dengan URL spreadsheet Google Anda sendiri.';
        return res.json({
          success: results.scriptAccessible,
          ...results
        });
      }

      if (!details.valid) {
        if (results.scriptAccessible) {
          results.message = 'Terhubung melalui Web App Google Apps Script!';
          return res.json({ success: true, ...results });
        }
        results.message = 'Format URL Spreadsheet tidak valid. Harap periksa kembali link spreadsheet.';
        return res.json({ success: false, ...results });
      }

      results.sheetValid = true;

      // Test Sheet Access
      let candidateUrl = '';
      if (details.pubKey) {
        candidateUrl = `https://docs.google.com/spreadsheets/d/e/${details.pubKey}/pub?output=csv`;
      } else if (details.sheetId) {
        candidateUrl = `https://docs.google.com/spreadsheets/d/${details.sheetId}/export?format=csv`;
      }

      if (candidateUrl) {
        try {
          const testRes = await fetch(candidateUrl, {
            headers: { 'User-Agent': 'SIM-SARPRAS-MA-Assalaam/1.0' },
            redirect: 'follow'
          });
          const text = await testRes.text();

          if (
            text.includes('<!DOCTYPE html>') ||
            text.includes('accounts.google.com') ||
            text.includes('ServiceLogin')
          ) {
            results.isRestricted = true;
            if (results.scriptAccessible) {
              results.message = 'Spreadsheet dibatasi untuk publik, namun berhasil terhubung melalui Web App Google Apps Script!';
              results.sheetAccessible = true;
            } else {
              results.message = 'Spreadsheet ditemukan, namun hak akses masih "Dibatasi" (Restricted). Harap ubah ke: "Siapa saja yang memiliki link" -> "Pelihat" atau pasang Google Apps Script.';
            }
          } else if (testRes.ok && text.trim().length > 0) {
            results.sheetAccessible = true;
            results.message = 'Google Spreadsheet berhasil terhubung dan dapat diakses dengan baik!';
          } else {
            results.message = `HTTP status ${testRes.status}: Tidak dapat membaca data spreadsheet.`;
          }
        } catch (err: any) {
          results.message = 'Gagal menghubungi Google: ' + err.message;
        }
      }

      const overallSuccess = results.sheetAccessible || results.scriptAccessible;
      return res.json({
        success: overallSuccess,
        ...results
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  });

  // Vite middleware in dev mode, static files in production mode
  const distPath = path.resolve(__dirname, 'dist');
  const isProduction =
    process.env.NODE_ENV === 'production' ||
    process.env.npm_lifecycle_event === 'start' ||
    (!process.env.VITE_DEV && fs.existsSync(path.resolve(distPath, 'index.html')));

  if (isProduction) {
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SIM SARPRAS MA ASSALAAM Server running on http://0.0.0.0:${PORT} [mode: ${isProduction ? 'production' : 'development'}]`);
  });
}

startServer();
